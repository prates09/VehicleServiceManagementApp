import {
  MatFormFieldModule
} from "./chunk-YDABGFN3.js";
import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-2Q2IMSKE.js";
import "./chunk-V2VUYUQ6.js";
import "./chunk-VON75VBJ.js";
import "./chunk-PLJ2QXBA.js";
import "./chunk-5IHK76FA.js";
import "./chunk-34WMMMZQ.js";
import "./chunk-XA6252L2.js";
import "./chunk-TSEHOPNP.js";
import "./chunk-TLIDJWLS.js";
import "./chunk-4HTKOCLX.js";
import "./chunk-N4DOILP3.js";
import "./chunk-GUGIMSVJ.js";
import "./chunk-ERXYH7HE.js";
import "./chunk-EZI6J6PE.js";
import "./chunk-DS2J575Q.js";
import "./chunk-BNOFZN76.js";
import "./chunk-5BEJFZHM.js";
import "./chunk-3ENG2STM.js";
import "./chunk-35SGLJC5.js";
import "./chunk-BY7Z3IGD.js";
import "./chunk-UAVGWFT4.js";
import "./chunk-PSTBIIF2.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};
