import {
  MediaMatcher
} from "./chunk-4HTKOCLX.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-3ENG2STM.js";
import {
  InjectionToken,
  inject
} from "./chunk-35SGLJC5.js";

// node_modules/@angular/material/fesm2022/_animation-chunk.mjs
var MATERIAL_ANIMATIONS = new InjectionToken("MATERIAL_ANIMATIONS");
var reducedMotion = null;
function _getAnimationsState() {
  if (inject(MATERIAL_ANIMATIONS, {
    optional: true
  })?.animationsDisabled || inject(ANIMATION_MODULE_TYPE, {
    optional: true
  }) === "NoopAnimations") {
    return "di-disabled";
  }
  reducedMotion ??= inject(MediaMatcher).matchMedia("(prefers-reduced-motion)").matches;
  return reducedMotion ? "reduced-motion" : "enabled";
}
function _animationsDisabled() {
  return _getAnimationsState() !== "enabled";
}

export {
  MATERIAL_ANIMATIONS,
  _getAnimationsState,
  _animationsDisabled
};
//# sourceMappingURL=chunk-34WMMMZQ.js.map
