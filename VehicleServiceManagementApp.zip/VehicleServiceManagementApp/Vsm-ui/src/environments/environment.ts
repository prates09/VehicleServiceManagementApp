export const environment = {
  production: false,
  apiUrl: 'http://localhost:5187' // Default ASP.NET Core URL, change as needed
};
