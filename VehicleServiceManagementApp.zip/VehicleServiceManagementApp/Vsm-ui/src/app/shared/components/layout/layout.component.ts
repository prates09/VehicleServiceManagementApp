import { Component, inject, signal, effect, OnInit, computed } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatBadgeModule } from '@angular/material/badge';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { RouterLink, RouterOutlet, Router } from '@angular/router';
import { UpperCasePipe, DatePipe } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationsService, NotificationDto } from '../../../core/services/notifications.service';
import { toSignal } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.scss',
  standalone: true,
  imports: [
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatListModule,
    MatIconModule,
    MatMenuModule,
    MatBadgeModule,
    RouterLink,
    RouterOutlet,
    UpperCasePipe,
    DatePipe
  ]
})
export class LayoutComponent implements OnInit {
  private breakpointObserver = inject(BreakpointObserver);
  protected authService = inject(AuthService);
  private router = inject(Router);
  private notificationsService = inject(NotificationsService);

  notifications = signal<NotificationDto[]>([]);
  unreadCount = signal<number>(0);
  lastSeenCount = signal<number>(0);
  
  showBadge = computed(() => this.unreadCount() > 0 && this.unreadCount() > this.lastSeenCount());

  isHandset = toSignal(this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    ), { initialValue: false });

  isMenuOpen = signal(true);

  constructor() {
    effect(() => {
      if (this.isHandset()) {
        this.isMenuOpen.set(false);
      } else {
        this.isMenuOpen.set(true);
      }
    });
  }

  ngOnInit() {
    this.loadNotifications();
    // Poll for notifications every minute
    setInterval(() => this.loadNotifications(), 60000);
  }

  loadNotifications() {
    if (this.authService.isLoggedIn()) {
      this.notificationsService.getMyNotifications().subscribe({
        next: (n) => this.notifications.set(n),
        error: (e) => console.error('Error loading notifications', e)
      });
      this.notificationsService.getUnreadCount().subscribe({
        next: (c) => this.unreadCount.set(c),
        error: (e) => console.error('Error loading unread count', e)
      });
    }
  }

  markAsRead(notification: NotificationDto) {
    if (!notification.isRead) {
      this.notificationsService.markAsRead(notification.id).subscribe(() => {
        this.loadNotifications();
      });
    }

    // Navigate to related entity
    if (notification.relatedEntityId && notification.relatedEntityType) {
      if (notification.relatedEntityType === 'ServiceRequest') {
        this.router.navigate(['/service-requests', notification.relatedEntityId]);
      } else if (notification.relatedEntityType === 'Invoice') {
        this.router.navigate(['/billing', notification.relatedEntityId]);
      }
    }
  }

  onMenuOpened() {
    this.lastSeenCount.set(this.unreadCount());
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
