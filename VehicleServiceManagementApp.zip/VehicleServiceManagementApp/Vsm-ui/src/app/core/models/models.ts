export interface AdjustStockRequestDto {
  delta: number;
}

export interface AssignTechnicianDto {
  technicianUserName?: string | null;
}

export interface CreateCustomerRequestDto {
  fullName?: string | null;
  phone?: string | null;
  email?: string | null;
}

export interface CreateMyVehicleRequestDto {
  registrationNumber?: string | null;
  make?: string | null;
  model?: string | null;
  year: number;
  vehicleType?: string | null;
}

export interface CreatePartRequestDto {
  partNumber?: string | null;
  name?: string | null;
  unitPrice: number;
  stockQty: number;
  lowStockThreshold: number;
}

export interface CreateServiceCategoryRequestDto {
  name?: string | null;
  description?: string | null;
  basePrice: number;
}

export interface CreateServiceRequestRequestDto {
  vehicleId: number;
  issueDescription?: string | null;
  priority: ServicePriority;
  serviceCategoryId?: number | null;
}

export interface CreateVehicleRequestDto {
  customerId: number;
  registrationNumber?: string | null;
  make?: string | null;
  model?: string | null;
  year: number;
  vehicleType?: string | null;
}

export interface CustomerResponseDto {
  id: number;
  fullName?: string | null;
  phone?: string | null;
  email?: string | null;
}

export interface GenerateInvoiceRequestDto {
  laborCharge?: number | null;
  taxRate: number;
}

export interface InvoiceLineDto {
  id: number;
  itemType?: string | null;
  itemName?: string | null;
  itemCode?: string | null;
  quantity: number;
  unitPrice: number;
  lineTotal: number;
}

export interface InvoiceResponseDto {
  id: number;
  serviceRequestId: number;
  status: InvoiceStatus;
  laborCharge: number;
  partsTotal: number;
  taxRate: number;
  taxAmount: number;
  totalAmount: number;
  isPaid: boolean;
  generatedAtUtc: string;
  paidAtUtc?: string | null;
  paymentReference?: string | null;
  lines?: InvoiceLineDto[] | null;
}

export type InvoiceStatus = 'Generated' | 'Sent' | 'Paid' | 'Cancelled';

export interface LoginRequestDto {
  userName?: string | null;
  password?: string | null;
}

export interface PagedUsersResponseDto {
  page: number;
  pageSize: number;
  total: number;
  items?: UserListItemDto[] | null;
}

export interface PartResponseDto {
  id: number;
  partNumber?: string | null;
  name?: string | null;
  unitPrice: number;
  stockQty: number;
  lowStockThreshold: number;
  isLowStock: boolean;
}

export interface PayInvoiceRequestDto {
  paymentReference?: string | null;
}

export interface RegisterRequestDto {
  userName?: string | null;
  password?: string | null;
  fullName?: string | null;
  email?: string | null;
  phone?: string | null;
}

export interface ServiceCategoryResponseDto {
  id: number;
  name?: string | null;
  description?: string | null;
  basePrice: number;
  isActive: boolean;
}

export type ServicePriority = 'Normal' | 'Urgent';

export interface ServiceRequestResponseDto {
  id: number;
  customerId: number;
  vehicleId: number;
  issueDescription?: string | null;
  priority: ServicePriority;
  status: ServiceRequestStatus;
  remarks?: string | null;
  serviceCategoryId?: number | null;
  serviceCategoryName?: string | null;
  technicianId?: string | null;
  technicianUserName?: string | null;
  createdAt?: string | null;
}

export type ServiceRequestStatus = 'Requested' | 'Assigned' | 'InProgress' | 'Completed' | 'Closed' | 'Cancelled';

export interface ServiceSummaryReportDto {
  total: number;
  requested: number;
  assigned: number;
  inProgress: number;
  completed: number;
  closed: number;
  cancelled: number;
  pending: number;
  totalRevenue: number;
  monthlyRevenue: number;
}

export interface SetUserRoleRequestDto {
  role?: string | null;
}

export interface TechnicianWorkloadDto {
  technicianUserId?: string | null;
  technicianUserName?: string | null;
  totalAssigned: number;
  inProgress: number;
  completed: number;
  closed: number;
}

export interface TokenResponseDto {
  token?: string | null;
}

export interface UpdateCustomerRequestDto {
  fullName?: string | null;
  phone?: string | null;
  email?: string | null;
}

export interface UpdatePartRequestDto {
  partNumber?: string | null;
  name?: string | null;
  unitPrice: number;
  stockQty: number;
  lowStockThreshold: number;
}

export interface UpdateServiceCategoryRequestDto {
  name?: string | null;
  description?: string | null;
  basePrice: number;
  isActive: boolean;
}

export interface UpdateServiceRequestRequestDto {
  vehicleId: number;
  issueDescription?: string | null;
  priority: ServicePriority;
  serviceCategoryId?: number | null;
}

export interface UpdateServiceRequestStatusDto {
  status: ServiceRequestStatus;
  remarks?: string | null;
}

export interface UpdateVehicleRequestDto {
  registrationNumber?: string | null;
  make?: string | null;
  model?: string | null;
  vehicleType?: string | null;
  year: number;
}

export interface UsePartItemDto {
  partId: number;
  quantity: number;
}

export interface UsePartsRequestDto {
  items?: UsePartItemDto[] | null;
}

export interface UserListItemDto {
  id?: string | null;
  userName?: string | null;
  fullName?: string | null;
  roles?: string[] | null;
  isActive: boolean;
}

export interface VehicleResponseDto {
  id: number;
  customerId: number;
  registrationNumber?: string | null;
  make?: string | null;
  model?: string | null;
  year: number;
  vehicleType?: string | null;
}

export interface ServiceRequestPartDto {
  id: number;
  serviceRequestId: number;
  partId: number;
  partName?: string | null;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
}

export interface MonthlyReportDto {
  year: number;
  month: number;
  total: number;
  requested: number;
  assigned: number;
  inProgress: number;
  completed: number;
  closed: number;
  cancelled: number;
}

export interface MonthlyRevenueDto {
  year: number;
  month: number;
  totalRevenue: number;
  totalInvoices: number;
  partsRevenue: number;
  laborRevenue: number;
  taxCollected: number;
}

export interface RevenueByCategoryDto {
  categoryId?: number | null;
  categoryName?: string | null;
  totalRevenue: number;
  totalInvoices: number;
  partsRevenue: number;
  laborRevenue: number;
  taxCollected: number;
  averageInvoiceAmount: number;
}

export interface ServiceCategoryReportDto {
  categoryId?: number | null;
  categoryName?: string | null;
  totalRequests: number;
  requested: number;
  assigned: number;
  inProgress: number;
  completed: number;
  closed: number;
  cancelled: number;
}

export interface ServiceRequestByCategoryDto {
  id: number;
  customerId: number;
  vehicleId: number;
  issueDescription?: string | null;
  priority: ServicePriority;
  status: ServiceRequestStatus;
  remarks?: string | null;
  serviceCategoryId?: number | null;
  serviceCategoryName?: string | null;
  requestedAtUtc: string;
  scheduledAtUtc?: string | null;
  completedAtUtc?: string | null;
  closedAtUtc?: string | null;
}

export interface VehicleHistoryDto {
  id: number;
  vehicleId: number;
  customerId: number;
  issueDescription?: string | null;
  priority: ServicePriority;
  status: ServiceRequestStatus;
  remarks?: string | null;
  requestedAtUtc: string;
  scheduledAtUtc?: string | null;
  completedAtUtc?: string | null;
  closedAtUtc?: string | null;
  cancelledAtUtc?: string | null;
}

export interface MonthlyRevenueDto {
  year: number;
  month: number;
  totalRevenue: number;
  totalInvoices: number;
  partsRevenue: number;
  laborRevenue: number;
  taxCollected: number;
}

export interface RevenueByCategoryDto {
  categoryId?: number | null;
  categoryName?: string | null;
  totalRevenue: number;
  totalInvoices: number;
  partsRevenue: number;
  laborRevenue: number;
  taxCollected: number;
  averageInvoiceAmount: number;
}

export interface ServiceCategoryReportDto {
  categoryId?: number | null;
  categoryName?: string | null;
  totalRequests: number;
  requested: number;
  assigned: number;
  inProgress: number;
  completed: number;
  closed: number;
  cancelled: number;
}

export interface ServiceRequestByCategoryDto {
  id: number;
  customerId: number;
  vehicleId: number;
  issueDescription?: string | null;
  priority: ServicePriority;
  status: ServiceRequestStatus;
  remarks?: string | null;
  serviceCategoryId?: number | null;
  serviceCategoryName?: string | null;
  requestedAtUtc: string;
  scheduledAtUtc?: string | null;
  completedAtUtc?: string | null;
  closedAtUtc?: string | null;
}

export interface MonthlyReportDto {
  year: number;
  month: number;
  total: number;
  requested: number;
  assigned: number;
  inProgress: number;
  completed: number;
  closed: number;
  cancelled: number;
}


