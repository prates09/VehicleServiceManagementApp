import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { 
  CreateServiceCategoryRequestDto, 
  ServiceCategoryResponseDto, 
  UpdateServiceCategoryRequestDto 
} from '../models/models';

@Injectable({
  providedIn: 'root'
})
export class ServiceCategoriesService {
  private http = inject(HttpClient);
  private apiUrl = `${environment.apiUrl}/api/ServiceCategories`;

  getServiceCategories(activeOnly: boolean = false): Observable<ServiceCategoryResponseDto[]> {
    const params = new HttpParams().set('activeOnly', activeOnly);
    return this.http.get<ServiceCategoryResponseDto[]>(this.apiUrl, { params });
  }

  createServiceCategory(req: CreateServiceCategoryRequestDto): Observable<ServiceCategoryResponseDto> {
    return this.http.post<ServiceCategoryResponseDto>(this.apiUrl, req);
  }

  getServiceCategory(id: number): Observable<ServiceCategoryResponseDto> {
    return this.http.get<ServiceCategoryResponseDto>(`${this.apiUrl}/${id}`);
  }

  updateServiceCategory(id: number, req: UpdateServiceCategoryRequestDto): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, req);
  }

  deleteServiceCategory(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
