import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { 
  CreateServiceRequestRequestDto, 
  ServiceRequestResponseDto, 
  UpdateServiceRequestRequestDto, 
  AssignTechnicianDto, 
  UpdateServiceRequestStatusDto, 
  UsePartsRequestDto, 
  ServiceRequestStatus, 
  ServicePriority,
  ServiceRequestPartDto
} from '../models/models';

@Injectable({
  providedIn: 'root'
})
export class ServiceRequestsService {
  private http = inject(HttpClient);
  private apiUrl = `${environment.apiUrl}/api/ServiceRequests`;

  createServiceRequest(req: CreateServiceRequestRequestDto): Observable<ServiceRequestResponseDto> {
    return this.http.post<ServiceRequestResponseDto>(this.apiUrl, req);
  }

  getServiceRequests(status?: ServiceRequestStatus, priority?: ServicePriority, serviceCategoryId?: number): Observable<ServiceRequestResponseDto[]> {
    let params = new HttpParams();
    if (status) params = params.set('status', status);
    if (priority) params = params.set('priority', priority);
    if (serviceCategoryId) params = params.set('serviceCategoryId', serviceCategoryId);

    return this.http.get<ServiceRequestResponseDto[]>(this.apiUrl, { params });
  }

  getServiceRequest(id: number): Observable<ServiceRequestResponseDto> {
    return this.http.get<ServiceRequestResponseDto>(`${this.apiUrl}/${id}`);
  }

  updateServiceRequest(id: number, req: UpdateServiceRequestRequestDto): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, req);
  }

  deleteServiceRequest(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  getServiceRequestsByCustomer(customerId: number): Observable<ServiceRequestResponseDto[]> {
    return this.http.get<ServiceRequestResponseDto[]>(`${this.apiUrl}/by-customer/${customerId}`);
  }

  getMyServiceRequests(): Observable<ServiceRequestResponseDto[]> {
    return this.http.get<ServiceRequestResponseDto[]>(`${this.apiUrl}/my`);
  }

  getMyAssignedServiceRequests(): Observable<ServiceRequestResponseDto[]> {
    return this.http.get<ServiceRequestResponseDto[]>(`${this.apiUrl}/my-assigned`);
  }

  assignTechnician(id: number, req: AssignTechnicianDto): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}/assign`, req);
  }

  updateStatus(id: number, req: UpdateServiceRequestStatusDto): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}/technician-status`, req);
  }

  closeServiceRequest(id: number, req: UpdateServiceRequestStatusDto): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}/close`, req);
  }

  cancelServiceRequest(id: number, req: UpdateServiceRequestStatusDto): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}/cancel`, req);
  }

  getParts(id: number): Observable<ServiceRequestPartDto[]> {
    return this.http.get<ServiceRequestPartDto[]>(`${this.apiUrl}/${id}/parts`);
  }

  useParts(id: number, req: UsePartsRequestDto): Observable<void> {
    return this.http.post<void>(`${this.apiUrl}/${id}/parts/use`, req);
  }
}
