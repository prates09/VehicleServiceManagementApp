import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { 
  ServiceSummaryReportDto, 
  TechnicianWorkloadDto, 
  ServiceRequestStatus,
  MonthlyReportDto,
  VehicleHistoryDto,
  MonthlyRevenueDto,
  RevenueByCategoryDto,
  ServiceCategoryReportDto,
  ServiceRequestByCategoryDto
} from '../models/models';

@Injectable({
  providedIn: 'root'
})
export class ReportsService {
  private http = inject(HttpClient);
  private apiUrl = `${environment.apiUrl}/api/Reports`;

  getSummary(): Observable<ServiceSummaryReportDto> {
    return this.http.get<ServiceSummaryReportDto>(`${this.apiUrl}/summary`);
  }

  getTechnicianWorkload(): Observable<TechnicianWorkloadDto[]> {
    return this.http.get<TechnicianWorkloadDto[]>(`${this.apiUrl}/technician-workload`);
  }

  getMonthlyReport(year?: number): Observable<MonthlyReportDto[]> {
    let params = new HttpParams();
    if (year) params = params.set('year', year);
    return this.http.get<MonthlyReportDto[]>(`${this.apiUrl}/monthly`, { params });
  }

  getVehicleHistory(vehicleId: number): Observable<VehicleHistoryDto[]> {
    return this.http.get<VehicleHistoryDto[]>(`${this.apiUrl}/vehicle/${vehicleId}/history`);
  }

  getMonthlyRevenue(year?: number): Observable<MonthlyRevenueDto[]> {
    let params = new HttpParams();
    if (year) params = params.set('year', year);
    return this.http.get<MonthlyRevenueDto[]>(`${this.apiUrl}/revenue/monthly`, { params });
  }

  getRevenueByCategory(year?: number): Observable<RevenueByCategoryDto[]> {
    let params = new HttpParams();
    if (year) params = params.set('year', year);
    return this.http.get<RevenueByCategoryDto[]>(`${this.apiUrl}/revenue/by-category`, { params });
  }

  getServiceCategoryReport(status?: ServiceRequestStatus): Observable<ServiceCategoryReportDto[]> {
    let params = new HttpParams();
    if (status) params = params.set('status', status);
    return this.http.get<ServiceCategoryReportDto[]>(`${this.apiUrl}/by-category`, { params });
  }

  getServiceRequestsByCategory(categoryId: number, status?: ServiceRequestStatus): Observable<ServiceRequestByCategoryDto[]> {
    let params = new HttpParams();
    if (status) params = params.set('status', status);
    return this.http.get<ServiceRequestByCategoryDto[]>(`${this.apiUrl}/service-requests/by-category/${categoryId}`, { params });
  }
}
