import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { 
  GenerateInvoiceRequestDto, 
  InvoiceResponseDto, 
  PayInvoiceRequestDto 
} from '../models/models';

@Injectable({
  providedIn: 'root'
})
export class BillingService {
  private http = inject(HttpClient);
  private apiUrl = `${environment.apiUrl}/api/Billing`;

  generateInvoice(serviceRequestId: number, req: GenerateInvoiceRequestDto): Observable<InvoiceResponseDto> {
    return this.http.post<InvoiceResponseDto>(`${this.apiUrl}/service-requests/${serviceRequestId}/generate`, req);
  }

  getInvoices(isPaid?: boolean, serviceRequestId?: number): Observable<InvoiceResponseDto[]> {
    let params = new HttpParams();
    if (isPaid !== undefined) params = params.set('isPaid', isPaid);
    if (serviceRequestId) params = params.set('serviceRequestId', serviceRequestId);

    return this.http.get<InvoiceResponseDto[]>(this.apiUrl, { params });
  }

  getInvoice(id: number): Observable<InvoiceResponseDto> {
    return this.http.get<InvoiceResponseDto>(`${this.apiUrl}/${id}`);
  }

  getInvoiceByServiceRequest(serviceRequestId: number): Observable<InvoiceResponseDto> {
    return this.http.get<InvoiceResponseDto>(`${this.apiUrl}/by-service-request/${serviceRequestId}`);
  }

  getMyInvoices(): Observable<InvoiceResponseDto[]> {
    return this.http.get<InvoiceResponseDto[]>(`${this.apiUrl}/my`);
  }

  payInvoice(id: number, req: PayInvoiceRequestDto): Observable<InvoiceResponseDto> {
    return this.http.put<InvoiceResponseDto>(`${this.apiUrl}/${id}/pay`, req);
  }
}
