import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { 
  CreatePartRequestDto, 
  PartResponseDto, 
  UpdatePartRequestDto, 
  AdjustStockRequestDto 
} from '../models/models';

@Injectable({
  providedIn: 'root'
})
export class PartsService {
  private http = inject(HttpClient);
  private apiUrl = `${environment.apiUrl}/api/Parts`;

  getParts(search?: string, lowStockOnly: boolean = false): Observable<PartResponseDto[]> {
    let params = new HttpParams().set('lowStockOnly', lowStockOnly);
    if (search) params = params.set('search', search);

    return this.http.get<PartResponseDto[]>(this.apiUrl, { params });
  }

  createPart(req: CreatePartRequestDto): Observable<PartResponseDto> {
    return this.http.post<PartResponseDto>(this.apiUrl, req);
  }

  getPart(id: number): Observable<PartResponseDto> {
    return this.http.get<PartResponseDto>(`${this.apiUrl}/${id}`);
  }

  updatePart(id: number, req: UpdatePartRequestDto): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, req);
  }

  deletePart(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  getLowStockParts(): Observable<PartResponseDto[]> {
    return this.http.get<PartResponseDto[]>(`${this.apiUrl}/low-stock`);
  }

  adjustStock(id: number, req: AdjustStockRequestDto): Observable<PartResponseDto> {
    return this.http.put<PartResponseDto>(`${this.apiUrl}/${id}/stock`, req);
  }
}
