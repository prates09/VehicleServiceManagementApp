import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { 
  CreateVehicleRequestDto, 
  VehicleResponseDto, 
  CreateMyVehicleRequestDto, 
  UpdateVehicleRequestDto 
} from '../models/models';

@Injectable({
  providedIn: 'root'
})
export class VehiclesService {
  private http = inject(HttpClient);
  private apiUrl = `${environment.apiUrl}/api/Vehicles`;

  createVehicle(req: CreateVehicleRequestDto): Observable<VehicleResponseDto> {
    return this.http.post<VehicleResponseDto>(this.apiUrl, req);
  }

  getVehicles(): Observable<VehicleResponseDto[]> {
    return this.http.get<VehicleResponseDto[]>(this.apiUrl);
  }

  createMyVehicle(req: CreateMyVehicleRequestDto): Observable<VehicleResponseDto> {
    return this.http.post<VehicleResponseDto>(`${this.apiUrl}/my`, req);
  }

  getMyVehicles(): Observable<VehicleResponseDto[]> {
    return this.http.get<VehicleResponseDto[]>(`${this.apiUrl}/my`);
  }

  getVehiclesByCustomer(customerId: number): Observable<VehicleResponseDto[]> {
    return this.http.get<VehicleResponseDto[]>(`${this.apiUrl}/by-customer/${customerId}`);
  }

  getVehicle(id: number): Observable<VehicleResponseDto> {
    return this.http.get<VehicleResponseDto>(`${this.apiUrl}/${id}`);
  }

  updateVehicle(id: number, req: UpdateVehicleRequestDto): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, req);
  }

  deleteVehicle(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
