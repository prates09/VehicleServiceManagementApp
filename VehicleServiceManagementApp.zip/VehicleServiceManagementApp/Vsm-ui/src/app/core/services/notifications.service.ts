import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';

export interface NotificationDto {
  id: number;
  title?: string;
  message?: string;
  isRead: boolean;
  createdAtUtc: string;
  relatedEntityId?: number;
  relatedEntityType?: string;
}

@Injectable({
  providedIn: 'root'
})
export class NotificationsService {
  private http = inject(HttpClient);
  private apiUrl = `${environment.apiUrl}/api/Notifications`;

  getMyNotifications(take: number = 20): Observable<NotificationDto[]> {
    const params = new HttpParams().set('take', take);
    return this.http.get<NotificationDto[]>(`${this.apiUrl}/my`, { params });
  }

  markAsRead(id: number): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}/read`, {});
  }

  getUnreadCount(): Observable<number> {
    return this.http.get<any>(`${this.apiUrl}/my/unread-count`).pipe(
      map(response => {
        if (typeof response === 'number') {
          return response;
        }
        // Handle object response if backend returns { count: 5 } etc.
        if (response && typeof response === 'object') {
          if ('count' in response) return response.count;
          if ('unreadCount' in response) return response.unreadCount;
          if ('value' in response) return response.value;
        }
        return 0;
      })
    );
  }

  getLatestNotifications(take: number = 50): Observable<NotificationDto[]> {
    const params = new HttpParams().set('take', take);
    return this.http.get<NotificationDto[]>(`${this.apiUrl}/latest`, { params });
  }
}
