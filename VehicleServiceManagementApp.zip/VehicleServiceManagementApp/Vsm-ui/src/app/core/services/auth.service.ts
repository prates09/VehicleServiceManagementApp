import { Injectable, inject, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, tap, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import { 
  LoginRequestDto, 
  RegisterRequestDto, 
  TokenResponseDto, 
  PagedUsersResponseDto, 
  SetUserRoleRequestDto 
} from '../models/models';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private http = inject(HttpClient);
  private apiUrl = `${environment.apiUrl}/api/Auth`;
  
  // Signal to hold the current token
  token = signal<string | null>(localStorage.getItem('token'));
  userRole = signal<string | null>(null);
  userName = signal<string | null>(null);

  constructor() {
    // Initialize role and username from existing token
    const token = this.token();
    if (token) {
      this.decodeToken(token);
    }
  }

  isLoggedIn(): boolean {
    return !!this.token();
  }

  login(req: LoginRequestDto): Observable<TokenResponseDto> {
    return this.http.post<TokenResponseDto>(`${this.apiUrl}/login`, req).pipe(
      tap(res => {
        if (res.token) {
          this.setToken(res.token);
        }
      })
    );
  }

  register(req: RegisterRequestDto): Observable<void> {
    return this.http.post<void>(`${this.apiUrl}/register`, req);
  }

  getUsers(search?: string, role?: string, page: number = 1, pageSize: number = 20): Observable<PagedUsersResponseDto> {
    let params = new HttpParams()
      .set('page', page)
      .set('pageSize', pageSize);
    
    if (search) params = params.set('search', search);
    if (role) params = params.set('role', role);

    return this.http.get<PagedUsersResponseDto>(`${this.apiUrl}/users`, { params });
  }

  setUserRole(userName: string, req: SetUserRoleRequestDto): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/users/${userName}/role`, req);
  }

  toggleUserStatus(id: string): Observable<void> {
    return this.http.post<void>(`${this.apiUrl}/users/${id}/toggle-status`, {});
  }

  getUser(userName: string): Observable<any> {
    return this.getUsers(userName, undefined, 1, 1).pipe(
      map(response => {
        if (response.items && response.items.length > 0) {
          return response.items[0];
        }
        throw new Error('User not found');
      })
    );
  }

  updateUser(userName: string, data: any): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/users/${userName}`, data);
  }

  deleteUser(userName: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/users/${userName}`);
  }

  logout(): void {
    this.setToken(null);
  }

  private setToken(token: string | null): void {
    if (token) {
      localStorage.setItem('token', token);
      this.decodeToken(token);
    } else {
      localStorage.removeItem('token');
      this.userRole.set(null);
      this.userName.set(null);
    }
    this.token.set(token);
  }

  isAuthenticated(): boolean {
    return !!this.token();
  }

  private decodeToken(token: string) {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      // ASP.NET Core Identity uses this claim type for roles
      const role = payload['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'] || 
                   payload['role'] || 
                   null;
      const name = payload['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name'] || 
                   payload['unique_name'] || 
                   payload['sub'];
      
      this.userRole.set(role);
      this.userName.set(name);
    } catch (e) {
      console.error('Failed to decode token', e);
      this.userRole.set(null);
      this.userName.set(null);
    }
  }
}
