import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { 
  CreateCustomerRequestDto, 
  CustomerResponseDto, 
  UpdateCustomerRequestDto 
} from '../models/models';

@Injectable({
  providedIn: 'root'
})
export class CustomersService {
  private http = inject(HttpClient);
  private apiUrl = `${environment.apiUrl}/api/Customers`;

  getCustomersWithUsers(): Observable<void> {
    return this.http.get<void>(`${this.apiUrl}/with-users`);
  }

  createCustomer(req: CreateCustomerRequestDto): Observable<CustomerResponseDto> {
    return this.http.post<CustomerResponseDto>(this.apiUrl, req);
  }

  getCustomers(): Observable<CustomerResponseDto[]> {
    return this.http.get<CustomerResponseDto[]>(this.apiUrl);
  }

  getCustomer(id: number): Observable<CustomerResponseDto> {
    return this.http.get<CustomerResponseDto>(`${this.apiUrl}/${id}`);
  }

  updateCustomer(id: number, req: UpdateCustomerRequestDto): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, req);
  }

  deleteCustomer(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  getMyProfile(): Observable<CustomerResponseDto> {
    return this.http.get<CustomerResponseDto>(`${this.apiUrl}/my-profile`);
  }

  updateMyProfile(req: UpdateCustomerRequestDto): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/my-profile`, req);
  }
}
