import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';

/**
 * Configures a MatTableDataSource with custom sorting logic:
 * - Case-insensitive
 * - Locale-aware
 * - Trims whitespace
 * - Sorts numeric strings numerically
 * - Puts null/undefined/empty values at the end regardless of direction
 */
export function configureTableSorting<T>(dataSource: MatTableDataSource<T>) {
  dataSource.sortData = (data: T[], sort: MatSort): T[] => {
    const active = sort.active;
    const direction = sort.direction;

    if (!active || direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      // Use the existing sortingDataAccessor to get values
      // We cast to any to access the method which is public on MatTableDataSource
      let valueA = dataSource.sortingDataAccessor(a, active);
      let valueB = dataSource.sortingDataAccessor(b, active);

      // Check for null/undefined/empty
      // We treat empty strings as nulls for sorting purposes to push them to the bottom
      const isANull = valueA === null || valueA === undefined || valueA === '';
      const isBNull = valueB === null || valueB === undefined || valueB === '';

      if (isANull && isBNull) return 0;
      
      // Always put nulls at the bottom
      // In Array.sort, returning > 0 puts 'a' after 'b'
      if (isANull) return 1;
      if (isBNull) return -1;

      // Convert to strings for processing
      const strA = String(valueA).trim();
      const strB = String(valueB).trim();

      // Check if both are numeric
      const numA = Number(strA);
      const numB = Number(strB);
      // Check if valid number and not an empty string (already handled but good for safety)
      const isANum = !isNaN(numA) && strA !== '';
      const isBNum = !isNaN(numB) && strB !== '';

      let comparison = 0;
      if (isANum && isBNum) {
        comparison = numA - numB;
      } else {
        // Case-insensitive, locale-aware string comparison
        comparison = strA.localeCompare(strB, undefined, { sensitivity: 'base', numeric: true });
      }

      // Apply direction multiplier
      return comparison * (direction === 'asc' ? 1 : -1);
    });
  };
}

/**
 * Sorts data by latest date (descending) or ID (descending) as fallback.
 * Checks for common date fields: updatedAt, createdAt, requestedAtUtc, generatedAtUtc.
 */
export function sortDataByLatest<T>(data: T[]): T[] {
  return data.sort((a: any, b: any) => {
    // 1. Try Date fields
    const dateA = a.updatedAt || a.updatedAtUtc || a.createdAt || a.createdAtUtc || a.requestedAtUtc || a.generatedAtUtc;
    const dateB = b.updatedAt || b.updatedAtUtc || b.createdAt || b.createdAtUtc || b.requestedAtUtc || b.generatedAtUtc;

    if (dateA && dateB) {
      return new Date(dateB).getTime() - new Date(dateA).getTime();
    }

    // 2. Fallback to ID (assuming higher ID = newer for auto-increment)
    if (a.id && b.id) {
        if (typeof a.id === 'number' && typeof b.id === 'number') {
            return b.id - a.id;
        }
    }

    return 0;
  });
}
