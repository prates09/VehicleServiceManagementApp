import { Routes } from '@angular/router';
import { LoginComponent } from './features/auth/login/login.component';
import { RegisterComponent } from './features/auth/register/register.component';
import { LayoutComponent } from './shared/components/layout/layout.component';
import { authGuard } from './core/guards/auth.guard';
import { roleGuard } from './core/guards/role.guard';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  {
    path: '',
    component: LayoutComponent,
    canActivate: [authGuard],
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { 
        path: 'dashboard', 
        loadComponent: () => import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent) 
      },
      { 
        path: 'users/create', 
        loadComponent: () => import('./features/users/user-form/user-form.component').then(m => m.UserFormComponent) 
      },
      { 
        path: 'users/:id', 
        loadComponent: () => import('./features/users/user-form/user-form.component').then(m => m.UserFormComponent) 
      },
      { 
        path: 'users', 
        loadComponent: () => import('./features/users/user-list/user-list.component').then(m => m.UserListComponent) 
      },
      { 
        path: 'service-categories', 
        loadComponent: () => import('./features/service-categories/service-category-list/service-category-list.component').then(m => m.ServiceCategoryListComponent) 
      },
      { 
        path: 'service-categories/:id', 
        loadComponent: () => import('./features/service-categories/service-category-form/service-category-form.component').then(m => m.ServiceCategoryFormComponent) 
      },
      { 
        path: 'service-requests', 
        loadComponent: () => import('./features/service-requests/service-request-list/service-request-list.component').then(m => m.ServiceRequestListComponent) 
      },
      { 
        path: 'service-requests/:id', 
        loadComponent: () => import('./features/service-requests/service-request-form/service-request-form.component').then(m => m.ServiceRequestFormComponent) 
      },
      { 
        path: 'vehicles', 
        loadComponent: () => import('./features/vehicles/vehicle-list/vehicle-list.component').then(m => m.VehicleListComponent) 
      },
      { 
        path: 'vehicles/:id', 
        loadComponent: () => import('./features/vehicles/vehicle-form/vehicle-form.component').then(m => m.VehicleFormComponent) 
      },
      {
        path: 'customer/vehicles/:id/history',
        loadComponent: () => import('./features/vehicles/vehicle-history/vehicle-history.component').then(m => m.VehicleHistoryComponent)
      },
      { 
        path: 'profile',  
        loadComponent: () => import('./features/profile/profile.component').then(m => m.ProfileComponent) 
      },
      { 
        path: 'parts', 
        loadComponent: () => import('./features/parts/part-list/part-list.component').then(m => m.PartListComponent),
        canActivate: [roleGuard],
        data: { roles: ['Admin'] }
      },
      { 
        path: 'parts/:id', 
        loadComponent: () => import('./features/parts/part-form/part-form.component').then(m => m.PartFormComponent),
        canActivate: [roleGuard],
        data: { roles: ['Admin'] }
      },
      { 
        path: 'billing', 
        loadComponent: () => import('./features/billing/invoice-list/invoice-list.component').then(m => m.InvoiceListComponent) 
      },
      { 
        path: 'billing/:id', 
        loadComponent: () => import('./features/billing/invoice-details/invoice-details.component').then(m => m.InvoiceDetailsComponent) 
      },
      { 
        path: 'reports', 
        loadComponent: () => import('./features/reports/reports.component').then(m => m.ReportsComponent),
        canActivate: [roleGuard],
        data: { roles: ['ServiceManager', 'Admin'] }
      },
      { 
        path: 'reports/low-stock', 
        loadComponent: () => import('./features/reports/pages/low-stock-report/low-stock-report.component').then(m => m.LowStockReportComponent),
        canActivate: [roleGuard],
        data: { roles: ['ServiceManager', 'Admin'] }
      },
      { 
        path: 'reports/workload', 
        loadComponent: () => import('./features/reports/pages/workload-report/workload-report.component').then(m => m.WorkloadReportComponent),
        canActivate: [roleGuard],
        data: { roles: ['ServiceManager', 'Admin'] }
      },
      { 
        path: 'reports/status', 
        loadComponent: () => import('./features/reports/pages/status-report/status-report.component').then(m => m.StatusReportComponent),
        canActivate: [roleGuard],
        data: { roles: ['ServiceManager', 'Admin'] }
      },
      { 
        path: 'reports/volume', 
        loadComponent: () => import('./features/reports/pages/volume-report/volume-report.component').then(m => m.VolumeReportComponent),
        canActivate: [roleGuard],
        data: { roles: ['ServiceManager', 'Admin'] }
      }
    ]
  }
];