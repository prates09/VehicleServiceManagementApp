import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ServiceCategoriesService } from '../../../core/services/service-categories.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-service-category-form',
  templateUrl: './service-category-form.component.html',
  styleUrl: './service-category-form.component.scss',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSlideToggleModule,
    RouterLink
  ]
})
export class ServiceCategoryFormComponent implements OnInit {
  private fb = inject(FormBuilder);
  private serviceCategoriesService = inject(ServiceCategoriesService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private snackBar = inject(MatSnackBar);

  form: FormGroup;
  isEditMode = false;
  categoryId: number | null = null;

  constructor() {
    this.form = this.fb.group({
      name: ['', Validators.required],
      description: [''],
      basePrice: [0, [Validators.required, Validators.min(0)]],
      isActive: [true]
    });
  }

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id && id !== 'new') {
      this.isEditMode = true;
      this.categoryId = +id;
      this.loadCategory(this.categoryId);
    }
  }

  loadCategory(id: number) {
    this.serviceCategoriesService.getServiceCategory(id).subscribe({
      next: (res) => {
        this.form.patchValue(res);
      },
      error: (err) => console.error(err)
    });
  }

  onSubmit() {
    if (this.form.invalid) return;

    const req = this.form.value;

    if (this.isEditMode && this.categoryId) {
      this.serviceCategoriesService.updateServiceCategory(this.categoryId, req).subscribe({
        next: () => {
          this.snackBar.open('Category updated successfully', 'Close', { duration: 3000 });
          this.router.navigate(['/service-categories']);
        },
        error: (err) => {
          console.error(err);
          this.snackBar.open('Failed to update category', 'Close', { duration: 3000 });
        }
      });
    } else {
      this.serviceCategoriesService.createServiceCategory(req).subscribe({
        next: () => {
          this.snackBar.open('Category created successfully', 'Close', { duration: 3000 });
          this.router.navigate(['/service-categories']);
        },
        error: (err) => {
          console.error(err);
          this.snackBar.open('Failed to create category', 'Close', { duration: 3000 });
        }
      });
    }
  }
}
