import { Component, inject, OnInit, ViewChild } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { RouterLink } from '@angular/router';
import { ServiceCategoriesService } from '../../../core/services/service-categories.service';
import { ServiceCategoryResponseDto } from '../../../core/models/models';
import { MatSnackBar } from '@angular/material/snack-bar';
import { configureTableSorting, sortDataByLatest } from '../../../core/utils/table.utils';

@Component({
  selector: 'app-service-category-list',
  templateUrl: './service-category-list.component.html',
  styleUrl: './service-category-list.component.scss',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    RouterLink,
    CurrencyPipe
  ]
})
export class ServiceCategoryListComponent implements OnInit {
  private serviceCategoriesService = inject(ServiceCategoriesService);
  private snackBar = inject(MatSnackBar);

  dataSource = new MatTableDataSource<ServiceCategoryResponseDto>([]);
  displayedColumns: string[] = ['name', 'description', 'basePrice', 'isActive', 'actions'];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  ngOnInit() {
    this.loadCategories();
  }

  loadCategories() {
    this.serviceCategoriesService.getServiceCategories().subscribe({
      next: (res) => {
        this.dataSource.data = sortDataByLatest(res);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        configureTableSorting(this.dataSource);
      },
      error: (err) => console.error(err)
    });
  }

  deleteCategory(id: number) {
    if (confirm('Are you sure you want to delete this category?')) {
      this.serviceCategoriesService.deleteServiceCategory(id).subscribe({
        next: () => {
          this.snackBar.open('Category deleted successfully', 'Close', { duration: 3000 });
          this.loadCategories();
        },
        error: (err) => {
          console.error(err);
          this.snackBar.open('Failed to delete category', 'Close', { duration: 3000 });
        }
      });
    }
  }
}
