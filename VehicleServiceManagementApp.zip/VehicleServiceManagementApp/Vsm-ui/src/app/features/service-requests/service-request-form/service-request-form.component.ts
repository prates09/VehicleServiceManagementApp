import { Component, inject, OnInit } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators, FormControl } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { ServiceRequestsService } from '../../../core/services/service-requests.service';
import { VehiclesService } from '../../../core/services/vehicles.service';
import { ServiceCategoriesService } from '../../../core/services/service-categories.service';
import { AuthService } from '../../../core/services/auth.service';
import { PartsService } from '../../../core/services/parts.service';
import { BillingService } from '../../../core/services/billing.service';
import { VehicleResponseDto, ServiceCategoryResponseDto, UserListItemDto, ServiceRequestStatus, PartResponseDto, ServiceRequestPartDto, ServicePriority } from '../../../core/models/models';
import { Observable, map, of, tap, BehaviorSubject } from 'rxjs';
import { catchError, shareReplay, switchMap } from 'rxjs/operators';
import { AsyncPipe, CurrencyPipe, NgIf } from '@angular/common';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatTableModule } from '@angular/material/table';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { ConfirmDialogComponent } from '../../../shared/components/confirm-dialog/confirm-dialog.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-service-request-form',
  templateUrl: './service-request-form.component.html',
  styleUrl: './service-request-form.component.scss',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatTableModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressSpinnerModule,
    MatIconModule,
    RouterLink,
    AsyncPipe,
    CurrencyPipe,
    NgIf,
    MatDialogModule
  ]
})
export class ServiceRequestFormComponent implements OnInit {
  private fb = inject(FormBuilder);
  private serviceRequestsService = inject(ServiceRequestsService);
  private vehiclesService = inject(VehiclesService);
  private serviceCategoriesService = inject(ServiceCategoriesService);
  private authService = inject(AuthService);
  private partsService = inject(PartsService);
  private billingService = inject(BillingService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private snackBar = inject(MatSnackBar);
  private dialog = inject(MatDialog);

  vehicles$: Observable<VehicleResponseDto[]> | undefined;
  categories$: Observable<ServiceCategoryResponseDto[]> | undefined;
  availableParts$: Observable<PartResponseDto[]> | undefined;
  usedParts$: Observable<ServiceRequestPartDto[]> | undefined;
  technicians$: Observable<UserListItemDto[]> | undefined;
  
  private partsRefresh$ = new BehaviorSubject<void>(undefined);

  isEditMode = false;
  requestId: number | null = null;
  userRole: string | null = null;
  currentStatus: ServiceRequestStatus = 'Requested';
  assignedTechnician: string | null = null;
  
  // Helper to track if the assigned user is no longer a valid technician
  technicianList: UserListItemDto[] = [];
  isTechnicianInvalid = false;
  isLoading = false;

  form = this.fb.group({
    vehicleId: [0, Validators.required],
    issueDescription: ['', Validators.required],
    priority: ['Normal', Validators.required],
    serviceCategoryId: [0, Validators.required],
    preferredDate: [null as Date | null]
  });

  // Controls for Service Manager / Technician actions
  assignTechnicianControl = new FormControl('');
  statusRemarksControl = new FormControl('');

  // Controls for Parts
  selectedPartControl = new FormControl<number | null>(null);
  partQuantityControl = new FormControl(1, [Validators.min(1)]);
  displayedPartColumns: string[] = ['partName', 'quantity', 'unitPrice', 'totalPrice'];

  ngOnInit() {
    this.userRole = this.authService.userRole();
    
    if (this.userRole === 'Customer') {
      this.vehicles$ = this.vehiclesService.getMyVehicles().pipe(
        catchError(() => of([])),
        tap(vehicles => {
          if (vehicles.length === 1) {
            this.form.patchValue({ vehicleId: vehicles[0].id });
          }
        })
      );
    } else {
      this.vehicles$ = this.vehiclesService.getVehicles().pipe(catchError(() => of([])));
    }
    
    this.categories$ = this.serviceCategoriesService.getServiceCategories(true);

    if (this.userRole === 'ServiceManager' || this.userRole === 'ServiceManager' || this.userRole === 'Technician' || this.userRole === 'Admin') {
      this.availableParts$ = this.partsService.getParts();
    }

    if (this.userRole === 'ServiceManager' || this.userRole === 'Admin') {
      // Try to fetch technicians directly using the role parameter
      this.technicians$ = this.authService.getUsers(undefined, 'Technician', 1, 100).pipe(
        map(res => res.items || []),
        tap(users => {
          this.technicianList = users;
          this.checkTechnicianValidity();
        }),
        shareReplay(1)
      );
    }

    this.usedParts$ = this.partsRefresh$.pipe(
      switchMap(() => {
        if (!this.requestId) return of([]);
        return this.serviceRequestsService.getParts(this.requestId).pipe(
          catchError(error => {
            console.error('Error loading parts:', error);
            return of([]);
          })
        );
      }),
      shareReplay(1)
    );

    const id = this.route.snapshot.paramMap.get('id');
    if (id && id !== 'new') {
      this.isEditMode = true;
      this.requestId = +id;
      this.loadUsedParts();
      this.serviceRequestsService.getServiceRequest(this.requestId).subscribe(request => {
        console.log('Loaded Service Request:', request); // Debug log
        this.currentStatus = request.status;

        // Extract Preferred Date from Description if present
        let cleanDescription = request.issueDescription;
        let extractedDate = null;
        const dateRegex = /^Preferred Date: (.*?)(?:\n+|$)/i;
        
        if (cleanDescription) {
          const match = cleanDescription.match(dateRegex);
          if (match) {
            const dateStr = match[1];
            extractedDate = new Date(dateStr);
            cleanDescription = cleanDescription.replace(dateRegex, '');
          }
        }

        this.form.patchValue({
          vehicleId: request.vehicleId,
          issueDescription: cleanDescription,
          priority: request.priority,
          serviceCategoryId: request.serviceCategoryId || 0,
          preferredDate: extractedDate
        });

        if (request.technicianUserName) {
          this.assignTechnicianControl.setValue(request.technicianUserName);
          this.assignedTechnician = request.technicianUserName;
          this.checkTechnicianValidity();
        }
        
        // Disable main form if not Customer or if status is advanced
        if (this.userRole !== 'Customer' && this.userRole !== 'ServiceManager' && this.userRole !== 'Admin') {
          this.form.disable();
        }

        // Rule: Customers can only edit if status is 'Requested'
        if (this.userRole === 'Customer') {
          if (this.currentStatus !== 'Requested') {
            this.form.disable();
            this.snackBar.open('This request cannot be modified after assignment.', 'Close', { duration: 5000 });
          } else {
            // Customer Reschedule Mode: Lock everything except Date
            this.form.get('vehicleId')?.disable();
            this.form.get('issueDescription')?.disable();
            this.form.get('priority')?.disable();
            this.form.get('serviceCategoryId')?.disable();
            // Ensure date is enabled
            this.form.get('preferredDate')?.enable();
          }
        }
      });
    }
  }
checkTechnicianValidity() {
    if (this.assignedTechnician && this.technicianList.length > 0) {
      const isValid = this.technicianList.some(t => t.userName === this.assignedTechnician);
      this.isTechnicianInvalid = !isValid;
    }
  }

  
  onSubmit() {
    if (this.form.valid && (this.form.enabled || this.userRole === 'Customer')) {
      this.isLoading = true;
      // Use getRawValue() to include disabled fields
      const formValue = this.form.getRawValue();
      
      // Handle Description & Date Logic
      let description = formValue.issueDescription || '';
      
      // 1. Remove any existing "Preferred Date" line to avoid duplication
      // Matches "Preferred Date: 1/1/2026" followed by newlines
      description = description.replace(/^Preferred Date:.*?\n+/i, '');

      // 2. Prepend the new date if selected
      if (formValue.preferredDate) {
        const dateStr = new Date(formValue.preferredDate).toLocaleDateString();
        description = `Preferred Date: ${dateStr}\n\n${description}`;
      }

      const req = {
        vehicleId: Number(formValue.vehicleId),
        serviceCategoryId: Number(formValue.serviceCategoryId),
        priority: formValue.priority as ServicePriority,
        issueDescription: description
      };

      let request$: Observable<any>;

      if (this.isEditMode && this.requestId) {
        request$ = this.serviceRequestsService.updateServiceRequest(this.requestId, req);
      } else {
        request$ = this.serviceRequestsService.createServiceRequest(req);
      }

      request$.subscribe({
        next: () => {
          this.isLoading = false;
          this.snackBar.open(
            this.isEditMode ? 'Request updated successfully' : 'Request created successfully', 
            'Close', 
            { duration: 3000 }
          );
          this.router.navigate(['/service-requests']);
        },
        error: (err) => {
          this.isLoading = false;
          console.error('Error submitting request:', err);
          
          // Extract meaningful error message
          let errorMessage = 'An error occurred';
          if (typeof err.error === 'string') {
            errorMessage = err.error;
          } else if (err.error?.title) {
            errorMessage = err.error.title; // ASP.NET Core Problem Details
          } else if (err.message) {
            errorMessage = err.message;
          }
          
          this.snackBar.open(errorMessage, 'Close', { duration: 5000 });
        }
      });
    }
  }

  onAssignTechnician() {
    if (this.requestId && this.assignTechnicianControl.value) {
      const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        data: {
          title: 'Confirm Assignment',
          message: 'Are you sure you want to assign this technician?'
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          const technicianUserName = this.assignTechnicianControl.value;
          console.log('Assigning technician:', technicianUserName);

          this.serviceRequestsService.assignTechnician(this.requestId!, { 
            technicianUserName: technicianUserName 
          }).subscribe({
            next: () => {
              this.snackBar.open('Technician assigned', 'Close', { duration: 3000 });
              this.router.navigate(['/service-requests']);
            },
            error: (err) => {
              console.error('Assignment error:', err);
              // Try to extract a meaningful error message
              let msg = 'Failed to assign technician';
              if (err.error) {
                if (typeof err.error === 'string') msg = err.error;
                else if (err.error.detail) msg = err.error.detail;
                else if (err.error.title) msg = err.error.title;
                else if (err.error.errors) msg = JSON.stringify(err.error.errors);
              }
              this.snackBar.open(`Error: ${msg}`, 'Close', { duration: 5000 });
            }
          });
        }
      });
    }
  }

  onUpdateStatus(status: ServiceRequestStatus) {
    if (!this.requestId) return;

    const remarks = this.statusRemarksControl.value;
    const req = { status, remarks };

    let obs: Observable<void>;

    if (status === 'Closed') {
      obs = this.serviceRequestsService.closeServiceRequest(this.requestId, req);
    } else if (status === 'Cancelled') {
      obs = this.serviceRequestsService.cancelServiceRequest(this.requestId, req);
    } else {
      obs = this.serviceRequestsService.updateStatus(this.requestId, req);
    }

    obs.subscribe({
      next: () => {
        this.snackBar.open(`Status updated to ${status}`, 'Close', { duration: 3000 });
        
        if (status === 'Completed') {
          this.generateInvoice();
        } else {
          this.router.navigate(['/service-requests']);
        }
      },
      error: (err) => console.error(err)
    });
  }

  private generateInvoice() {
    if (!this.requestId) return;

    // Helper to handle invoice generation response
    const handleInvoiceResponse = {
      next: () => {
        this.snackBar.open('Invoice generated successfully', 'Close', { duration: 3000 });
        this.router.navigate(['/service-requests']);
      },
      error: (err: any) => {
        console.error('Error generating invoice', err);
        
        // Treat 200/201 as success even if parsing failed (e.g. text response)
        if (err.status === 200 || err.status === 201) {
           this.snackBar.open('Invoice generated successfully', 'Close', { duration: 3000 });
        } else if (err.error && typeof err.error === 'string' && err.error.includes('exists')) {
           this.snackBar.open('Invoice already exists', 'Close', { duration: 3000 });
        } else {
           // Fallback success message since the task is completed
           this.snackBar.open('Task completed. Please verify invoice generation.', 'Close', { duration: 3000 });
        }
        this.router.navigate(['/service-requests']);
      }
    };

    // Get the service category price to use as labor charge
    const categoryId = this.form.value.serviceCategoryId;
    if (categoryId) {
      this.serviceCategoriesService.getServiceCategory(categoryId).subscribe({
        next: (category) => {
          this.billingService.generateInvoice(this.requestId!, {
            laborCharge: category.basePrice,
            taxRate: 0.18 // Default 18% tax
          }).subscribe(handleInvoiceResponse);
        },
        error: () => {
          // Fallback if category fetch fails
          this.billingService.generateInvoice(this.requestId!, {
            laborCharge: 0,
            taxRate: 0.18
          }).subscribe(handleInvoiceResponse);
        }
      });
    } else {
      // No category, just generate with 0 labor
      this.billingService.generateInvoice(this.requestId!, {
        laborCharge: 0,
        taxRate: 0.18
      }).subscribe(handleInvoiceResponse);
    }
  }

  loadUsedParts() {
    if (this.requestId) {
      this.partsRefresh$.next();
    }
  }

  onAddPart() {
    if (!this.requestId || !this.selectedPartControl.value || !this.partQuantityControl.value) return;
    
    const partId = this.selectedPartControl.value;
    const quantity = this.partQuantityControl.value;

    this.serviceRequestsService.useParts(this.requestId, {
      items: [{ partId, quantity }]
    }).subscribe({
      next: () => {
        this.snackBar.open('Part added successfully', 'Close', { duration: 3000 });
        this.loadUsedParts();
        this.selectedPartControl.reset();
        this.partQuantityControl.setValue(1);
      },
      error: (err) => {
        console.error(err);
        this.snackBar.open('Failed to add part', 'Close', { duration: 3000 });
      }
    });
  }
}
