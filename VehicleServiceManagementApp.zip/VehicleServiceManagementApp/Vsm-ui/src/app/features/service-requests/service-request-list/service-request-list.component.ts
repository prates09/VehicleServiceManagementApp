import { Component, inject, OnInit, ViewChild } from '@angular/core';
import { AsyncPipe, DatePipe } from '@angular/common';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ServiceRequestsService } from '../../../core/services/service-requests.service';
import { AuthService } from '../../../core/services/auth.service';
import { VehiclesService } from '../../../core/services/vehicles.service';
import { ServiceRequestResponseDto, VehicleResponseDto, ServiceRequestStatus } from '../../../core/models/models';
import { Observable, combineLatest, of, forkJoin } from 'rxjs';
import { map, catchError, tap, switchMap } from 'rxjs/operators';
import { configureTableSorting, sortDataByLatest } from '../../../core/utils/table.utils';
import { AssignTechnicianDialogComponent } from '../assign-technician-dialog/assign-technician-dialog.component';

@Component({
  selector: 'app-service-request-list',
  templateUrl: './service-request-list.component.html',
  styleUrl: './service-request-list.component.scss',
  standalone: true,
  imports: [
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatTooltipModule,
    MatSelectModule,
    MatFormFieldModule,
    FormsModule,
    RouterLink
  ]
})
export class ServiceRequestListComponent implements OnInit {
  private serviceRequestsService = inject(ServiceRequestsService);
  protected authService = inject(AuthService);
  private vehiclesService = inject(VehiclesService);
  private dialog = inject(MatDialog);
  
  dataSource = new MatTableDataSource<(ServiceRequestResponseDto & { vehicleReg?: string })>([]);
  displayedColumns: string[] = ['id', 'vehicleReg', 'issueDescription', 'priority', 'status', 'actions'];

  selectedStatus: ServiceRequestStatus | 'All' = 'All';
  statuses: (ServiceRequestStatus | 'All')[] = ['All', 'Requested', 'Assigned', 'InProgress', 'Completed', 'Closed', 'Cancelled'];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  ngOnInit() {
    this.loadRequests();
  }

  onFilterChange() {
    this.loadRequests();
  }

  loadRequests() {
    const role = this.authService.userRole();
    let requests$: Observable<ServiceRequestResponseDto[]>;

    if (role === 'Customer') {
      requests$ = this.serviceRequestsService.getMyServiceRequests().pipe(
        catchError(() => of([])),
        map(requests => this.selectedStatus === 'All' ? requests : requests.filter(r => r.status === this.selectedStatus))
      );
    } else if (role === 'Technician') {
      requests$ = this.serviceRequestsService.getMyAssignedServiceRequests().pipe(
        catchError(() => of([])),
        map(requests => this.selectedStatus === 'All' ? requests : requests.filter(r => r.status === this.selectedStatus))
      );
    } else {
      const statusParam = this.selectedStatus === 'All' ? undefined : this.selectedStatus;
      requests$ = this.serviceRequestsService.getServiceRequests(statusParam).pipe(catchError(() => of([])));
    }

    requests$.pipe(
      switchMap(requests => {
        let vehicles$: Observable<VehicleResponseDto[]>;

        if (role === 'Customer') {
          // Try bulk fetch first
          vehicles$ = this.vehiclesService.getMyVehicles().pipe(
            catchError(() => of([])),
            switchMap(vehicles => {
              if (vehicles.length > 0) return of(vehicles);
              
              // Fallback: Fetch individually based on requests
              const vehicleIds = [...new Set(requests.map(r => r.vehicleId))];
              if (vehicleIds.length === 0) return of([]);
              
              return forkJoin(
                vehicleIds.map(id => this.vehiclesService.getVehicle(id).pipe(catchError(() => of(null))))
              ).pipe(
                map(vs => vs.filter(v => v !== null) as VehicleResponseDto[])
              );
            })
          );
        } else if (role === 'Technician') {
          // Backend restricts vehicle access for Technicians (403 Forbidden).
          // We skip fetching vehicle details to avoid errors.
          // The UI will display "Vehicle #ID" instead of the registration number.
          vehicles$ = of([]);
        } else {
          vehicles$ = this.vehiclesService.getVehicles().pipe(catchError(() => of([])));
        }

        return vehicles$.pipe(
          map(vehicles => {
            const vehicleMap = new Map(vehicles.map(v => [v.id, v.registrationNumber]));
            return sortDataByLatest(requests.map(r => ({
              ...r,
              vehicleReg: vehicleMap.get(r.vehicleId) || `Vehicle #${r.vehicleId}`,
              issueDescription: r.issueDescription ? r.issueDescription.replace(/^Preferred Date: (.*?)(?:\n+|$)/i, '') : r.issueDescription
            })));
          })
        );
      })
    ).subscribe(data => {
      this.dataSource.data = data;
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      configureTableSorting(this.dataSource);
    });
  }

  openAssignDialog(request: ServiceRequestResponseDto & { vehicleReg?: string }) {
    const dialogRef = this.dialog.open(AssignTechnicianDialogComponent, {
      width: '500px',
      data: { request }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadRequests();
      }
    });
  }
}
