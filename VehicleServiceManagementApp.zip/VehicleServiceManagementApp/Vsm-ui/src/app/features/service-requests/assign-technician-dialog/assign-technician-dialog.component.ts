import { Component, Inject, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { ServiceRequestResponseDto } from '../../../core/models/models';
import { AuthService } from '../../../core/services/auth.service';
import { ServiceRequestsService } from '../../../core/services/service-requests.service';
import { ConfirmDialogComponent } from '../../../shared/components/confirm-dialog/confirm-dialog.component';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-assign-technician-dialog',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatSelectModule,
    MatSnackBarModule
  ],
  templateUrl: './assign-technician-dialog.component.html',
  styleUrls: ['./assign-technician-dialog.component.scss']
})
export class AssignTechnicianDialogComponent implements OnInit {
  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private serviceRequestsService = inject(ServiceRequestsService);
  private dialog = inject(MatDialog);
  private snackBar = inject(MatSnackBar);
  public dialogRef = inject(MatDialogRef<AssignTechnicianDialogComponent>);

  form: FormGroup;
  technicians$: Observable<any>;

  constructor(@Inject(MAT_DIALOG_DATA) public data: { request: ServiceRequestResponseDto & { vehicleReg?: string } }) {
    this.form = this.fb.group({
      technicianUserName: ['', Validators.required]
    });
    
    // Fetch technicians
    this.technicians$ = this.authService.getUsers(undefined, 'Technician', 1, 100);
  }

  ngOnInit(): void {}

  onCancel(): void {
    this.dialogRef.close(false);
  }

  onSubmit(): void {
    if (this.form.invalid) return;

    const technicianUserName = this.form.value.technicianUserName;

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: 'Confirm Assignment',
        message: 'Are you sure you want to assign this technician to this request?'
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.assignTechnician(technicianUserName);
      }
    });
  }

  private assignTechnician(userName: string): void {
    this.serviceRequestsService.assignTechnician(this.data.request.id, { technicianUserName: userName })
      .subscribe({
        next: () => {
          this.snackBar.open('Technician assigned successfully', 'Close', { duration: 3000 });
          this.dialogRef.close(true);
        },
        error: (err) => {
          console.error('Error assigning technician', err);
          this.snackBar.open('Failed to assign technician', 'Close', { duration: 3000 });
        }
      });
  }
}
