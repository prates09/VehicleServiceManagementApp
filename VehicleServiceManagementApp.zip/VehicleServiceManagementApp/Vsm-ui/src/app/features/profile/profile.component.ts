import { Component, inject, OnInit } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { CustomersService } from '../../core/services/customers.service';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule
  ],
  template: `
    <div class="page-container">
      <div class="profile-wrapper">
        <mat-card class="profile-card">
          <div class="card-header-accent"></div>
          
          <div class="profile-header">
            <div class="avatar">
              {{ authService.userName()?.charAt(0) | uppercase }}
            </div>
            <div class="user-info">
              <h2>{{ authService.userName() }}</h2>
              <span class="role-badge">{{ authService.userRole() }}</span>
            </div>
          </div>

          <div class="card-content">
            <div class="section-title">
              <h3>My Profile</h3>
              <p>Update your personal details</p>
            </div>

            <form [formGroup]="form" (ngSubmit)="onSubmit()">
              <div class="form-grid">
                <mat-form-field appearance="outline">
                  <mat-label>Full Name</mat-label>
                  <mat-icon matPrefix>person</mat-icon>
                  <input matInput formControlName="fullName" placeholder="Ex. John Doe">
                  <mat-error *ngIf="form.get('fullName')?.hasError('required')">
                    Full Name is required
                  </mat-error>
                </mat-form-field>

                <mat-form-field appearance="outline">
                  <mat-label>Email Address</mat-label>
                  <mat-icon matPrefix>email</mat-icon>
                  <input matInput formControlName="email" type="email" placeholder="Ex. john@example.com">
                  <mat-error *ngIf="form.get('email')?.hasError('required')">
                    Email is required
                  </mat-error>
                  <mat-error *ngIf="form.get('email')?.hasError('email')">
                    Please enter a valid email address
                  </mat-error>
                </mat-form-field>

                <mat-form-field appearance="outline">
                  <mat-label>Phone Number</mat-label>
                  <mat-icon matPrefix>phone</mat-icon>
                  <input matInput formControlName="phone" placeholder="Ex. +1 234 567 890">
                  <mat-error *ngIf="form.get('phone')?.hasError('required')">
                    Phone number is required
                  </mat-error>
                </mat-form-field>
              </div>

              <div class="actions">
                <button mat-button type="button" (click)="onCancel()">Cancel</button>
                <button mat-raised-button color="primary" type="submit" 
                        [disabled]="form.invalid || form.pristine">
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .page-container {
      display: flex;
      justify-content: center;
      padding: 2rem;
      min-height: 100%;
      box-sizing: border-box;
    }

    .profile-wrapper {
      width: 100%;
      max-width: 700px;
      animation: fadeIn 0.4s ease-out;
    }

    .profile-card {
      background: #1e293b;
      color: #e2e8f0;
      border-radius: 16px;
      overflow: hidden;
      box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
      position: relative;
    }

    .card-header-accent {
      height: 6px;
      background: linear-gradient(90deg, #3b82f6, #8b5cf6);
      width: 100%;
    }

    .profile-header {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 2.5rem 2rem 1.5rem;
      border-bottom: 1px solid #334155;
      background: rgba(30, 41, 59, 0.5);
    }

    .avatar {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      background: linear-gradient(135deg, #3b82f6, #2563eb);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 2.5rem;
      font-weight: 700;
      margin-bottom: 1rem;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
      text-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .user-info h2 {
      margin: 0;
      font-size: 1.5rem;
      font-weight: 600;
      color: #f8fafc;
      text-align: center;
    }

    .role-badge {
      display: inline-block;
      margin-top: 0.5rem;
      padding: 0.25rem 0.75rem;
      background: #334155;
      color: #94a3b8;
      border-radius: 9999px;
      font-size: 0.75rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      border: 1px solid #475569;
    }

    .card-content {
      padding: 2.5rem;
    }

    .section-title {
      margin-bottom: 2rem;
      text-align: center;
    }

    .section-title h3 {
      margin: 0;
      font-size: 1.25rem;
      font-weight: 600;
      color: #f1f5f9;
    }

    .section-title p {
      margin: 0.5rem 0 0;
      color: #94a3b8;
      font-size: 0.95rem;
    }

    .form-grid {
      display: flex;
      flex-direction: column;
      gap: 1.25rem;
    }

    mat-form-field {
      width: 100%;
    }

    mat-icon {
      color: #94a3b8;
      margin-right: 8px;
    }

    .actions {
      display: flex;
      justify-content: flex-end;
      gap: 1rem;
      margin-top: 2.5rem;
      padding-top: 1.5rem;
      border-top: 1px solid #334155;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }

    @media (max-width: 600px) {
      .page-container {
        padding: 1rem;
      }
      .card-content {
        padding: 1.5rem;
      }
    }
  `]
})
export class ProfileComponent implements OnInit {
  private fb = inject(FormBuilder);
  private customersService = inject(CustomersService);
  private snackBar = inject(MatSnackBar);
  public authService = inject(AuthService);
  private router = inject(Router);

  form = this.fb.group({
    fullName: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    phone: ['', Validators.required]
  });

  ngOnInit() {
    // Only load profile if user is a customer
    if (this.authService.userRole() === 'Customer') {
      this.customersService.getMyProfile().subscribe({
        next: (profile) => {
          this.form.patchValue({
            fullName: profile.fullName,
            email: profile.email,
            phone: profile.phone
          });
        },
        error: (err) => console.error('Error loading profile', err)
      });
    }
  }

  onSubmit() {
    if (this.form.valid) {
      this.customersService.updateMyProfile(this.form.value).subscribe({
        next: () => {
          this.snackBar.open('Profile updated successfully', 'Close', { duration: 3000 });
          this.form.markAsPristine();
        },
        error: (err) => {
          console.error('Error updating profile', err);
          this.snackBar.open('Failed to update profile', 'Close', { duration: 3000 });
        }
      });
    }
  }

  onCancel() {
    this.router.navigate(['/dashboard']);
  }
}
