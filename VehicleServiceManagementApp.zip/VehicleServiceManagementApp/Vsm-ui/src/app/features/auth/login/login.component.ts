import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatIconModule } from '@angular/material/icon';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSnackBarModule,
    MatIconModule,
    RouterLink
  ]
})
export class LoginComponent {
  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private router = inject(Router);
  private snackBar = inject(MatSnackBar);

  form = this.fb.group({
    userName: ['', Validators.required],
    password: ['', Validators.required]
  });

  onSubmit() {
    if (this.form.valid) {
      this.authService.login(this.form.value).subscribe({
        next: () => {
          this.snackBar.open('Login successful', 'Close', {
            duration: 2000,
            horizontalPosition: 'center',
            verticalPosition: 'top'
          });
          this.router.navigate(['/dashboard']);
        },
        error: (err) => {
          console.error('Login error:', err);
          
          // Extract error message safely
          let errorMsg = '';
          if (typeof err.error === 'string') {
            errorMsg = err.error;
          } else if (err.error && typeof err.error === 'object') {
            errorMsg = err.error.message || err.error.error || '';
          }
          
          if (!errorMsg) {
            errorMsg = err.message || '';
          }

          const lowerMsg = errorMsg.toLowerCase();
          
          // Check for inactive account error (401 or 403)
          const isInactive = 
            (err.status === 401 || err.status === 403) && 
            (lowerMsg.includes('inactive') || 
             lowerMsg.includes('disabled') || 
             lowerMsg.includes('deactivated') ||
             lowerMsg.includes('not active') ||
             lowerMsg.includes('locked') ||
             lowerMsg.includes('suspended'));

          if (isInactive) {
            this.snackBar.open('Your account is deactivated. Please contact the administrator.', 'Close', {
              duration: 5000,
              horizontalPosition: 'center',
              verticalPosition: 'top',
              panelClass: ['warning-snackbar']
            });
            // Ensure no stale state remains
            this.authService.logout();
          } else {
            this.snackBar.open('Login failed. Please check your credentials.', 'Close', {
              duration: 3000,
              horizontalPosition: 'center',
              verticalPosition: 'top',
              panelClass: ['error-snackbar']
            });
          }
        }
      });
    }
  }
}
