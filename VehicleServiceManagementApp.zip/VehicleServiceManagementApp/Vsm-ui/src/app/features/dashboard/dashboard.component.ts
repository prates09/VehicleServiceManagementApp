import { Component, inject, OnInit, ViewChild } from '@angular/core';
import { AsyncPipe, CurrencyPipe, DatePipe, CommonModule, TitleCasePipe } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatListModule } from '@angular/material/list';
import { RouterLink } from '@angular/router';
import { Observable, combineLatest, map, of, forkJoin } from 'rxjs';
import { catchError, startWith, switchMap } from 'rxjs/operators';
import { configureTableSorting, sortDataByLatest } from '../../core/utils/table.utils';

import { AuthService } from '../../core/services/auth.service';
import { ReportsService } from '../../core/services/reports.service';
import { ServiceRequestsService } from '../../core/services/service-requests.service';
import { VehiclesService } from '../../core/services/vehicles.service';
import { BillingService } from '../../core/services/billing.service';
import { ServiceCategoriesService } from '../../core/services/service-categories.service';
import { PartsService } from '../../core/services/parts.service';

import { 
  ServiceSummaryReportDto, 
  ServiceRequestResponseDto, 
  VehicleResponseDto, 
  InvoiceResponseDto 
} from '../../core/models/models';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatGridListModule,
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule,
    MatMenuModule,
    MatTooltipModule,
    MatListModule,
    RouterLink,
    AsyncPipe,
    CurrencyPipe,
    DatePipe,
    TitleCasePipe
  ]
})
export class DashboardComponent implements OnInit {
  protected authService = inject(AuthService);
  private reportsService = inject(ReportsService);
  private serviceRequestsService = inject(ServiceRequestsService);
  private vehiclesService = inject(VehiclesService);
  private billingService = inject(BillingService);
  private serviceCategoriesService = inject(ServiceCategoriesService);
  private partsService = inject(PartsService);

  // Admin
  adminStats$: Observable<{ 
    users: number, 
    categories: number, 
    parts: number,
    roleDistribution: { role: string, count: number, color: string }[]
  }> | undefined;

  // Manager
  summary$: Observable<ServiceSummaryReportDto> | undefined;
  unassignedRequests$: Observable<ServiceRequestResponseDto[]> | undefined;
  lowStockParts$: Observable<any[]> | undefined;
  technicianWorkload$: Observable<any[]> | undefined;
  monthlyVolume$: Observable<any[]> | undefined;

  // Technician
  assignedJobs$: Observable<ServiceRequestResponseDto[]> | undefined;
  technicianStats$: Observable<any> | undefined;
  activeJobs$: Observable<ServiceRequestResponseDto[]> | undefined;

  // Customer
  customerRequestsDataSource = new MatTableDataSource<ServiceRequestResponseDto & { vehicleReg?: string }>([]);
  customerVehicles: VehicleResponseDto[] = [];
  customerInvoices: InvoiceResponseDto[] = [];
  isLoadingCustomerData = false;

  customerStats = {
    totalServices: 0,
    activeRequests: 0,
    pendingPayments: 0,
    totalSpent: 0
  };

  customerChartData = {
    statusDistribution: [] as { name: string, value: number, color: string }[],
    spendingHistory: [] as { month: string, amount: number }[]
  };

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  displayedColumnsRequests: string[] = ['id', 'vehicle', 'issue', 'status', 'date'];
  displayedColumnsVehicles: string[] = ['registration', 'make', 'model', 'year'];
  displayedColumnsInvoices: string[] = ['id', 'amount', 'status', 'date'];

  ngOnInit() {
    const role = this.authService.userRole();

    if (role === 'Admin') {
      const roles = ['Admin', 'ServiceManager', 'Technician', 'Customer'];
      const colors = ['#ff9800', '#2196f3', '#4caf50', '#9c27b0'];

      this.adminStats$ = forkJoin({
        usersResponse: this.authService.getUsers(undefined, undefined, 1, 1000),
        categories: this.serviceCategoriesService.getServiceCategories().pipe(map(res => res.length)),
        parts: this.partsService.getParts().pipe(map(res => res.length))
      }).pipe(
        map(data => {
          const allUsers = data.usersResponse.items || [];
          const totalUsers = data.usersResponse.total;
          
          const roleCounts = roles.map((r, index) => {
            const count = allUsers.filter(u => u.roles && u.roles.includes(r)).length;
            return { role: r, count, color: colors[index] };
          });

          return {
            users: totalUsers,
            categories: data.categories,
            parts: data.parts,
            roleDistribution: roleCounts
          };
        })
      );
    }

    if (role === 'ServiceManager') {
      this.summary$ = this.reportsService.getSummary();
      this.unassignedRequests$ = this.serviceRequestsService.getServiceRequests('Requested').pipe(
        map(requests => sortDataByLatest(requests)
          .map(req => ({
            ...req,
            issueDescription: req.issueDescription?.replace(/Preferred Date: \d{1,2}\/\d{1,2}\/\d{4}\s*/, '')
          }))
        )
      );

      // New Reports Data
      this.lowStockParts$ = this.partsService.getLowStockParts().pipe(
        map(parts => parts.slice(0, 5)) // Top 5 only
      );
      this.technicianWorkload$ = this.reportsService.getTechnicianWorkload().pipe(
        map(workload => workload.map(tech => {
          const total = tech.totalAssigned || 0;
          const closed = tech.closed || 0;
          const percentage = total > 0 ? (closed / total) * 100 : 0;
          
          let colorClass = 'progress-red';
          if (percentage >= 80) colorClass = 'progress-green';
          else if (percentage >= 50) colorClass = 'progress-yellow';

          return {
            ...tech,
            percentage,
            colorClass
          };
        }).slice(0, 5))
      );
      this.monthlyVolume$ = this.reportsService.getMonthlyReport(new Date().getFullYear());
    }

    if (role === 'Technician') {
      const userName = this.authService.userName();
      
      // KPI Stats from Workload API
      this.technicianStats$ = this.reportsService.getTechnicianWorkload().pipe(
        map(workload => workload.find(w => w.technicianUserName === userName) || {
          totalAssigned: 0,
          inProgress: 0,
          completed: 0,
          closed: 0
        })
      );

      // Active Jobs (Latest 3)
      this.activeJobs$ = this.serviceRequestsService.getMyAssignedServiceRequests().pipe(
        map(jobs => sortDataByLatest(jobs.filter(j => ['Assigned', 'InProgress'].includes(j.status)))
          .slice(0, 3)
        )
      );
    }

    if (role === 'Customer') {
      this.isLoadingCustomerData = true;
      const requests$ = this.serviceRequestsService.getMyServiceRequests().pipe(catchError(() => of([])));
      const invoices$ = this.billingService.getMyInvoices().pipe(catchError(() => of([])));

      combineLatest([requests$, invoices$]).pipe(
        switchMap(([requests, invoices]) => {
          // Try bulk fetch first
          return this.vehiclesService.getMyVehicles().pipe(
            catchError(() => of([])),
            switchMap(vehicles => {
              if (vehicles.length > 0) return of({ requests, vehicles, invoices });
              
              // Fallback: Fetch individually based on requests
              const vehicleIds = [...new Set(requests.map(r => r.vehicleId))];
              if (vehicleIds.length === 0) return of({ requests, vehicles: [], invoices });
              
              return forkJoin(
                vehicleIds.map(id => this.vehiclesService.getVehicle(id).pipe(catchError(() => of(null))))
              ).pipe(
                map(vs => ({ 
                  requests, 
                  vehicles: vs.filter(v => v !== null) as VehicleResponseDto[], 
                  invoices 
                }))
              );
            })
          );
        }),
        map(({ requests, vehicles, invoices }) => {
          const vehicleMap = new Map(vehicles.map(v => [v.id, v.registrationNumber]));
          
          const enrichedRequests = requests.map(r => ({
            ...r,
            vehicleReg: vehicleMap.get(r.vehicleId) || `Vehicle #${r.vehicleId}`
          }));

          return {
            requests: sortDataByLatest(enrichedRequests),
            vehicles,
            invoices: sortDataByLatest(invoices)
          };
        })
      ).subscribe(data => {
        this.customerRequestsDataSource.data = data.requests;
        this.customerVehicles = data.vehicles;
        this.customerInvoices = data.invoices;
        this.isLoadingCustomerData = false;
        
        this.calculateCustomerStats(data.requests, data.invoices);

        // Use setTimeout to allow the view to update and paginator to be available
        setTimeout(() => {
          this.customerRequestsDataSource.paginator = this.paginator;
        });
      });
    }
  }

  private calculateCustomerStats(requests: ServiceRequestResponseDto[], invoices: InvoiceResponseDto[]) {
    // Summary Cards
    this.customerStats.totalServices = requests.filter(r => r.status === 'Completed' || r.status === 'Closed').length;
    this.customerStats.activeRequests = requests.filter(r => ['Requested', 'Assigned', 'In-Progress'].includes(r.status)).length;
    this.customerStats.pendingPayments = invoices.filter(i => !i.isPaid && i.status !== 'Cancelled').length;
    this.customerStats.totalSpent = invoices.filter(i => i.isPaid).reduce((sum, i) => sum + i.totalAmount, 0);

    // Status Distribution (Pie Chart)
    const statusCounts: {[key: string]: number} = {};
    requests.forEach(r => {
      statusCounts[r.status] = (statusCounts[r.status] || 0) + 1;
    });
    
    const statusColors: {[key: string]: string} = {
      'Requested': '#FFC107', // Amber
      'Assigned': '#2196F3', // Blue
      'In-Progress': '#9C27B0', // Purple
      'Completed': '#4CAF50', // Green
      'Closed': '#607D8B', // Blue Grey
      'Cancelled': '#F44336' // Red
    };

    this.customerChartData.statusDistribution = Object.keys(statusCounts).map(status => ({
      name: status,
      value: statusCounts[status],
      color: statusColors[status] || '#9E9E9E'
    }));

    // Spending History (Bar Chart) - Last 6 months
    const today = new Date();
    const last6Months = Array.from({length: 6}, (_, i) => {
      const d = new Date(today.getFullYear(), today.getMonth() - 5 + i, 1);
      return { 
        month: d.toLocaleString('default', { month: 'short' }), 
        year: d.getFullYear(),
        monthIndex: d.getMonth(),
        amount: 0 
      };
    });

    invoices.filter(i => i.isPaid && i.paidAtUtc).forEach(inv => {
      const paidDate = new Date(inv.paidAtUtc!);
      const monthEntry = last6Months.find(m => m.monthIndex === paidDate.getMonth() && m.year === paidDate.getFullYear());
      if (monthEntry) {
        monthEntry.amount += inv.totalAmount;
      }
    });

    this.customerChartData.spendingHistory = last6Months.map(m => ({
      month: m.month,
      amount: m.amount
    }));
  }

  getConicGradient(data: { name: string, value: number, color: string }[]): string {
    let currentAngle = 0;
    const total = data.reduce((sum, item) => sum + item.value, 0);
    if (total === 0) return 'conic-gradient(#e0e0e0 0% 100%)';

    const parts = data.map(item => {
      const start = currentAngle;
      const angle = (item.value / total) * 360;
      currentAngle += angle;
      return `${item.color} ${start}deg ${currentAngle}deg`;
    });

    return `conic-gradient(${parts.join(', ')})`;
  }

  getMaxSpending(): number {
    return Math.max(...this.customerChartData.spendingHistory.map(i => i.amount), 100);
  }
}
