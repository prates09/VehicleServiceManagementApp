import { Component, inject, OnInit } from '@angular/core';
import { CommonModule, AsyncPipe } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { RouterLink } from '@angular/router';
import { ReportsService } from '../../../../core/services/reports.service';
import { ServiceSummaryReportDto } from '../../../../core/models/models';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-status-report',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    RouterLink,
    AsyncPipe
  ],
  template: `
    <div class="page-container">
      <div class="header">
        <h1>Service Status Report</h1>
        <button mat-button routerLink="/dashboard">Back to Dashboard</button>
      </div>

      @if (summary$ | async; as summary) {
        <div class="stats-grid">
          <mat-card class="stat-card">
            <div class="value">{{summary.total}}</div>
            <div class="label">Total Requests</div>
          </mat-card>
          <mat-card class="stat-card">
            <div class="value">{{summary.requested}}</div>
            <div class="label">New / Requested</div>
          </mat-card>
          <mat-card class="stat-card">
            <div class="value">{{summary.assigned}}</div>
            <div class="label">Assigned</div>
          </mat-card>
          <mat-card class="stat-card">
            <div class="value">{{summary.inProgress}}</div>
            <div class="label">In Progress</div>
          </mat-card>
          <mat-card class="stat-card">
            <div class="value">{{summary.completed}}</div>
            <div class="label">Completed</div>
          </mat-card>
          <mat-card class="stat-card">
            <div class="value">{{summary.closed}}</div>
            <div class="label">Closed</div>
          </mat-card>
          <mat-card class="stat-card">
            <div class="value">{{summary.cancelled}}</div>
            <div class="label">Cancelled</div>
          </mat-card>
        </div>

        <div class="chart-section mat-elevation-z2">
          <h3>Status Distribution</h3>
          <div class="chart-container">
            <!-- Simple CSS Bar Chart for Status -->
            <div class="chart-bar-container">
              <div class="chart-bar" [style.height.%]="getPercentage(summary.requested, summary.total)" title="Requested">
                <span class="bar-value">{{summary.requested}}</span>
              </div>
              <div class="bar-label">Requested</div>
            </div>
            <div class="chart-bar-container">
              <div class="chart-bar" [style.height.%]="getPercentage(summary.assigned, summary.total)" title="Assigned">
                <span class="bar-value">{{summary.assigned}}</span>
              </div>
              <div class="bar-label">Assigned</div>
            </div>
            <div class="chart-bar-container">
              <div class="chart-bar" [style.height.%]="getPercentage(summary.inProgress, summary.total)" title="In Progress">
                <span class="bar-value">{{summary.inProgress}}</span>
              </div>
              <div class="bar-label">In Progress</div>
            </div>
            <div class="chart-bar-container">
              <div class="chart-bar" [style.height.%]="getPercentage(summary.completed, summary.total)" title="Completed">
                <span class="bar-value">{{summary.completed}}</span>
              </div>
              <div class="bar-label">Completed</div>
            </div>
            <div class="chart-bar-container">
              <div class="chart-bar" [style.height.%]="getPercentage(summary.closed, summary.total)" title="Closed">
                <span class="bar-value">{{summary.closed}}</span>
              </div>
              <div class="bar-label">Closed</div>
            </div>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .page-container { padding: 24px; }
    .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 16px; margin-bottom: 24px; }
    .stat-card { padding: 16px; text-align: center; background: #1e293b; color: white; }
    .value { font-size: 24px; font-weight: bold; margin-bottom: 4px; }
    .label { font-size: 12px; color: #94a3b8; }
    
    .chart-section { background: #1e293b; padding: 24px; border-radius: 8px; color: white; }
    .chart-container { display: flex; justify-content: space-around; align-items: flex-end; height: 300px; padding-top: 20px; }
    .chart-bar-container { display: flex; flex-direction: column; align-items: center; height: 100%; width: 60px; }
    .chart-bar { width: 40px; background-color: #3b82f6; border-radius: 4px 4px 0 0; position: relative; min-height: 4px; transition: height 0.3s ease; }
    .bar-value { position: absolute; top: -20px; left: 50%; transform: translateX(-50%); font-size: 12px; color: #cbd5e1; }
    .bar-label { margin-top: 8px; font-size: 12px; color: #94a3b8; text-align: center; }
  `]
})
export class StatusReportComponent implements OnInit {
  private reportsService = inject(ReportsService);
  summary$: Observable<ServiceSummaryReportDto> | undefined;

  ngOnInit() {
    this.summary$ = this.reportsService.getSummary();
  }

  getPercentage(value: number, total: number): number {
    if (!total) return 0;
    return (value / total) * 100;
  }
}
