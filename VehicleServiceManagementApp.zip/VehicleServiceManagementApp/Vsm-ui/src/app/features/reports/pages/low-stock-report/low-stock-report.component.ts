import { Component, inject, OnInit, ViewChild } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouterLink } from '@angular/router';
import { PartsService } from '../../../../core/services/parts.service';
import { PartResponseDto } from '../../../../core/models/models';
import { configureTableSorting } from '../../../../core/utils/table.utils';

@Component({
  selector: 'app-low-stock-report',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    RouterLink,
    CurrencyPipe
  ],
  template: `
    <div class="page-container">
      <div class="header">
        <h1>Low Stock Report</h1>
        <button mat-button routerLink="/dashboard">Back to Dashboard</button>
      </div>

      <mat-form-field appearance="outline" class="search-field">
        <mat-label>Search Parts</mat-label>
        <input matInput (keyup)="applyFilter($event)" placeholder="Ex. Oil Filter" #input>
        <mat-icon matSuffix>search</mat-icon>
      </mat-form-field>

      <div class="table-container mat-elevation-z8">
        <table mat-table [dataSource]="dataSource" matSort>
          
          <ng-container matColumnDef="partNumber">
            <th mat-header-cell *matHeaderCellDef mat-sort-header> Part Number </th>
            <td mat-cell *matCellDef="let element"> {{element.partNumber}} </td>
          </ng-container>

          <ng-container matColumnDef="name">
            <th mat-header-cell *matHeaderCellDef mat-sort-header> Name </th>
            <td mat-cell *matCellDef="let element"> {{element.name}} </td>
          </ng-container>

          <ng-container matColumnDef="stockQty">
            <th mat-header-cell *matHeaderCellDef mat-sort-header> Stock </th>
            <td mat-cell *matCellDef="let element" class="stock-cell"> 
              <span class="stock-badge low">{{element.stockQty}}</span>
            </td>
          </ng-container>

          <ng-container matColumnDef="lowStockThreshold">
            <th mat-header-cell *matHeaderCellDef mat-sort-header> Reorder Level </th>
            <td mat-cell *matCellDef="let element"> {{element.lowStockThreshold}} </td>
          </ng-container>

          <ng-container matColumnDef="unitPrice">
            <th mat-header-cell *matHeaderCellDef mat-sort-header> Unit Price </th>
            <td mat-cell *matCellDef="let element"> {{element.unitPrice | currency:'INR'}} </td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>

          <tr class="mat-row" *matNoDataRow>
            <td class="mat-cell" colspan="5">No low stock items found.</td>
          </tr>
        </table>

        <mat-paginator [pageSizeOptions]="[10, 25, 50]" showFirstLastButtons></mat-paginator>
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 24px; }
    .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
    .search-field { width: 100%; max-width: 400px; margin-bottom: 16px; }
    .stock-badge { padding: 4px 8px; border-radius: 4px; font-weight: bold; }
    .stock-badge.low { background-color: #fee2e2; color: #ef4444; }
    .table-container { overflow: auto; }
    table { width: 100%; }
  `]
})
export class LowStockReportComponent implements OnInit {
  private partsService = inject(PartsService);
  
  dataSource = new MatTableDataSource<PartResponseDto>([]);
  displayedColumns: string[] = ['partNumber', 'name', 'stockQty', 'lowStockThreshold', 'unitPrice'];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.partsService.getParts(undefined, true).subscribe(data => {
      this.dataSource.data = data;
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      configureTableSorting(this.dataSource);
    });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}
