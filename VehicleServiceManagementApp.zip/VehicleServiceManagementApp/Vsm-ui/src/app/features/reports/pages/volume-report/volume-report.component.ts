import { Component, inject, OnInit } from '@angular/core';
import { CommonModule, AsyncPipe } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { RouterLink } from '@angular/router';
import { ReportsService } from '../../../../core/services/reports.service';
import { MonthlyReportDto } from '../../../../core/models/models';
import { Observable, BehaviorSubject } from 'rxjs';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-volume-report',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatSelectModule,
    MatFormFieldModule,
    RouterLink,
    AsyncPipe
  ],
  template: `
    <div class="page-container">
      <div class="header">
        <h1>Monthly Service Volume</h1>
        <button mat-button routerLink="/dashboard">Back to Dashboard</button>
      </div>

      <div class="filters">
        <mat-form-field appearance="outline">
          <mat-label>Year</mat-label>
          <mat-select [value]="selectedYear" (selectionChange)="onYearChange($event.value)">
            <mat-option [value]="2024">2024</mat-option>
            <mat-option [value]="2025">2025</mat-option>
            <mat-option [value]="2026">2026</mat-option>
          </mat-select>
        </mat-form-field>
      </div>

      @if (monthlyData$ | async; as data) {
        <div class="chart-section mat-elevation-z2">
          <h3>Jobs Per Month ({{selectedYear}})</h3>
          <div class="chart-container">
            @for (item of data; track item.month) {
              <div class="chart-bar-container">
                <div class="chart-bar" [style.height.%]="getPercentage(item.total)" [title]="getMonthName(item.month) + ': ' + item.total">
                  <span class="bar-value">{{item.total}}</span>
                </div>
                <div class="bar-label">{{getMonthName(item.month)}}</div>
              </div>
            }
          </div>
        </div>

        <div class="data-grid">
          @for (item of data; track item.month) {
            <mat-card class="month-card">
              <div class="month-title">{{getMonthName(item.month)}}</div>
              <div class="stat-row">
                <span>Total:</span> <strong>{{item.total}}</strong>
              </div>
              <div class="stat-row">
                <span>Completed:</span> <strong>{{item.completed}}</strong>
              </div>
              <div class="stat-row">
                <span>Revenue:</span> <strong>-</strong> <!-- Revenue not in MonthlyReportDto -->
              </div>
            </mat-card>
          }
        </div>
      }
    </div>
  `,
  styles: [`
    .page-container { padding: 24px; }
    .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
    .filters { margin-bottom: 24px; }
    
    .chart-section { background: #1e293b; padding: 24px; border-radius: 8px; color: white; margin-bottom: 24px; }
    .chart-container { display: flex; justify-content: space-between; align-items: flex-end; height: 300px; padding-top: 20px; gap: 8px; }
    .chart-bar-container { display: flex; flex-direction: column; align-items: center; height: 100%; flex: 1; }
    .chart-bar { width: 60%; background-color: #8b5cf6; border-radius: 4px 4px 0 0; position: relative; min-height: 4px; transition: height 0.3s ease; }
    .bar-value { position: absolute; top: -20px; left: 50%; transform: translateX(-50%); font-size: 12px; color: #cbd5e1; }
    .bar-label { margin-top: 8px; font-size: 12px; color: #94a3b8; text-align: center; }

    .data-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 16px; }
    .month-card { padding: 16px; background: #1e293b; color: white; }
    .month-title { font-size: 18px; font-weight: bold; margin-bottom: 12px; color: #8b5cf6; }
    .stat-row { display: flex; justify-content: space-between; margin-bottom: 4px; font-size: 14px; color: #cbd5e1; }
  `]
})
export class VolumeReportComponent implements OnInit {
  private reportsService = inject(ReportsService);
  
  selectedYear = new Date().getFullYear();
  yearSubject = new BehaviorSubject<number>(this.selectedYear);
  monthlyData$: Observable<MonthlyReportDto[]> | undefined;

  ngOnInit() {
    this.monthlyData$ = this.yearSubject.pipe(
      switchMap(year => this.reportsService.getMonthlyReport(year))
    );
  }

  onYearChange(year: number) {
    this.selectedYear = year;
    this.yearSubject.next(year);
  }

  getMonthName(month: number): string {
    return new Date(0, month - 1).toLocaleString('default', { month: 'short' });
  }

  getPercentage(value: number): number {
    // Assuming max 100 jobs per month for scaling, or dynamic max would be better
    // For simplicity, let's use a fixed max or try to find max from data if possible.
    // Since we are in template, we can't easily get max of observable. 
    // Let's assume 50 is a good baseline max for now, or 100.
    return Math.min((value / 50) * 100, 100); 
  }
}
