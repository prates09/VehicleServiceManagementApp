import { Component, inject, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatButtonModule } from '@angular/material/button';
import { RouterLink } from '@angular/router';
import { ReportsService } from '../../../../core/services/reports.service';
import { TechnicianWorkloadDto } from '../../../../core/models/models';
import { configureTableSorting } from '../../../../core/utils/table.utils';

@Component({
  selector: 'app-workload-report',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatButtonModule,
    RouterLink
  ],
  template: `
    <div class="page-container">
      <div class="header">
        <h1>Technician Workload Report</h1>
        <button mat-button routerLink="/dashboard">Back to Dashboard</button>
      </div>

      <div class="chart-section mat-elevation-z2">
        <h3>Workload Distribution</h3>
        <div class="chart-container">
           <!-- Simple CSS Bar Chart -->
           @for (item of dataSource.data; track item.technicianUserId) {
             <div class="chart-row">
               <div class="label">{{item.technicianUserName}}</div>
               <div class="bars">
                 <div class="bar assigned" [style.width.%]="getPercentage(item.totalAssigned - item.closed, item)" [title]="'Active: ' + (item.totalAssigned - item.closed)"></div>
                 <div class="bar closed" [style.width.%]="getPercentage(item.closed, item)" [title]="'Closed: ' + item.closed"></div>
               </div>
               <div class="values">
                 <span>{{item.totalAssigned}} / {{item.closed}}</span>
               </div>
             </div>
           }
        </div>
        <div class="legend">
          <span class="dot assigned"></span> Assigned
          <span class="dot closed"></span> Closed
        </div>
      </div>

      <div class="table-container mat-elevation-z8">
        <table mat-table [dataSource]="dataSource" matSort>
          
          <ng-container matColumnDef="technicianUserName">
            <th mat-header-cell *matHeaderCellDef mat-sort-header> Technician </th>
            <td mat-cell *matCellDef="let element"> {{element.technicianUserName}} </td>
          </ng-container>

          <ng-container matColumnDef="totalAssigned">
            <th mat-header-cell *matHeaderCellDef mat-sort-header> Total Assigned </th>
            <td mat-cell *matCellDef="let element"> {{element.totalAssigned}} </td>
          </ng-container>

          <ng-container matColumnDef="inProgress">
            <th mat-header-cell *matHeaderCellDef mat-sort-header> In Progress </th>
            <td mat-cell *matCellDef="let element"> {{element.inProgress}} </td>
          </ng-container>

          <ng-container matColumnDef="closed">
            <th mat-header-cell *matHeaderCellDef mat-sort-header> Closed </th>
            <td mat-cell *matCellDef="let element"> {{element.closed}} </td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
        </table>

        <mat-paginator [pageSizeOptions]="[10, 25, 50]" showFirstLastButtons></mat-paginator>
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 24px; }
    .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
    .chart-section { background: #1e293b; padding: 20px; border-radius: 8px; margin-bottom: 24px; color: white; }
    .chart-container { display: flex; flex-direction: column; gap: 12px; margin-top: 16px; }
    .chart-row { display: flex; align-items: center; gap: 16px; }
    .label { width: 150px; font-size: 14px; }
    .bars { flex: 1; display: flex; height: 20px; background: #334155; border-radius: 4px; overflow: hidden; }
    .bar { height: 100%; transition: width 0.3s ease; }
    .bar.assigned { background-color: #60a5fa; }
    .bar.closed { background-color: #4ade80; }
    .values { width: 80px; text-align: right; font-size: 12px; color: #94a3b8; }
    .legend { display: flex; gap: 16px; margin-top: 16px; font-size: 12px; color: #94a3b8; justify-content: flex-end; }
    .dot { width: 10px; height: 10px; border-radius: 50%; display: inline-block; margin-right: 4px; }
    .dot.assigned { background-color: #60a5fa; }
    .dot.closed { background-color: #4ade80; }
    table { width: 100%; }
  `]
})
export class WorkloadReportComponent implements OnInit {
  private reportsService = inject(ReportsService);
  
  dataSource = new MatTableDataSource<TechnicianWorkloadDto>([]);
  displayedColumns: string[] = ['technicianUserName', 'totalAssigned', 'inProgress', 'closed'];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  ngOnInit() {
    this.reportsService.getTechnicianWorkload().subscribe(data => {
      this.dataSource.data = data;
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      configureTableSorting(this.dataSource);
    });
  }

  getPercentage(value: number, item: TechnicianWorkloadDto): number {
    const total = item.totalAssigned || 0;
    return total > 0 ? (value / total) * 100 : 0;
  }
}
