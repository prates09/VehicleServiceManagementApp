import { Component, inject, OnInit, ViewChild } from '@angular/core';
import { AsyncPipe, CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { ReportsService } from '../../core/services/reports.service';
import { ServiceSummaryReportDto, TechnicianWorkloadDto } from '../../core/models/models';
import { Observable } from 'rxjs';
import { configureTableSorting } from '../../core/utils/table.utils';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrl: './reports.component.scss',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatGridListModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    AsyncPipe
  ]
})
export class ReportsComponent implements OnInit {
  private reportsService = inject(ReportsService);
  
  summary$: Observable<ServiceSummaryReportDto> | undefined;
  dataSource = new MatTableDataSource<TechnicianWorkloadDto>([]);
  
  workloadColumns: string[] = ['technician', 'assigned', 'inProgress', 'completed', 'closed'];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  ngOnInit() {
    this.summary$ = this.reportsService.getSummary();
    this.reportsService.getTechnicianWorkload().subscribe(data => {
      this.dataSource.data = data;
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      configureTableSorting(this.dataSource);
    });
  }
}
