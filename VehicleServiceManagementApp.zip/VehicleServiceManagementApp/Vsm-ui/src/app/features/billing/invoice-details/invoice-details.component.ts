import { Component, inject, OnInit } from '@angular/core';
import { CommonModule, CurrencyPipe, DatePipe } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatChipsModule } from '@angular/material/chips';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { BillingService } from '../../../core/services/billing.service';
import { AuthService } from '../../../core/services/auth.service';
import { InvoiceResponseDto, PayInvoiceRequestDto } from '../../../core/models/models';
import { PaymentDialogComponent } from '../payment-dialog/payment-dialog.component';

@Component({
  selector: 'app-invoice-details',
  templateUrl: './invoice-details.component.html',
  styleUrl: './invoice-details.component.scss',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatButtonModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatChipsModule,
    MatDividerModule,
    MatIconModule,
    MatDialogModule,
    MatSnackBarModule,
    RouterLink,
    CurrencyPipe,
    DatePipe
  ]
})
export class InvoiceDetailsComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private billingService = inject(BillingService);
  private dialog = inject(MatDialog);
  private snackBar = inject(MatSnackBar);
  protected authService = inject(AuthService);
  private fb = inject(FormBuilder);

  invoice: InvoiceResponseDto | null = null;
  paymentForm: FormGroup;
  displayedColumns: string[] = ['itemType', 'itemName', 'quantity', 'unitPrice', 'lineTotal'];

  constructor() {
    this.paymentForm = this.fb.group({
      paymentReference: ['', Validators.required]
    });
  }

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.loadInvoice(+id);
    }
  }

  loadInvoice(id: number) {
    this.billingService.getInvoice(id).subscribe(invoice => {
      this.invoice = invoice;
    });
  }

  onPay() {
    if (this.paymentForm.valid && this.invoice) {
      const req: PayInvoiceRequestDto = this.paymentForm.value;
      this.billingService.payInvoice(this.invoice.id, req).subscribe(updatedInvoice => {
        this.invoice = updatedInvoice;
        this.paymentForm.reset();
      });
    }
  }

  onCustomerPay() {
    if (this.invoice) {
      const dialogRef = this.dialog.open(PaymentDialogComponent, {
        width: '400px',
        data: { 
          invoiceId: this.invoice.id,
          amount: this.invoice.totalAmount 
        },
        disableClose: true
      });

      dialogRef.afterClosed().subscribe((result: InvoiceResponseDto | undefined) => {
        if (result) {
          // Payment successful, update invoice state
          this.invoice = result;
          this.snackBar.open('Payment successful! Thank you.', 'Close', {
            duration: 5000,
            panelClass: ['success-snackbar']
          });
        }
      });
    }
  }
}
