import { Component, inject, OnInit, ViewChild } from '@angular/core';
import { AsyncPipe, CurrencyPipe, DatePipe } from '@angular/common';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';
import { BillingService } from '../../../core/services/billing.service';
import { AuthService } from '../../../core/services/auth.service';
import { InvoiceResponseDto } from '../../../core/models/models';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { configureTableSorting, sortDataByLatest } from '../../../core/utils/table.utils';
import { InvoiceDetailsDialogComponent } from '../invoice-details-dialog/invoice-details-dialog.component';

@Component({
  selector: 'app-invoice-list',
  templateUrl: './invoice-list.component.html',
  styleUrl: './invoice-list.component.scss',
  standalone: true,
  imports: [
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    FormsModule,
    CurrencyPipe,
    DatePipe
  ]
})
export class InvoiceListComponent implements OnInit {
  private billingService = inject(BillingService);
  private authService = inject(AuthService);
  private dialog = inject(MatDialog);

  dataSource = new MatTableDataSource<InvoiceResponseDto>([]);
  displayedColumns: string[] = ['id', 'serviceRequestId', 'totalAmount', 'createdAt', 'isPaid', 'actions'];
  
  isLoading = true;
  
  // Summary Data
  totalInvoices = 0;
  totalAmountPaid = 0;
  pendingPayments = 0;

  // Filters
  searchQuery = '';
  statusFilter = 'All';

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  ngOnInit() {
    const role = this.authService.userRole();
    let invoices$: Observable<InvoiceResponseDto[]>;

    if (role === 'Customer') {
      invoices$ = this.billingService.getMyInvoices().pipe(catchError(() => of([])));
    } else {
      invoices$ = this.billingService.getInvoices().pipe(catchError(() => of([])));
    }

    invoices$.subscribe(data => {
      this.dataSource.data = sortDataByLatest(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      
      // Custom filter predicate
      this.dataSource.filterPredicate = (data: InvoiceResponseDto, filter: string) => {
        const filterState = JSON.parse(filter);
        const searchStr = filterState.search;
        const status = filterState.status;

        const matchesSearch = 
          data.id.toString().includes(searchStr) || 
          data.serviceRequestId.toString().includes(searchStr);
          
        const matchesStatus = 
          status === 'All' || 
          (status === 'Paid' && data.isPaid) || 
          (status === 'Pending' && !data.isPaid);

        return matchesSearch && matchesStatus;
      };

      configureTableSorting(this.dataSource);
      this.calculateSummary(data);
      this.isLoading = false;
      this.applyFilter(); // Apply initial filter state
    });
  }

  calculateSummary(data: InvoiceResponseDto[]) {
    this.totalInvoices = data.length;
    this.totalAmountPaid = data
      .filter(i => i.isPaid)
      .reduce((sum, i) => sum + i.totalAmount, 0);
    this.pendingPayments = data
      .filter(i => !i.isPaid)
      .reduce((sum, i) => sum + i.totalAmount, 0);
  }

  applyFilter() {
    const filterState = {
      search: this.searchQuery.trim().toLowerCase(),
      status: this.statusFilter
    };
    this.dataSource.filter = JSON.stringify(filterState);
    
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  openDetails(invoice: InvoiceResponseDto) {
    this.dialog.open(InvoiceDetailsDialogComponent, {
      data: { invoiceId: invoice.id },
      width: '600px',
      panelClass: 'invoice-details-dialog'
    });
  }
}
