import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule, CurrencyPipe, DatePipe } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatChipsModule } from '@angular/material/chips';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { InvoiceResponseDto } from '../../../core/models/models';
import { BillingService } from '../../../core/services/billing.service';

@Component({
  selector: 'app-invoice-details-dialog',
  template: `
    <div class="dialog-container" *ngIf="invoice">
      <div class="dialog-header">
        <div class="header-content">
          <h2 mat-dialog-title>Invoice #{{invoice.id}}</h2>
          <span class="status-chip" [class.paid]="invoice.isPaid" [class.pending]="!invoice.isPaid">
            {{invoice.isPaid ? 'Paid' : 'Pending'}}
          </span>
        </div>
        <button mat-icon-button mat-dialog-close>
          <mat-icon>close</mat-icon>
        </button>
      </div>

      <mat-dialog-content>
        <div class="info-grid">
          <div class="info-item">
            <span class="label">Service Request</span>
            <span class="value">#{{invoice.serviceRequestId}}</span>
          </div>
          <div class="info-item">
            <span class="label">Date</span>
            <span class="value">{{invoice.generatedAtUtc | date:'mediumDate'}}</span>
          </div>
          <div class="info-item" *ngIf="invoice.paidAtUtc">
            <span class="label">Paid On</span>
            <span class="value">{{invoice.paidAtUtc | date:'mediumDate'}}</span>
          </div>
          <div class="info-item" *ngIf="invoice.paymentReference">
            <span class="label">Reference</span>
            <span class="value">{{invoice.paymentReference}}</span>
          </div>
        </div>

        <mat-divider class="divider"></mat-divider>

        <table mat-table [dataSource]="invoice.lines || []" class="details-table">
          <ng-container matColumnDef="item">
            <th mat-header-cell *matHeaderCellDef> Item </th>
            <td mat-cell *matCellDef="let item"> 
              <div class="item-name">{{item.itemName}}</div>
              <div class="item-type">{{item.itemType}}</div>
            </td>
          </ng-container>

          <ng-container matColumnDef="qty">
            <th mat-header-cell *matHeaderCellDef> Qty </th>
            <td mat-cell *matCellDef="let item"> {{item.quantity}} </td>
          </ng-container>

          <ng-container matColumnDef="price">
            <th mat-header-cell *matHeaderCellDef> Price </th>
            <td mat-cell *matCellDef="let item"> {{item.unitPrice | currency:'INR'}} </td>
          </ng-container>

          <ng-container matColumnDef="total">
            <th mat-header-cell *matHeaderCellDef> Total </th>
            <td mat-cell *matCellDef="let item"> {{item.lineTotal | currency:'INR'}} </td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="['item', 'qty', 'price', 'total']"></tr>
          <tr mat-row *matRowDef="let row; columns: ['item', 'qty', 'price', 'total']"></tr>
        </table>

        <div class="totals-section">
          <div class="total-row">
            <span>Labor Charge</span>
            <span>{{invoice.laborCharge | currency:'INR'}}</span>
          </div>
          <div class="total-row">
            <span>Parts Total</span>
            <span>{{invoice.partsTotal | currency:'INR'}}</span>
          </div>
          <div class="total-row">
            <span>Tax ({{invoice.taxRate * 100}}%)</span>
            <span>{{invoice.taxAmount | currency:'INR'}}</span>
          </div>
          <div class="total-row grand-total">
            <span>Total Amount</span>
            <span>{{invoice.totalAmount | currency:'INR'}}</span>
          </div>
        </div>
      </mat-dialog-content>

      <mat-dialog-actions align="end">
        <button mat-button mat-dialog-close>Close</button>
      </mat-dialog-actions>
    </div>
  `,
  styles: [`
    .dialog-container {
      min-width: 500px;
      max-width: 800px;
    }
    .dialog-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 16px 24px;
      border-bottom: 1px solid rgba(255,255,255,0.1);
      
      h2 { margin: 0; font-size: 1.5rem; }
    }
    .header-content {
      display: flex;
      align-items: center;
      gap: 16px;
    }
    .status-chip {
      padding: 4px 12px;
      border-radius: 16px;
      font-size: 0.85rem;
      font-weight: 500;
      
      &.paid { background: rgba(74, 222, 128, 0.1); color: #4ade80; }
      &.pending { background: rgba(251, 146, 60, 0.1); color: #fb923c; }
    }
    .info-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 16px;
      padding: 24px 0;
    }
    .info-item {
      display: flex;
      flex-direction: column;
      gap: 4px;
      
      .label { color: #94a3b8; font-size: 0.85rem; }
      .value { color: #e2e8f0; font-weight: 500; }
    }
    .divider { margin: 0 0 24px 0; }
    .details-table {
      width: 100%;
      background: transparent;
      margin-bottom: 24px;
      
      th { color: #94a3b8; font-weight: 500; border-bottom-color: rgba(255,255,255,0.1); }
      td { color: #e2e8f0; border-bottom-color: rgba(255,255,255,0.05); padding: 12px 0; }
      
      .item-name { font-weight: 500; }
      .item-type { font-size: 0.8rem; color: #94a3b8; }
    }
    .totals-section {
      background: rgba(255,255,255,0.03);
      padding: 16px;
      border-radius: 8px;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    .total-row {
      display: flex;
      justify-content: space-between;
      color: #cbd5e1;
      font-size: 0.9rem;
      
      &.grand-total {
        margin-top: 8px;
        padding-top: 8px;
        border-top: 1px solid rgba(255,255,255,0.1);
        color: #e2e8f0;
        font-weight: 600;
        font-size: 1.1rem;
      }
    }
  `],
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatTableModule,
    MatChipsModule,
    MatDividerModule,
    MatIconModule,
    CurrencyPipe,
    DatePipe
  ]
})
export class InvoiceDetailsDialogComponent implements OnInit {
  invoice: InvoiceResponseDto | null = null;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { invoiceId: number },
    private billingService: BillingService
  ) {}

  ngOnInit() {
    if (this.data.invoiceId) {
      this.billingService.getInvoice(this.data.invoiceId).subscribe(inv => {
        this.invoice = inv;
      });
    }
  }
}
