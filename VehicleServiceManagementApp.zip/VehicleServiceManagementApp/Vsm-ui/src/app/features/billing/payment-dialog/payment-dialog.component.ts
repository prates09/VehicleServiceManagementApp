import { Component, Inject, inject } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatRadioModule } from '@angular/material/radio';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { FormsModule } from '@angular/forms';
import { BillingService } from '../../../core/services/billing.service';
import { InvoiceResponseDto } from '../../../core/models/models';

export interface PaymentDialogData {
  invoiceId: number;
  amount: number;
}

@Component({
  selector: 'app-payment-dialog',
  templateUrl: './payment-dialog.component.html',
  styleUrl: './payment-dialog.component.scss',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatRadioModule,
    MatProgressSpinnerModule,
    FormsModule,
    CurrencyPipe
  ]
})
export class PaymentDialogComponent {
  private billingService = inject(BillingService);
  private snackBar = inject(MatSnackBar);

  selectedMethod: string = 'UPI';
  amount: number;
  isLoading = false;

  paymentMethods = [
    { value: 'UPI', label: 'UPI', description: 'Google Pay, PhonePe, Paytm' },
    { value: 'Card', label: 'Credit / Debit Card', description: 'Visa, Mastercard, RuPay' },
    { value: 'NetBanking', label: 'Net Banking', description: 'All major banks supported' }
  ];

  constructor(
    public dialogRef: MatDialogRef<PaymentDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: PaymentDialogData
  ) {
    this.amount = data.amount;
  }

  onCancel(): void {
    if (!this.isLoading) {
      this.dialogRef.close();
    }
  }

  onPay(): void {
    if (this.isLoading) return;
    
    this.isLoading = true;
    const paymentReference = `${this.selectedMethod}-${new Date().getTime()}`;
    
    this.billingService.payInvoice(this.data.invoiceId, { paymentReference }).subscribe({
      next: (updatedInvoice: InvoiceResponseDto) => {
        this.isLoading = false;
        this.dialogRef.close(updatedInvoice);
      },
      error: (err) => {
        this.isLoading = false;
        console.error('Payment error', err);
        this.snackBar.open('Payment failed. Please try again later.', 'Close', {
          duration: 5000,
          panelClass: ['error-snackbar']
        });
      }
    });
  }
}
