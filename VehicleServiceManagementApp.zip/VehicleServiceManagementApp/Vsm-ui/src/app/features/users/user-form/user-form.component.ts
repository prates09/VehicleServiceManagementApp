import { Component, inject, OnInit } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink, ActivatedRoute } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatIconModule } from '@angular/material/icon';
import { AuthService } from '../../../core/services/auth.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrl: './user-form.component.scss',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    RouterLink
  ]
})
export class UserFormComponent implements OnInit {
  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private snackBar = inject(MatSnackBar);

  isLoading = false;
  isEditMode = false;
  userName: string | null = null;
  roles = ['Customer', 'ServiceManager', 'Technician'];

  form = this.fb.group({
    userName: ['', Validators.required],
    fullName: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    phoneNumber: ['', [Validators.pattern(/^\+?[0-9]{10,15}$/)]],
    role: ['Customer', Validators.required],
    password: ['Password@123!', [Validators.required, Validators.minLength(6)]]
  });

  ngOnInit() {
    this.userName = this.route.snapshot.paramMap.get('id'); // Route param is still 'id' but we treat it as username
    if (this.userName) {
      this.isEditMode = true;
      this.loadUser(this.userName);
      this.form.get('password')?.clearValidators();
      this.form.get('password')?.updateValueAndValidity();
      this.form.get('role')?.disable(); // Disable role editing in edit mode as per requirement
    }
  }

  loadUser(userName: string) {
    this.isLoading = true;
    this.authService.getUser(userName).subscribe({
      next: (user) => {
        this.form.patchValue({
          userName: user.userName,
          fullName: user.fullName,
          email: user.email,
          phoneNumber: user.phoneNumber,
          role: user.roles?.[0] || 'Customer'
        });
        this.form.get('userName')?.disable(); // Can't change username
        this.isLoading = false;
      },
      error: (err) => {
        console.error(err);
        this.snackBar.open('Failed to load user', 'Close', { duration: 3000 });
        this.router.navigate(['/users']);
      }
    });
  }

  onSubmit() {
    if (this.form.valid) {
      this.isLoading = true;
      if (this.isEditMode && this.userName) {
        this.updateUser();
      } else {
        this.createUser();
      }
    }
  }

  createUser() {
    const { userName, email, password, role, fullName, phoneNumber } = this.form.value;

    // 1. Register the user
    this.authService.register({
      userName,
      password: password,
      fullName,
      email,
      phone: phoneNumber
    }).subscribe({
      next: () => {
        // 2. Assign Role
        if (role && role !== 'Customer') {
           this.assignRole(email!, role);
        } else {
           this.showSuccess('User created successfully');
        }
      },
      error: (err) => {
        this.isLoading = false;
        console.error(err);
        let msg = 'Failed to create user';
        if (err.error && typeof err.error === 'string') msg = err.error;
        else if (err.error?.description) msg = err.error.description;
        
        this.snackBar.open(msg, 'Close', { duration: 5000 });
      }
    });
  }

  updateUser() {
    const { fullName, email, phoneNumber } = this.form.value;
    const updateData = { fullName, email, phoneNumber };
    
    this.authService.updateUser(this.userName!, updateData).subscribe({
      next: () => {
        this.showSuccess('User updated successfully');
      },
      error: (err) => {
        this.isLoading = false;
        console.error(err);
        this.snackBar.open('Failed to update user', 'Close', { duration: 3000 });
      }
    });
  }

  assignRole(userName: string, role: string) {
    this.authService.setUserRole(userName, { role }).subscribe({
      next: () => this.showSuccess('User created successfully'),
      error: (err) => {
        console.error(err);
        this.snackBar.open('User created but failed to assign role', 'Close', { duration: 5000 });
        this.router.navigate(['/users']);
      }
    });
  }

  showSuccess(message: string) {
    this.snackBar.open(message, 'Close', { duration: 3000 });
    this.router.navigate(['/users']);
  }
}
