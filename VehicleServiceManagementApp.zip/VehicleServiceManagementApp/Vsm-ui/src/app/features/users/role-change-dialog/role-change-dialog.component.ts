import { Component, Inject, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule } from '@angular/forms';
import { UserListItemDto } from '../../../core/models/models';

export interface RoleChangeDialogData {
  user: UserListItemDto;
  currentRole: string;
}

@Component({
  selector: 'app-role-change-dialog',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatSelectModule,
    MatFormFieldModule,
    FormsModule
  ],
  template: `
    <h2 mat-dialog-title>Change Role</h2>
    <mat-dialog-content>
      <div class="user-details">
        <p><strong>User:</strong> {{ data.user.userName }}</p>
        <p><strong>Current Role:</strong> {{ data.currentRole }}</p>
      </div>

      <mat-form-field appearance="outline" class="full-width">
        <mat-label>New Role</mat-label>
        <mat-select [(ngModel)]="selectedRole" (selectionChange)="onRoleSelect()">
          @for (role of roles; track role) {
            <mat-option [value]="role" [disabled]="role === data.currentRole">
              {{ role }}
            </mat-option>
          }
        </mat-select>
      </mat-form-field>

      @if (showWarning) {
        <div class="warning-box">
          <p class="warning-text">
            <strong>Warning:</strong> Changing the role to <strong>{{ selectedRole }}</strong> might affect the user's access and assigned tasks.
            Are you sure you want to proceed?
          </p>
        </div>
      }
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button mat-dialog-close>Cancel</button>
      <button mat-raised-button color="primary" 
              [disabled]="!selectedRole || selectedRole === data.currentRole"
              (click)="confirm()">
        {{ showWarning ? 'Confirm Change' : 'Change Role' }}
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    .user-details {
      margin-bottom: 16px;
      p { margin: 4px 0; }
    }
    .full-width {
      width: 100%;
      margin-bottom: 8px;
    }
    .warning-box {
      background-color: rgba(239, 68, 68, 0.1);
      border: 1px solid rgba(239, 68, 68, 0.3);
      border-radius: 8px;
      padding: 12px;
      margin-top: 8px;
    }
    .warning-text {
      color: #ef4444;
      margin: 0;
      font-size: 14px;
    }
  `]
})
export class RoleChangeDialogComponent {
  readonly data = inject<RoleChangeDialogData>(MAT_DIALOG_DATA);
  readonly dialogRef = inject(MatDialogRef<RoleChangeDialogComponent>);

  roles = ['ServiceManager', 'Technician', 'Customer'];
  selectedRole = '';
  showWarning = false;

  onRoleSelect() {
    this.showWarning = true;
  }

  confirm() {
    this.dialogRef.close(this.selectedRole);
  }
}
