import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { AuthService } from '../../../core/services/auth.service';
import { UserListItemDto } from '../../../core/models/models';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ViewChild } from '@angular/core';
import { configureTableSorting, sortDataByLatest } from '../../../core/utils/table.utils';
import { ConfirmDialogComponent } from '../../../shared/components/confirm-dialog/confirm-dialog.component';
import { RoleChangeDialogComponent } from '../role-change-dialog/role-change-dialog.component';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrl: './user-list.component.scss',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    RouterLink
  ]
})
export class UserListComponent implements OnInit {
  private authService = inject(AuthService);
  private snackBar = inject(MatSnackBar);
  private dialog = inject(MatDialog);

  dataSource = new MatTableDataSource<UserListItemDto>([]);
  displayedColumns: string[] = ['userName', 'fullName', 'email', 'role', 'status', 'actions'];
  
  totalUsers = 0;
  pageSize = 10;
  pageIndex = 0;

  @ViewChild(MatSort) sort!: MatSort;

  ngOnInit() {
    configureTableSorting(this.dataSource);
    this.loadUsers();
  }

  loadUsers() {
    // API uses 1-based page index
    this.authService.getUsers(undefined, undefined, this.pageIndex + 1, this.pageSize).subscribe({
      next: (res) => {
        const filteredUsers = (res.items || []).filter(u => !u.roles?.includes('Admin'));
        
        // Ensure only one role is displayed (prefer non-Customer role)
        filteredUsers.forEach(u => {
          if (u.roles && u.roles.length > 1) {
            const nonCustomerRole = u.roles.find(r => r !== 'Customer');
            if (nonCustomerRole) {
              u.roles = [nonCustomerRole];
            }
          }
        });

        this.dataSource.data = sortDataByLatest(filteredUsers);
        this.dataSource.sort = this.sort;
        this.totalUsers = res.total || 0;
      },
      error: (err) => console.error(err)
    });
  }

  onPageChange(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.loadUsers();
  }

  openRoleDialog(user: UserListItemDto) {
    if (!user.userName) return;

    const currentRole = user.roles?.[0] || 'Customer';
    
    const dialogRef = this.dialog.open(RoleChangeDialogComponent, {
      width: '400px',
      data: {
        user: user,
        currentRole: currentRole
      }
    });

    dialogRef.afterClosed().subscribe(newRole => {
      if (newRole) {
        this.authService.setUserRole(user.userName!, { role: newRole }).subscribe({
          next: () => {
            this.snackBar.open(`Role updated to ${newRole}`, 'Close', { duration: 3000 });
            this.loadUsers();
          },
          error: (err) => {
            console.error(err);
            this.snackBar.open('Failed to update role', 'Close', { duration: 3000 });
          }
        });
      }
    });
  }

  toggleUserStatus(user: UserListItemDto) {
    if (!user.id || !user.userName) return;

    // Prevent self-deactivation
    const currentUserName = this.authService.userName();
    if (user.userName === currentUserName) {
      this.snackBar.open('You cannot deactivate your own account.', 'Close', { duration: 3000 });
      return;
    }

    const action = user.isActive ? 'deactivate' : 'activate';
    const message = user.isActive 
      ? `Are you sure you want to deactivate user ${user.userName}? They will not be able to login.`
      : `Activate user ${user.userName} and restore login access?`;

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: `${action === 'activate' ? 'Activate' : 'Deactivate'} User`,
        message: message
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.authService.toggleUserStatus(user.id!).subscribe({
          next: () => {
            const statusMsg = user.isActive ? 'deactivated' : 'activated';
            this.snackBar.open(`User ${statusMsg} successfully`, 'Close', { duration: 3000 });
            this.loadUsers();
          },
          error: (err) => {
            console.error(err);
            this.snackBar.open(`Failed to ${action} user`, 'Close', { duration: 3000 });
          }
        });
      }
    });
  }
}
