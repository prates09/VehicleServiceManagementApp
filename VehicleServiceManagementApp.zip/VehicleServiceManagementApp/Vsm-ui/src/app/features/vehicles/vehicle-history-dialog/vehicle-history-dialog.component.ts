import { Component, Inject, inject, OnInit, signal } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { DatePipe } from '@angular/common';
import { VehicleHistoryDto, VehicleResponseDto, ServiceRequestResponseDto } from '../../../core/models/models';
import { ServiceRequestsService } from '../../../core/services/service-requests.service';
import { AuthService } from '../../../core/services/auth.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-vehicle-history-dialog',
  templateUrl: './vehicle-history-dialog.component.html',
  styleUrl: './vehicle-history-dialog.component.scss',
  standalone: true,
  imports: [
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule,
    DatePipe
  ]
})
export class VehicleHistoryDialogComponent implements OnInit {
  private serviceRequestsService = inject(ServiceRequestsService);
  private authService = inject(AuthService);

  history = signal<VehicleHistoryDto[]>([]);
  loading = signal<boolean>(true);
  error = signal<string | null>(null);

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { vehicle: VehicleResponseDto }
  ) {}

  ngOnInit() {
    this.loadHistory();
  }

  loadHistory() {
    this.loading.set(true);
    this.error.set(null);

    const role = this.authService.userRole();
    let requests$: Observable<ServiceRequestResponseDto[]>;

    // Use existing ServiceRequest endpoints as a fallback since Reports endpoint might be missing
    if (role === 'Customer') {
      requests$ = this.serviceRequestsService.getMyServiceRequests();
    } else {
      // For Admin/Manager, fetch by customer ID
      requests$ = this.serviceRequestsService.getServiceRequestsByCustomer(this.data.vehicle.customerId);
    }

    requests$.subscribe({
      next: (allRequests) => {
        // Filter for this specific vehicle
        const vehicleRequests = allRequests.filter(r => r.vehicleId === this.data.vehicle.id);
        
        // Map to VehicleHistoryDto format
        const historyItems: VehicleHistoryDto[] = vehicleRequests.map(r => ({
          id: r.id,
          vehicleId: r.vehicleId,
          customerId: r.customerId,
          issueDescription: r.issueDescription,
          priority: r.priority,
          status: r.status,
          remarks: r.remarks,
          requestedAtUtc: r.createdAt || new Date().toISOString(),
          scheduledAtUtc: null,
          completedAtUtc: r.status === 'Completed' || r.status === 'Closed' ? r.createdAt : null, // Approximate if not available
          closedAtUtc: null,
          cancelledAtUtc: null
        }));

        // Sort by date descending (newest first)
        const sorted = historyItems.sort((a, b) => 
          new Date(b.requestedAtUtc).getTime() - new Date(a.requestedAtUtc).getTime()
        );
        
        this.history.set(sorted);
        this.loading.set(false);
      },
      error: (err) => {
        console.error('Failed to load history', err);
        this.error.set('Failed to load service history. Please try again.');
        this.loading.set(false);
      }
    });
  }
}
