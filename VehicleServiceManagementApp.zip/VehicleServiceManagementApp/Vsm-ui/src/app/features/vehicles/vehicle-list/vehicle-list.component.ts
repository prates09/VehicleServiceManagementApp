import { Component, inject, OnInit, ViewChild } from '@angular/core';
import { AsyncPipe } from '@angular/common';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouterLink } from '@angular/router';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { VehiclesService } from '../../../core/services/vehicles.service';
import { ServiceRequestsService } from '../../../core/services/service-requests.service';
import { AuthService } from '../../../core/services/auth.service';
import { VehicleResponseDto } from '../../../core/models/models';
import { Observable, of, forkJoin } from 'rxjs';
import { catchError, switchMap, map } from 'rxjs/operators';
import { configureTableSorting, sortDataByLatest } from '../../../core/utils/table.utils';
import { VehicleHistoryDialogComponent } from '../vehicle-history-dialog/vehicle-history-dialog.component';

@Component({
  selector: 'app-vehicle-list',
  templateUrl: './vehicle-list.component.html',
  styleUrl: './vehicle-list.component.scss',
  standalone: true,
  imports: [
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatButtonModule,
    MatIconModule,
    RouterLink,
    MatDialogModule
  ]
})
export class VehicleListComponent implements OnInit {
  private vehiclesService = inject(VehiclesService);
  private serviceRequestsService = inject(ServiceRequestsService);
  private authService = inject(AuthService);
  private dialog = inject(MatDialog);

  dataSource = new MatTableDataSource<VehicleResponseDto>([]);
  displayedColumns: string[] = ['id', 'registrationNumber', 'make', 'model', 'year', 'actions'];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  ngOnInit() {
    const role = this.authService.userRole();
    let vehicles$: Observable<VehicleResponseDto[]>;

    if (role === 'Customer') {
      vehicles$ = this.vehiclesService.getMyVehicles().pipe(
        catchError(() => of([])),
        switchMap(vehicles => {
          if (vehicles.length > 0) return of(vehicles);
          
          // Fallback: Try to find vehicles from service requests
          return this.serviceRequestsService.getMyServiceRequests().pipe(
            catchError(() => of([])),
            switchMap(requests => {
               const vehicleIds = [...new Set(requests.map(r => r.vehicleId))];
               if (vehicleIds.length === 0) return of([]);
               
               return forkJoin(
                 vehicleIds.map(id => this.vehiclesService.getVehicle(id).pipe(catchError(() => of(null))))
               ).pipe(
                 map(vs => vs.filter(v => v !== null) as VehicleResponseDto[])
               );
            })
          );
        })
      );
    } else {
      vehicles$ = this.vehiclesService.getVehicles().pipe(catchError(() => of([])));
    }

    vehicles$.subscribe(data => {
      this.dataSource.data = sortDataByLatest(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      configureTableSorting(this.dataSource);
    });
  }

  openHistory(vehicle: VehicleResponseDto) {
    this.dialog.open(VehicleHistoryDialogComponent, {
      data: { vehicle },
      width: '800px',
      panelClass: 'custom-dialog-container'
    });
  }
}
