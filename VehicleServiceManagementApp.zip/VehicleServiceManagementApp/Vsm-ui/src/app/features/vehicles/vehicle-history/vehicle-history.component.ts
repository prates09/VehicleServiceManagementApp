import { Component, inject, Input, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ServiceRequestsService } from '../../../core/services/service-requests.service';
import { VehiclesService } from '../../../core/services/vehicles.service';
import { ServiceRequestResponseDto, VehicleResponseDto } from '../../../core/models/models';
import { Observable, switchMap, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Component({
  selector: 'app-vehicle-history',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    RouterLink,
    DatePipe
  ],
  template: `
    <div class="page-container">
      <div class="header-actions">
        <button mat-button routerLink="/dashboard">
          <mat-icon>arrow_back</mat-icon> Back to Dashboard
        </button>
        <h1>Vehicle Service History</h1>
      </div>

      @if (vehicle$ | async; as vehicle) {
        <mat-card class="vehicle-info-card">
          <mat-card-header>
            <div mat-card-avatar class="vehicle-avatar">
              <mat-icon>directions_car</mat-icon>
            </div>
            <mat-card-title>{{ vehicle.year }} {{ vehicle.make }} {{ vehicle.model }}</mat-card-title>
            <mat-card-subtitle>{{ vehicle.registrationNumber }}</mat-card-subtitle>
          </mat-card-header>
        </mat-card>
      }

      <div class="history-section">
        <h2>Service Records</h2>
        
        @if (history$ | async; as history) {
          @if (history.length > 0) {
            <table mat-table [dataSource]="history" class="mat-elevation-z8">
              
              <ng-container matColumnDef="date">
                <th mat-header-cell *matHeaderCellDef> Date </th>
                <td mat-cell *matCellDef="let record"> {{ record.createdAt | date:'mediumDate' }} </td>
              </ng-container>

              <ng-container matColumnDef="service">
                <th mat-header-cell *matHeaderCellDef> Service </th>
                <td mat-cell *matCellDef="let record"> {{ record.issueDescription }} </td>
              </ng-container>

              <ng-container matColumnDef="status">
                <th mat-header-cell *matHeaderCellDef> Status </th>
                <td mat-cell *matCellDef="let record"> 
                  <span class="status-badge" [class]="record.status.toLowerCase().replace(' ', '-')">
                    {{ record.status }}
                  </span>
                </td>
              </ng-container>

              <ng-container matColumnDef="actions">
                <th mat-header-cell *matHeaderCellDef> Actions </th>
                <td mat-cell *matCellDef="let record">
                  <button mat-icon-button color="primary" [routerLink]="['/service-requests', record.id]">
                    <mat-icon>visibility</mat-icon>
                  </button>
                </td>
              </ng-container>

              <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
              <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
            </table>
          } @else {
            <div class="no-data">
              <p>No service history found for this vehicle.</p>
              <button mat-raised-button color="primary" routerLink="/service-requests/new">Book Service</button>
            </div>
          }
        }
      </div>
    </div>
  `,
  styles: [`
    .page-container {
      padding: 24px;
      max-width: 1200px;
      margin: 0 auto;
    }
    .header-actions {
      margin-bottom: 24px;
      h1 { margin-top: 16px; }
    }
    .vehicle-info-card {
      margin-bottom: 32px;
      background: #1e293b;
      color: #e2e8f0;
    }
    .vehicle-avatar {
      background: #334155;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #94a3b8;
    }
    .history-section {
      h2 { color: #e2e8f0; margin-bottom: 16px; }
    }
    table {
      width: 100%;
      background: #1e293b;
      
      th { color: #94a3b8; border-bottom-color: #334155; }
      td { color: #e2e8f0; border-bottom-color: #334155; }
    }
    .status-badge {
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 12px;
      &.completed { background: rgba(76, 175, 80, 0.2); color: #4caf50; }
      &.in-progress { background: rgba(33, 150, 243, 0.2); color: #2196f3; }
      &.closed { background: rgba(158, 158, 158, 0.2); color: #9e9e9e; }
    }
    .no-data {
      text-align: center;
      padding: 48px;
      background: #1e293b;
      border-radius: 8px;
      color: #94a3b8;
    }
  `]
})
export class VehicleHistoryComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private vehiclesService = inject(VehiclesService);
  private serviceRequestsService = inject(ServiceRequestsService);

  vehicle$: Observable<VehicleResponseDto | null> | undefined;
  history$: Observable<ServiceRequestResponseDto[]> | undefined;
  
  displayedColumns = ['date', 'service', 'status', 'actions'];

  ngOnInit() {
    const vehicleId = this.route.snapshot.paramMap.get('id');
    if (vehicleId) {
      const id = parseInt(vehicleId, 10);
      this.vehicle$ = this.vehiclesService.getVehicle(id).pipe(catchError(() => of(null)));
      
      // Assuming we can filter requests by vehicle ID locally or via API
      // Since API might not have getByVehicleId, we'll fetch all my requests and filter
      this.history$ = this.serviceRequestsService.getMyServiceRequests().pipe(
        map(requests => requests.filter(r => r.vehicleId === id)),
        catchError(() => of([]))
      );
    }
  }
}
