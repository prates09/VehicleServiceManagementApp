import { Component, inject, OnInit } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { VehiclesService } from '../../../core/services/vehicles.service';
import { CreateMyVehicleRequestDto, UpdateVehicleRequestDto } from '../../../core/models/models';

@Component({
  selector: 'app-vehicle-form',
  templateUrl: './vehicle-form.component.html',
  styleUrl: './vehicle-form.component.scss',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    RouterLink,
    MatSnackBarModule
  ]
})
export class VehicleFormComponent implements OnInit {
  private fb = inject(FormBuilder);
  private vehiclesService = inject(VehiclesService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private snackBar = inject(MatSnackBar);

  isEditMode = false;
  vehicleId: number | null = null;

  form = this.fb.group({
    registrationNumber: ['', Validators.required],
    make: ['', Validators.required],
    model: ['', Validators.required],
    year: [new Date().getFullYear(), [Validators.required, Validators.min(1900), Validators.max(new Date().getFullYear() + 1)]]
  });

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id && id !== 'new') {
      this.isEditMode = true;
      this.vehicleId = +id;
      this.vehiclesService.getVehicle(this.vehicleId).subscribe({
        next: (vehicle) => {
          this.form.patchValue({
            registrationNumber: vehicle.registrationNumber,
            make: vehicle.make,
            model: vehicle.model,
            year: vehicle.year
          });
        },
        error: (err) => {
          this.showError('Failed to load vehicle details');
          this.router.navigate(['/vehicles']);
        }
      });
    }
  }

  onSubmit() {
    if (this.form.valid) {
      const formValue = this.form.value;
      
      if (this.isEditMode && this.vehicleId) {
        const req: UpdateVehicleRequestDto = {
          registrationNumber: formValue.registrationNumber,
          make: formValue.make,
          model: formValue.model,
          year: formValue.year!,
          vehicleType: 'Car' // Default or add field if needed
        };

        this.vehiclesService.updateVehicle(this.vehicleId, req).subscribe({
          next: () => {
            this.showSuccess('Vehicle updated successfully');
            this.router.navigate(['/vehicles']);
          },
          error: (err) => this.showError('Failed to update vehicle')
        });
      } else {
        const req: CreateMyVehicleRequestDto = {
          registrationNumber: formValue.registrationNumber,
          make: formValue.make,
          model: formValue.model,
          year: formValue.year!,
          vehicleType: 'Car' // Default
        };

        this.vehiclesService.createMyVehicle(req).subscribe({
          next: () => {
            this.showSuccess('Vehicle registered successfully');
            this.router.navigate(['/vehicles']);
          },
          error: (err) => this.showError('Failed to register vehicle')
        });
      }
    }
  }

  private showSuccess(message: string) {
    this.snackBar.open(message, 'Close', {
      duration: 3000,
      panelClass: ['success-snackbar'],
      horizontalPosition: 'end',
      verticalPosition: 'top'
    });
  }

  private showError(message: string) {
    this.snackBar.open(message, 'Close', {
      duration: 5000,
      panelClass: ['error-snackbar'],
      horizontalPosition: 'end',
      verticalPosition: 'top'
    });
  }
}
