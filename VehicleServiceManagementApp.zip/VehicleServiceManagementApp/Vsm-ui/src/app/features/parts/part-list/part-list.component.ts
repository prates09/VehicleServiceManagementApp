import { Component, inject, OnInit, ViewChild } from '@angular/core';
import { AsyncPipe, CurrencyPipe } from '@angular/common';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { RouterLink } from '@angular/router';
import { PartsService } from '../../../core/services/parts.service';
import { PartResponseDto } from '../../../core/models/models';
import { Observable, map } from 'rxjs';
import { configureTableSorting, sortDataByLatest } from '../../../core/utils/table.utils';

@Component({
  selector: 'app-part-list',
  templateUrl: './part-list.component.html',
  styleUrl: './part-list.component.scss',
  standalone: true,
  imports: [
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    RouterLink,
    CurrencyPipe
  ]
})
export class PartListComponent implements OnInit {
  private partsService = inject(PartsService);
  dataSource = new MatTableDataSource<PartResponseDto>([]);
  displayedColumns: string[] = ['id', 'partNumber', 'name', 'unitPrice', 'stockQty', 'actions'];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  ngOnInit() {
    this.partsService.getParts().pipe(
      map(parts => sortDataByLatest(parts))
    ).subscribe(data => {
      this.dataSource.data = data;
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      configureTableSorting(this.dataSource);
    });
  }
}
