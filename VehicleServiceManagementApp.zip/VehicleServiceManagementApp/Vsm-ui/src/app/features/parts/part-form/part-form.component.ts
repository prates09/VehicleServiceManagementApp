import { Component, inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { PartsService } from '../../../core/services/parts.service';
import { CreatePartRequestDto, UpdatePartRequestDto } from '../../../core/models/models';

@Component({
  selector: 'app-part-form',
  templateUrl: './part-form.component.html',
  styleUrl: './part-form.component.scss',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    RouterLink
  ]
})
export class PartFormComponent implements OnInit {
  private fb = inject(FormBuilder);
  private partsService = inject(PartsService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private snackBar = inject(MatSnackBar);

  form: FormGroup;
  isEditMode = false;
  partId: number | null = null;
  originalValues: any = null;

  constructor() {
    this.form = this.fb.group({
      partNumber: ['', Validators.required],
      name: ['', Validators.required],
      description: [''],
      unitPrice: [0, [Validators.required, Validators.min(0)]],
      stockQty: [0, [Validators.required, Validators.min(0)]]
    });
  }

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id && id !== 'new') {
      this.isEditMode = true;
      this.partId = +id;
      this.loadPart(this.partId);
    }
  }

  loadPart(id: number) {
    this.partsService.getPart(id).subscribe({
      next: (part) => {
        this.form.patchValue(part);
        this.originalValues = this.form.value;
      },
      error: (err) => console.error(err)
    });
  }

  onSubmit() {
    if (this.form.invalid) return;

    // Check for significant changes if in edit mode
    if (this.isEditMode && this.originalValues) {
      const currentValues = this.form.value;
      const priceChanged = currentValues.unitPrice !== this.originalValues.unitPrice;
      const qtyChanged = currentValues.stockQty !== this.originalValues.stockQty;

      if ((priceChanged || qtyChanged) && !confirm('You have changed the price or stock quantity. Are you sure you want to proceed?')) {
        return;
      }
    }

    if (this.isEditMode && this.partId) {
      const request: UpdatePartRequestDto = this.form.value;
      this.partsService.updatePart(this.partId, request).subscribe({
        next: () => {
          this.snackBar.open('Part updated successfully', 'Close', { duration: 3000 });
          this.router.navigate(['/parts']);
        },
        error: (err) => {
          console.error(err);
          this.snackBar.open('Failed to update part', 'Close', { duration: 3000 });
        }
      });
    } else {
      const request: CreatePartRequestDto = this.form.value;
      this.partsService.createPart(request).subscribe({
        next: () => {
          this.snackBar.open('Part created successfully', 'Close', { duration: 3000 });
          this.router.navigate(['/parts']);
        },
        error: (err) => {
          console.error(err);
          this.snackBar.open('Failed to create part', 'Close', { duration: 3000 });
        }
      });
    }
  }
}
