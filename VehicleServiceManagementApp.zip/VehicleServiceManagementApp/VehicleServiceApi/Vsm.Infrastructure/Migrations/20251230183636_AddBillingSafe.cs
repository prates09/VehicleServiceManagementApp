﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Vsm.Infrastructure.Migrations
{
    public partial class AddBillingSafe : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // ---- DO NOT DROP Status (keep existing data) ----
            // migrationBuilder.DropColumn(name: "Status", table: "Invoices"); // <-- remove

            // ---- Preserve Description by renaming it to ItemName ----
            // (Description existed previously; rename keeps content)
            migrationBuilder.RenameColumn(
                name: "Description",
                table: "InvoiceLines",
                newName: "ItemName");

            // ---- Other renames on Invoices ----
            migrationBuilder.RenameColumn(
                name: "Subtotal",
                table: "Invoices",
                newName: "PartsTotal");

            migrationBuilder.RenameColumn(
                name: "CreatedAtUtc",
                table: "Invoices",
                newName: "GeneratedAtUtc");

            // ---- Alter PaymentReference to nvarchar(max) ----
            migrationBuilder.AlterColumn<string>(
                name: "PaymentReference",
                table: "Invoices",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);

            // ---- Add new billing fields ----
            migrationBuilder.AddColumn<bool>(
                name: "IsPaid",
                table: "Invoices",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<decimal>(
                name: "LaborCharge",
                table: "Invoices",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "TaxRate",
                table: "Invoices",
                type: "decimal(18,4)",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<string>(
                name: "ItemCode",
                table: "InvoiceLines",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ItemType",
                table: "InvoiceLines",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "Part"); // default for existing rows

            // ---- Data migration: derive IsPaid from Status ----
            // Adjust mapping if your old enum differs (assumed: 0=Unpaid, 1=Paid).
            migrationBuilder.Sql(@"
UPDATE Invoices
SET IsPaid = CASE WHEN Status = 1 THEN 1 ELSE 0 END
");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Reverse added columns
            migrationBuilder.DropColumn(name: "IsPaid", table: "Invoices");
            migrationBuilder.DropColumn(name: "LaborCharge", table: "Invoices");
            migrationBuilder.DropColumn(name: "TaxRate", table: "Invoices");
            migrationBuilder.DropColumn(name: "ItemCode", table: "InvoiceLines");
            migrationBuilder.DropColumn(name: "ItemType", table: "InvoiceLines");

            // Reverse PaymentReference size
            migrationBuilder.AlterColumn<string>(
                name: "PaymentReference",
                table: "Invoices",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            // Rename columns back
            migrationBuilder.RenameColumn(
                name: "PartsTotal",
                table: "Invoices",
                newName: "Subtotal");

            migrationBuilder.RenameColumn(
                name: "GeneratedAtUtc",
                table: "Invoices",
                newName: "CreatedAtUtc");

            migrationBuilder.RenameColumn(
                name: "ItemName",
                table: "InvoiceLines",
                newName: "Description");

            // NOTE: We never dropped Invoices.Status in Up, so we don't re-add it here.
        }
    }
}