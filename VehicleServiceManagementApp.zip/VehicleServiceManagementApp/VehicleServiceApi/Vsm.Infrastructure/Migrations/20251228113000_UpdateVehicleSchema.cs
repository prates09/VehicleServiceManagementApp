﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Vsm.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class UpdateVehicleSchema : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "VehicleType",
                table: "Vehicles",
                newName: "Make");

            migrationBuilder.AddColumn<int>(
                name: "Year",
                table: "Vehicles",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Year",
                table: "Vehicles");

            migrationBuilder.RenameColumn(
                name: "Make",
                table: "Vehicles",
                newName: "VehicleType");
        }
    }
}
