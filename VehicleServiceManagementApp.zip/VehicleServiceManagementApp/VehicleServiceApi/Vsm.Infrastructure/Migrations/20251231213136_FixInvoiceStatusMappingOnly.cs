﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Vsm.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class FixInvoiceStatusMappingOnly : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // DB already has Invoices.Status column.
            // This migration intentionally does nothing to avoid duplicate column error.
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Intentionally empty.
        }
    }
}
