﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Vsm.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class RestoreVehicleType : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Check if column already exists before adding
            var sql = @"
                IF NOT EXISTS (SELECT 1 FROM sys.columns 
                               WHERE object_id = OBJECT_ID('Vehicles') 
                               AND name = 'VehicleType')
                BEGIN
                    ALTER TABLE [Vehicles] ADD [VehicleType] nvarchar(max) NULL;
                END";
            migrationBuilder.Sql(sql);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Check if column exists before dropping
            var sql = @"
                IF EXISTS (SELECT 1 FROM sys.columns 
                          WHERE object_id = OBJECT_ID('Vehicles') 
                          AND name = 'VehicleType')
                BEGIN
                    ALTER TABLE [Vehicles] DROP COLUMN [VehicleType];
                END";
            migrationBuilder.Sql(sql);
        }
    }
}
