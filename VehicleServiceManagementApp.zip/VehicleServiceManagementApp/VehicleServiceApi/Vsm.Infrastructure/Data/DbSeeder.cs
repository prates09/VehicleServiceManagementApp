﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Vsm.Domain.Entities;
using Vsm.Infrastructure.Identity;

namespace Vsm.Infrastructure.Data;

public static class DbSeeder
{
    public static async Task SeedAsync(IServiceProvider services)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();

        // ✅ InMemory-safe
        if (db.Database.IsRelational())
            await db.Database.MigrateAsync();
        else
            await db.Database.EnsureCreatedAsync();

        // ---- Customers (linked to Identity users) ----
        if (!await db.Customers.AnyAsync())
        {
            var uPratyush = await userManager.FindByNameAsync("pratyush");
            var uKaustabh = await userManager.FindByNameAsync("kaustabh");
            var uAman = await userManager.FindByNameAsync("aman");
            var uRiya = await userManager.FindByNameAsync("riya");

            db.Customers.AddRange(
                new Customer
                {
                    FullName = "Pratyush Singh",
                    Phone = "9876543210",
                    Email = "pratyush@gmail.com",
                    ApplicationUserId = uPratyush?.Id
                },
                new Customer
                {
                    FullName = "Kaustabh Mishra",
                    Phone = "9123456780",
                    Email = "kaustabh@gmail.com",
                    ApplicationUserId = uKaustabh?.Id
                },
                new Customer
                {
                    FullName = "Aman Verma",
                    Phone = "9988776655",
                    Email = "aman@gmail.com",
                    ApplicationUserId = uAman?.Id
                },
                new Customer
                {
                    FullName = "Riya Sharma",
                    Phone = "9090909090",
                    Email = "riya@gmail.com",
                    ApplicationUserId = uRiya?.Id
                }
            );

            await db.SaveChangesAsync();
        }

        // ---- Vehicles ----
        if (!await db.Vehicles.AnyAsync())
        {
            var customers = await db.Customers.OrderBy(x => x.Id).ToListAsync();

            db.Vehicles.AddRange(
                new Vehicle { CustomerId = customers[0].Id, RegistrationNumber = "TR01AB1234", Make = "Maruti", Model = "Swift", Year = 2020 },
                new Vehicle { CustomerId = customers[1].Id, RegistrationNumber = "TR02CD5678", Make = "Hyundai", Model = "i20", Year = 2021 },
                new Vehicle { CustomerId = customers[2].Id, RegistrationNumber = "TR03EF9012", Make = "Tata", Model = "Nexon", Year = 2022 },
                new Vehicle { CustomerId = customers[3].Id, RegistrationNumber = "TR04GH3456", Make = "Honda", Model = "City", Year = 2019 }
            );

            await db.SaveChangesAsync();
        }

        // ---- Service Categories ----
        if (!await db.ServiceCategories.AnyAsync())
        {
            db.ServiceCategories.AddRange(
                new ServiceCategory { Name = "Oil Change", Description = "Engine oil and filter replacement", BasePrice = 500, IsActive = true },
                new ServiceCategory { Name = "Brake Service", Description = "Brake pad replacement and brake fluid check", BasePrice = 1500, IsActive = true },
                new ServiceCategory { Name = "Engine Tune-up", Description = "Spark plugs, air filter, and general engine maintenance", BasePrice = 2000, IsActive = true },
                new ServiceCategory { Name = "AC Service", Description = "Air conditioning system service and gas refill", BasePrice = 1200, IsActive = true },
                new ServiceCategory { Name = "General Service", Description = "Comprehensive vehicle inspection and maintenance", BasePrice = 800, IsActive = true }
            );

            await db.SaveChangesAsync();
        }

        // ---- Parts ----
        if (!await db.Parts.AnyAsync())
        {
            db.Parts.AddRange(
                new Part { PartNumber = "OIL-5W30", Name = "Engine Oil 5W30 (1L)", StockQty = 50, UnitPrice = 450, LowStockThreshold = 5 },
                new Part { PartNumber = "FLT-OIL-01", Name = "Oil Filter", StockQty = 30, UnitPrice = 180, LowStockThreshold = 5 },
                new Part { PartNumber = "BRK-PAD-F", Name = "Brake Pad Set (Front)", StockQty = 10, UnitPrice = 2200, LowStockThreshold = 3 },
                new Part { PartNumber = "AIR-FLT-01", Name = "Air Filter", StockQty = 8, UnitPrice = 350, LowStockThreshold = 3 },
                new Part { PartNumber = "SPK-PLUG-01", Name = "Spark Plug", StockQty = 25, UnitPrice = 160, LowStockThreshold = 5 }
            );

            await db.SaveChangesAsync();
        }
    }
}
