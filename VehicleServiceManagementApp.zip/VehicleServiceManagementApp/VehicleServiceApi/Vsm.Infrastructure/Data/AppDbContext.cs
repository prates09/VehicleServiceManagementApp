﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Vsm.Domain.Entities;
using Vsm.Infrastructure.Identity;

namespace Vsm.Infrastructure.Data;

public class AppDbContext : IdentityDbContext<ApplicationUser>
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<Vehicle> Vehicles => Set<Vehicle>();
    public DbSet<ServiceRequest> ServiceRequests => Set<ServiceRequest>();
    public DbSet<ServiceCategory> ServiceCategories => Set<ServiceCategory>();

    public DbSet<Part> Parts => Set<Part>();
    public DbSet<ServicePartUsage> ServicePartUsages => Set<ServicePartUsage>();
    public DbSet<Invoice> Invoices => Set<Invoice>();
    public DbSet<InvoiceLine> InvoiceLines => Set<InvoiceLine>();

    // ✅ Notifications
    public DbSet<Notification> Notifications => Set<Notification>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.Entity<Customer>()
            .Property(x => x.ApplicationUserId)
            .HasMaxLength(450);

        builder.Entity<Customer>()
            .HasIndex(x => x.ApplicationUserId)
            .IsUnique();

        // ✅ SQL Server supports filtered unique indexes; SQLite (tests) doesn't
        if (Database.ProviderName?.Contains("SqlServer") == true)
        {
            builder.Entity<Customer>()
                .HasIndex(x => x.ApplicationUserId)
                .IsUnique()
                .HasFilter("[ApplicationUserId] IS NOT NULL");
        }

        builder.Entity<Vehicle>()
            .HasIndex(x => x.RegistrationNumber)
            .IsUnique();

        builder.Entity<ServiceRequest>()
            .HasOne(x => x.Customer)
            .WithMany()
            .HasForeignKey(x => x.CustomerId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.Entity<ServiceRequest>()
            .HasOne(x => x.Vehicle)
            .WithMany()
            .HasForeignKey(x => x.VehicleId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.Entity<ServiceRequest>()
            .Property(x => x.Priority)
            .HasConversion<int>();

        builder.Entity<ServiceRequest>()
            .Property(x => x.Status)
            .HasConversion<int>();

        builder.Entity<ServiceRequest>()
            .Property(x => x.IssueDescription)
            .HasMaxLength(1000)
            .IsRequired();

        builder.Entity<ServiceRequest>()
            .Property(x => x.Remarks)
            .HasMaxLength(2000);

        builder.Entity<ServiceRequest>()
            .Property(x => x.AssignedTechnicianUserId)
            .HasMaxLength(450);

        builder.Entity<ServiceRequest>()
            .Property(x => x.RequestedAtUtc)
            .HasDefaultValueSql("GETUTCDATE()");

        builder.Entity<ServiceRequest>()
            .HasOne(x => x.ServiceCategory)
            .WithMany(x => x.ServiceRequests)
            .HasForeignKey(x => x.ServiceCategoryId)
            .OnDelete(DeleteBehavior.SetNull); // Allow null if category is deleted

        builder.Entity<ServiceCategory>()
            .Property(x => x.Name)
            .HasMaxLength(200)
            .IsRequired();

        builder.Entity<ServiceCategory>()
            .Property(x => x.Description)
            .HasMaxLength(1000);

        builder.Entity<ServiceCategory>()
            .Property(x => x.BasePrice)
            .HasColumnType("decimal(18,2)");

        builder.Entity<ServiceCategory>()
            .HasIndex(x => x.Name)
            .IsUnique();

        builder.Entity<Part>()
            .HasIndex(x => x.PartNumber)
            .IsUnique();

        builder.Entity<Part>()
            .Property(x => x.UnitPrice)
            .HasColumnType("decimal(18,2)");

        builder.Entity<ServicePartUsage>()
            .Property(x => x.UnitPriceAtUse)
            .HasColumnType("decimal(18,2)");

        builder.Entity<ServicePartUsage>()
            .HasOne(x => x.ServiceRequest)
            .WithMany()
            .HasForeignKey(x => x.ServiceRequestId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.Entity<ServicePartUsage>()
            .HasOne(x => x.Part)
            .WithMany()
            .HasForeignKey(x => x.PartId)
            .OnDelete(DeleteBehavior.Restrict);

        // ✅ Invoice mappings
        builder.Entity<Invoice>()
            .Property(x => x.Status)
            .HasConversion<int>()
            .IsRequired()
            .ValueGeneratedNever(); // ✅ FORCE EF to include Status in INSERT

        builder.Entity<Invoice>()
            .Property(x => x.TotalAmount)
            .HasColumnType("decimal(18,2)");

        builder.Entity<Invoice>()
            .Property(x => x.LaborCharge)
            .HasColumnType("decimal(18,2)");

        builder.Entity<Invoice>()
            .Property(x => x.PartsTotal)
            .HasColumnType("decimal(18,2)");

        builder.Entity<Invoice>()
            .Property(x => x.TaxRate)
            .HasColumnType("decimal(18,4)");

        builder.Entity<Invoice>()
            .Property(x => x.TaxAmount)
            .HasColumnType("decimal(18,2)");

        builder.Entity<Invoice>()
            .HasIndex(x => x.ServiceRequestId)
            .IsUnique();

        builder.Entity<InvoiceLine>()
            .Property(x => x.UnitPrice)
            .HasColumnType("decimal(18,2)");

        builder.Entity<InvoiceLine>()
            .Property(x => x.LineTotal)
            .HasColumnType("decimal(18,2)");

        builder.Entity<Invoice>()
            .HasMany(x => x.Lines)
            .WithOne(x => x.Invoice)
            .HasForeignKey(x => x.InvoiceId)
            .OnDelete(DeleteBehavior.Cascade);

        // ✅ Notifications mapping
        builder.Entity<Notification>()
            .Property(x => x.UserId)
            .HasMaxLength(450)
            .IsRequired();

        builder.Entity<Notification>()
            .Property(x => x.Title)
            .HasMaxLength(200)
            .IsRequired();

        builder.Entity<Notification>()
            .Property(x => x.Message)
            .HasMaxLength(2000)
            .IsRequired();

        builder.Entity<Notification>()
            .Property(x => x.Type)
            .HasMaxLength(50)
            .IsRequired();

        builder.Entity<Notification>()
            .HasIndex(x => new { x.UserId, x.CreatedAtUtc });
    }
}
