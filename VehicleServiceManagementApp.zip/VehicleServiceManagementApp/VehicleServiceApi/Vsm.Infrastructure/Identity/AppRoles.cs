﻿namespace Vsm.Infrastructure.Identity;

public static class AppRoles
{
    public const string Admin = "Admin";
    public const string ServiceManager = "ServiceManager";
    public const string Technician = "Technician";
    public const string Customer = "Customer";

    public static readonly string[] All = { Admin, ServiceManager, Technician, Customer };
}
