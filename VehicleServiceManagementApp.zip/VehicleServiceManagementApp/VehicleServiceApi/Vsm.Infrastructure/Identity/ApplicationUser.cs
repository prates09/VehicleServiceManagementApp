﻿using Microsoft.AspNetCore.Identity;

namespace Vsm.Infrastructure.Identity;

public class ApplicationUser : IdentityUser
{
    public bool IsActive { get; set; } = true;
    
    // Extended profile field - nullable for backward compatibility with existing users
    // Note: Email and PhoneNumber are already available from IdentityUser base class (nullable)
    public string? FullName { get; set; }
}
