﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;

namespace Vsm.Infrastructure.Identity;

public static class IdentityDbSeeder
{
    public static async Task SeedAsync(IServiceProvider services)
    {
        using var scope = services.CreateScope();

        var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();

        // ✅ Seed roles
        foreach (var role in AppRoles.All)
        {
            if (!await roleManager.RoleExistsAsync(role))
            {
                var roleRes = await roleManager.CreateAsync(new IdentityRole(role));
                if (!roleRes.Succeeded)
                    throw new Exception($"Failed to create role '{role}': {string.Join(", ", roleRes.Errors.Select(e => e.Description))}");
            }
        }

        // ✅ Seed default users (your original list)
        await EnsureUser(userManager, "admin", "Admin@123", AppRoles.Admin);
        await EnsureUser(userManager, "manager", "Manager@123", AppRoles.ServiceManager);

        await EnsureUser(userManager, "tech", "Tech@123", AppRoles.Technician);
        await EnsureUser(userManager, "tech1", "Tech@123", AppRoles.Technician);
        await EnsureUser(userManager, "tech2", "Tech@123", AppRoles.Technician);

        await EnsureUser(userManager, "pratyush", "Customer@123", AppRoles.Customer);
        await EnsureUser(userManager, "kaustabh", "Customer@123", AppRoles.Customer);
        await EnsureUser(userManager, "aman", "Customer@123", AppRoles.Customer);
        await EnsureUser(userManager, "riya", "Customer@123", AppRoles.Customer);
    }

    private static async Task EnsureUser(
        UserManager<ApplicationUser> userManager,
        string userName,
        string password,
        string role)
    {
        var user = await userManager.FindByNameAsync(userName);

        if (user is null)
        {
            user = new ApplicationUser { UserName = userName };
            var create = await userManager.CreateAsync(user, password);

            if (!create.Succeeded)
                throw new Exception($"Failed to create user '{userName}': {string.Join(", ", create.Errors.Select(e => e.Description))}");
        }

        if (!await userManager.IsInRoleAsync(user, role))
        {
            var addRole = await userManager.AddToRoleAsync(user, role);

            if (!addRole.Succeeded)
                throw new Exception($"Failed to add role '{role}' to '{userName}': {string.Join(", ", addRole.Errors.Select(e => e.Description))}");
        }
    }
}
