namespace Vsm.Application.Services;

/// <summary>
/// Service for parts inventory management and calculations
/// </summary>
public class PartsService
{
    /// <summary>
    /// Checks if a part is low in stock
    /// </summary>
    public bool IsLowStock(int stockQty, int lowStockThreshold)
    {
        if (stockQty < 0)
            throw new ArgumentException("Stock quantity cannot be negative.", nameof(stockQty));
        
        if (lowStockThreshold < 0)
            throw new ArgumentException("Low stock threshold cannot be negative.", nameof(lowStockThreshold));

        return stockQty <= lowStockThreshold;
    }

    /// <summary>
    /// Calculates new stock quantity after adjustment
    /// </summary>
    public StockAdjustmentResult AdjustStock(int currentStock, int delta)
    {
        if (currentStock < 0)
            throw new ArgumentException("Current stock cannot be negative.", nameof(currentStock));

        var newStock = currentStock + delta;
        
        if (newStock < 0)
            throw new InvalidOperationException($"Stock adjustment would result in negative stock. Current: {currentStock}, Delta: {delta}");

        return new StockAdjustmentResult
        {
            PreviousStock = currentStock,
            Delta = delta,
            NewStock = newStock
        };
    }

    /// <summary>
    /// Validates part creation/update data
    /// </summary>
    public ValidationResult ValidatePartData(
        string partNumber,
        string name,
        decimal unitPrice,
        int stockQty,
        int lowStockThreshold)
    {
        var errors = new List<string>();

        if (string.IsNullOrWhiteSpace(partNumber))
            errors.Add("Part number is required.");

        if (string.IsNullOrWhiteSpace(name))
            errors.Add("Name is required.");

        if (unitPrice <= 0)
            errors.Add("Unit price must be greater than zero.");

        if (stockQty < 0)
            errors.Add("Stock quantity cannot be negative.");

        if (lowStockThreshold < 0)
            errors.Add("Low stock threshold cannot be negative.");

        return new ValidationResult
        {
            IsValid = errors.Count == 0,
            Errors = errors
        };
    }
}

/// <summary>
/// Result of stock adjustment
/// </summary>
public class StockAdjustmentResult
{
    public int PreviousStock { get; set; }
    public int Delta { get; set; }
    public int NewStock { get; set; }
}

/// <summary>
/// Validation result
/// </summary>
public class ValidationResult
{
    public bool IsValid { get; set; }
    public List<string> Errors { get; set; } = new();
}

