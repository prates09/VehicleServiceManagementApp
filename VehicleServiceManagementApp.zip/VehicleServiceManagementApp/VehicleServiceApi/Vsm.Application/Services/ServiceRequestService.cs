using Vsm.Domain.Enums;

namespace Vsm.Application.Services;

/// <summary>
/// Service for service request business logic and validations
/// </summary>
public class ServiceRequestService
{
    /// <summary>
    /// Validates if a status transition is allowed
    /// </summary>
    public bool IsValidStatusTransition(ServiceRequestStatus currentStatus, ServiceRequestStatus newStatus)
    {
        // Define allowed transitions
        return currentStatus switch
        {
            ServiceRequestStatus.Requested => newStatus == ServiceRequestStatus.Assigned ||
                                              newStatus == ServiceRequestStatus.Cancelled,
            
            ServiceRequestStatus.Assigned => newStatus == ServiceRequestStatus.InProgress ||
                                            newStatus == ServiceRequestStatus.Cancelled,
            
            ServiceRequestStatus.InProgress => newStatus == ServiceRequestStatus.Completed ||
                                              newStatus == ServiceRequestStatus.Cancelled,
            
            ServiceRequestStatus.Completed => newStatus == ServiceRequestStatus.Closed,
            
            ServiceRequestStatus.Closed => false, // Cannot transition from closed
            
            ServiceRequestStatus.Cancelled => false, // Cannot transition from cancelled
            
            _ => false
        };
    }

    /// <summary>
    /// Determines if a service request can be cancelled
    /// </summary>
    public bool CanCancel(ServiceRequestStatus status)
    {
        return status == ServiceRequestStatus.Requested ||
               status == ServiceRequestStatus.Assigned ||
               status == ServiceRequestStatus.InProgress;
    }

    /// <summary>
    /// Determines if a service request can be assigned to a technician
    /// </summary>
    public bool CanAssign(ServiceRequestStatus status)
    {
        return status == ServiceRequestStatus.Requested;
    }

    /// <summary>
    /// Validates service request creation data
    /// </summary>
    public ValidationResult ValidateServiceRequestData(
        int vehicleId,
        string issueDescription,
        ServicePriority priority)
    {
        var errors = new List<string>();

        if (vehicleId <= 0)
            errors.Add("Vehicle ID must be greater than zero.");

        if (string.IsNullOrWhiteSpace(issueDescription))
            errors.Add("Issue description is required.");
        else if (issueDescription.Trim().Length < 10)
            errors.Add("Issue description must be at least 10 characters.");

        if (!Enum.IsDefined(typeof(ServicePriority), priority))
            errors.Add("Invalid priority value.");

        return new ValidationResult
        {
            IsValid = errors.Count == 0,
            Errors = errors
        };
    }
}

