using Vsm.Domain.Entities;
using Vsm.Domain.Enums;

namespace Vsm.Application.Services;

/// <summary>
/// Service for billing and invoice calculations
/// </summary>
public class BillingService
{
    /// <summary>
    /// Calculates invoice totals including parts, labor, tax, and grand total
    /// </summary>
    public InvoiceCalculationResult CalculateInvoice(
        decimal partsTotal,
        decimal laborCharge,
        decimal taxRate)
    {
        if (partsTotal < 0)
            throw new ArgumentException("Parts total cannot be negative.", nameof(partsTotal));
        
        if (laborCharge < 0)
            throw new ArgumentException("Labor charge cannot be negative.", nameof(laborCharge));
        
        if (taxRate < 0 || taxRate > 1)
            throw new ArgumentException("Tax rate must be between 0 and 1.", nameof(taxRate));

        var subTotal = partsTotal + laborCharge;
        var taxAmount = Math.Round(subTotal * taxRate, 2);
        var totalAmount = Math.Round(subTotal + taxAmount, 2);

        return new InvoiceCalculationResult
        {
            PartsTotal = partsTotal,
            LaborCharge = laborCharge,
            SubTotal = subTotal,
            TaxRate = taxRate,
            TaxAmount = taxAmount,
            TotalAmount = totalAmount
        };
    }

    /// <summary>
    /// Determines the labor charge to use based on provided value or service category base price
    /// </summary>
    public decimal DetermineLaborCharge(
        decimal? providedLaborCharge,
        decimal? serviceCategoryBasePrice)
    {
        if (providedLaborCharge.HasValue && providedLaborCharge.Value > 0)
            return providedLaborCharge.Value;

        if (serviceCategoryBasePrice.HasValue && serviceCategoryBasePrice.Value > 0)
            return serviceCategoryBasePrice.Value;

        return 0;
    }

    /// <summary>
    /// Validates if invoice can be generated for a service request status
    /// </summary>
    public bool CanGenerateInvoice(ServiceRequestStatus status)
    {
        return status == ServiceRequestStatus.Completed || 
               status == ServiceRequestStatus.Closed;
    }
}

/// <summary>
/// Result of invoice calculation
/// </summary>
public class InvoiceCalculationResult
{
    public decimal PartsTotal { get; set; }
    public decimal LaborCharge { get; set; }
    public decimal SubTotal { get; set; }
    public decimal TaxRate { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }
}

