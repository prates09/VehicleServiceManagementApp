using Vsm.Domain.Enums;

namespace Vsm.Application.Services;

/// <summary>
/// Service for report calculations and aggregations
/// </summary>
public class ReportService
{
    /// <summary>
    /// Calculates service summary statistics
    /// </summary>
    public ServiceSummary CalculateSummary(
        int total,
        int requested,
        int assigned,
        int inProgress,
        int completed,
        int closed,
        int cancelled)
    {
        if (total < 0 || requested < 0 || assigned < 0 || inProgress < 0 || 
            completed < 0 || closed < 0 || cancelled < 0)
            throw new ArgumentException("Counts cannot be negative.");

        var pending = requested + assigned + inProgress;
        var totalCalculated = requested + assigned + inProgress + completed + closed + cancelled;

        if (total != totalCalculated)
            throw new ArgumentException($"Total count ({total}) does not match sum of individual counts ({totalCalculated}).");

        return new ServiceSummary
        {
            Total = total,
            Requested = requested,
            Assigned = assigned,
            InProgress = inProgress,
            Completed = completed,
            Closed = closed,
            Cancelled = cancelled,
            Pending = pending
        };
    }

    /// <summary>
    /// Groups service requests by status and counts them
    /// </summary>
    public Dictionary<ServiceRequestStatus, int> GroupByStatus(
        IEnumerable<ServiceRequestStatus> statuses)
    {
        if (statuses == null)
            throw new ArgumentNullException(nameof(statuses));

        return statuses
            .GroupBy(s => s)
            .ToDictionary(g => g.Key, g => g.Count());
    }

    /// <summary>
    /// Calculates completion rate
    /// </summary>
    public decimal CalculateCompletionRate(int completed, int total)
    {
        if (total <= 0)
            return 0;

        if (completed < 0 || completed > total)
            throw new ArgumentException("Invalid completion count.");

        return Math.Round((decimal)completed / total * 100, 2);
    }
}

/// <summary>
/// Service summary statistics
/// </summary>
public class ServiceSummary
{
    public int Total { get; set; }
    public int Requested { get; set; }
    public int Assigned { get; set; }
    public int InProgress { get; set; }
    public int Completed { get; set; }
    public int Closed { get; set; }
    public int Cancelled { get; set; }
    public int Pending { get; set; }
}

