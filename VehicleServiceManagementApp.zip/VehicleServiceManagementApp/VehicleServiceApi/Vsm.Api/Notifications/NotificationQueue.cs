﻿using System.Threading.Channels;

namespace Vsm.Api.Notifications;

public static class NotificationQueue
{
    public static Channel<NotificationEvent> Channel { get; } =
        System.Threading.Channels.Channel.CreateUnbounded<NotificationEvent>();
}
