﻿namespace Vsm.Api.Notifications;

public record NotificationEvent(
    string UserId,
    string Title,
    string Message,
    string Type,
    int? RelatedServiceRequestId = null,
    int? RelatedInvoiceId = null
);
