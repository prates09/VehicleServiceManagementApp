﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Vsm.Domain.Entities;
using Vsm.Infrastructure.Data;

namespace Vsm.Api.Notifications;

public class NotificationBackgroundService : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;

    public NotificationBackgroundService(IServiceScopeFactory scopeFactory)
    {
        _scopeFactory = scopeFactory;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await foreach (var evt in NotificationQueue.Channel.Reader.ReadAllAsync(stoppingToken))
        {
            try
            {
                using var scope = _scopeFactory.CreateScope();
                var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

                db.Notifications.Add(new Notification
                {
                    UserId = evt.UserId,
                    Title = evt.Title,
                    Message = evt.Message,
                    Type = evt.Type,
                    RelatedServiceRequestId = evt.RelatedServiceRequestId,
                    RelatedInvoiceId = evt.RelatedInvoiceId,
                    CreatedAtUtc = DateTime.UtcNow,
                    IsRead = false
                });

                await db.SaveChangesAsync(stoppingToken);
            }
            catch
            {
                // Keep background service alive even if one event fails
                // (Optional: add logging later)
            }
        }
    }
}
