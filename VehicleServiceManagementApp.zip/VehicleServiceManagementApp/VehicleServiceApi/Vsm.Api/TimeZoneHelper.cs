using System;

namespace Vsm.Api;

/// <summary>
/// Centralized helper for working with Indian Standard Time (IST).
/// We continue to store all timestamps in UTC in the database,
/// but any "local" business time should use IST via this helper.
/// </summary>
public static class TimeZoneHelper
{
    private static readonly TimeZoneInfo IndiaTimeZone = GetIndiaTimeZone();

    private static TimeZoneInfo GetIndiaTimeZone()
    {
        try
        {
            // Windows ID
            return TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
        }
        catch (TimeZoneNotFoundException)
        {
            // Linux/macOS ID
            return TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata");
        }
        catch (InvalidTimeZoneException)
        {
            // Fallback to UTC if IST is not available (defensive)
            return TimeZoneInfo.Utc;
        }
    }

    /// <summary>
    /// Current UTC time.
    /// </summary>
    public static DateTime UtcNow => DateTime.UtcNow;

    /// <summary>
    /// Current time in Indian Standard Time (IST).
    /// </summary>
    public static DateTime NowInIst => TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, IndiaTimeZone);

    /// <summary>
    /// Convert a DateTime to IST.
    /// If the input is UTC, it is converted from UTC; otherwise it's treated as local.
    /// </summary>
    public static DateTime ToIst(DateTime dateTime)
    {
        if (dateTime.Kind == DateTimeKind.Utc)
            return TimeZoneInfo.ConvertTimeFromUtc(dateTime, IndiaTimeZone);

        return TimeZoneInfo.ConvertTime(dateTime, TimeZoneInfo.Local, IndiaTimeZone);
    }
}
