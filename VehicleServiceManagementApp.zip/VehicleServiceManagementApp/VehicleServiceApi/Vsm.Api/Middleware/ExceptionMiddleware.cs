﻿using System.Net;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;

namespace Vsm.Api.Middleware;

public sealed class ExceptionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionMiddleware> _logger;

    public ExceptionMiddleware(RequestDelegate next, ILogger<ExceptionMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled exception");

            await WriteErrorAsync(context, ex);
        }
    }

    private static Task WriteErrorAsync(HttpContext context, Exception ex)
    {
        var (statusCode, title) = ex switch
        {
            UnauthorizedAccessException => (HttpStatusCode.Unauthorized, "Unauthorized"),
            KeyNotFoundException => (HttpStatusCode.NotFound, "Not Found"),
            ArgumentException => (HttpStatusCode.BadRequest, "Bad Request"),
            InvalidOperationException => (HttpStatusCode.BadRequest, "Bad Request"),
            DbUpdateException => (HttpStatusCode.Conflict, "Database Update Error"),
            NullReferenceException => (HttpStatusCode.InternalServerError, "Server Error"),
            _ => (HttpStatusCode.InternalServerError, "Server Error")
        };

        context.Response.ContentType = "application/json";
        context.Response.StatusCode = (int)statusCode;

        var isDevelopment = context.RequestServices
            .GetService<Microsoft.Extensions.Hosting.IHostEnvironment>()?
            .IsDevelopment() ?? false;

        var payload = new
        {
            title,
            status = context.Response.StatusCode,
            detail = ex.Message,
            traceId = context.TraceIdentifier,
            type = ex.GetType().Name,
            stackTrace = isDevelopment ? ex.StackTrace : null,
            innerException = isDevelopment && ex.InnerException != null ? ex.InnerException.Message : null
        };

        return context.Response.WriteAsync(JsonSerializer.Serialize(payload));
    }
}
