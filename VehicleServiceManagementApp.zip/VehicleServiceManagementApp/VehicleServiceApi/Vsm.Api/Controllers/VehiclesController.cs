﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Vsm.Api.Dtos.Vehicles;
using Vsm.Domain.Entities;
using Vsm.Infrastructure.Data;
using Vsm.Infrastructure.Identity;

namespace Vsm.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class VehiclesController : ControllerBase
{
    private readonly AppDbContext _db;

    public VehiclesController(AppDbContext db)
    {
        _db = db;
    }

    private string? GetUserId()
    {
        try
        {
            if (User?.Identity == null || !User.Identity.IsAuthenticated)
                return null;

            return User.FindFirstValue(ClaimTypes.NameIdentifier)
                ?? User.FindFirstValue("sub");
        }
        catch
        {
            return null;
        }
    }

    private async Task<Customer?> GetLoggedInCustomerAsync()
    {
        var userId = GetUserId();
        if (string.IsNullOrWhiteSpace(userId)) return null;

        try
        {
            return await _db.Customers
                .AsNoTracking()
                .FirstOrDefaultAsync(c => c.ApplicationUserId == userId);
        }
        catch
        {
            return null;
        }
    }

    // -------------------- CREATE (ADMIN/MANAGER) --------------------
    [HttpPost]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<ActionResult<VehicleResponseDto>> Create([FromBody] CreateVehicleRequestDto dto)
    {
        if (dto.CustomerId <= 0) return BadRequest("CustomerId is required.");

        var customerExists = await _db.Customers.AnyAsync(x => x.Id == dto.CustomerId);
        if (!customerExists) return BadRequest("CustomerId not found.");

        var regNo = (dto.RegistrationNumber ?? "").Trim();
        var make = (dto.Make ?? "").Trim();
        var model = (dto.Model ?? "").Trim();

        if (string.IsNullOrWhiteSpace(regNo)) return BadRequest("RegistrationNumber is required.");
        if (string.IsNullOrWhiteSpace(make)) return BadRequest("Make is required.");
        if (string.IsNullOrWhiteSpace(model)) return BadRequest("Model is required.");

        var vehicle = new Vehicle
        {
            CustomerId = dto.CustomerId,
            RegistrationNumber = regNo,
            Make = make,
            Model = model,
            Year = dto.Year,
            VehicleType = string.IsNullOrWhiteSpace(dto.VehicleType) ? null : dto.VehicleType.Trim()
        };

        _db.Vehicles.Add(vehicle);

        try
        {
            await _db.SaveChangesAsync();
        }
        catch (DbUpdateException)
        {
            return BadRequest("RegistrationNumber must be unique.");
        }

        var res = new VehicleResponseDto(
            vehicle.Id,
            vehicle.CustomerId,
            vehicle.RegistrationNumber,
            vehicle.Make,
            vehicle.Model,
            vehicle.Year,
            vehicle.VehicleType);

        return CreatedAtAction(nameof(GetById), new { id = vehicle.Id }, res);
    }

    // -------------------- CREATE (CUSTOMER: MY VEHICLE) --------------------
    // Customer does NOT send CustomerId. We auto-link using logged-in customer profile.
    [HttpPost("my")]
    [Authorize(Roles = AppRoles.Customer)]
    public async Task<ActionResult<VehicleResponseDto>> CreateMyVehicle([FromBody] CreateMyVehicleRequestDto dto)
    {
        var customer = await GetLoggedInCustomerAsync();
        if (customer is null) return StatusCode(403, "Customer profile not linked with this login.");

        var regNo = (dto.RegistrationNumber ?? "").Trim();
        var make = (dto.Make ?? "").Trim();
        var model = (dto.Model ?? "").Trim();

        if (string.IsNullOrWhiteSpace(regNo)) return BadRequest("RegistrationNumber is required.");
        if (string.IsNullOrWhiteSpace(make)) return BadRequest("Make is required.");
        if (string.IsNullOrWhiteSpace(model)) return BadRequest("Model is required.");

        var vehicle = new Vehicle
        {
            CustomerId = customer.Id,
            RegistrationNumber = regNo,
            Make = make,
            Model = model,
            Year = dto.Year,
            VehicleType = string.IsNullOrWhiteSpace(dto.VehicleType) ? null : dto.VehicleType.Trim()
        };

        _db.Vehicles.Add(vehicle);

        try
        {
            await _db.SaveChangesAsync();
        }
        catch (DbUpdateException)
        {
            return BadRequest("RegistrationNumber must be unique.");
        }

        var res = new VehicleResponseDto(
            vehicle.Id,
            vehicle.CustomerId,
            vehicle.RegistrationNumber,
            vehicle.Make,
            vehicle.Model,
            vehicle.Year,
            vehicle.VehicleType);

        return CreatedAtAction(nameof(GetById), new { id = vehicle.Id }, res);
    }

    // -------------------- LIST (ADMIN/MANAGER) --------------------
    [HttpGet]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<ActionResult<List<VehicleResponseDto>>> GetAll()
    {
        var list = await _db.Vehicles
            .AsNoTracking()
            .OrderBy(x => x.Id)
            .Select(x => new VehicleResponseDto(x.Id, x.CustomerId, x.RegistrationNumber, x.Make, x.Model, x.Year, x.VehicleType))
            .ToListAsync();

        return Ok(list);
    }

    // -------------------- BY CUSTOMER (ADMIN/MANAGER) --------------------
    [HttpGet("by-customer/{customerId:int}")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<ActionResult<List<VehicleResponseDto>>> GetByCustomer(int customerId)
    {
        var list = await _db.Vehicles
            .AsNoTracking()
            .Where(x => x.CustomerId == customerId)
            .OrderBy(x => x.Id)
            .Select(x => new VehicleResponseDto(x.Id, x.CustomerId, x.RegistrationNumber, x.Make, x.Model, x.Year, x.VehicleType))
            .ToListAsync();

        return Ok(list);
    }

    // -------------------- CUSTOMER: MY VEHICLES --------------------
    [HttpGet("my")]
    [Authorize(Roles = AppRoles.Customer)]
    public async Task<ActionResult<List<VehicleResponseDto>>> MyVehicles()
    {
        var userId = GetUserId();
        if (string.IsNullOrWhiteSpace(userId))
        {
            Console.WriteLine("[VehiclesController.MyVehicles] ERROR: User ID not found in token.");
            return StatusCode(401, "User ID not found in token.");
        }

        var customer = await GetLoggedInCustomerAsync();
        if (customer is null)
        {
            Console.WriteLine($"[VehiclesController.MyVehicles] ERROR: Customer profile not linked with user ID: {userId}");
            return StatusCode(403, "Customer profile not linked with this login.");
        }

        try
        {
            Console.WriteLine($"[VehiclesController.MyVehicles] Fetching vehicles for customer ID: {customer.Id}");
            var list = await _db.Vehicles
                .AsNoTracking()
                .Where(v => v.CustomerId == customer.Id)
                .OrderBy(v => v.Id)
                .Select(v => new VehicleResponseDto(v.Id, v.CustomerId, v.RegistrationNumber, v.Make, v.Model, v.Year, v.VehicleType))
                .ToListAsync();

            Console.WriteLine($"[VehiclesController.MyVehicles] Successfully retrieved {list.Count} vehicles");
            return Ok(list);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[VehiclesController.MyVehicles] EXCEPTION: {ex.GetType().Name}: {ex.Message}");
            Console.WriteLine($"[VehiclesController.MyVehicles] StackTrace: {ex.StackTrace}");
            if (ex.InnerException != null)
            {
                Console.WriteLine($"[VehiclesController.MyVehicles] InnerException: {ex.InnerException.GetType().Name}: {ex.InnerException.Message}");
            }
            return StatusCode(500, $"Error retrieving vehicles: {ex.Message}");
        }
    }

    // -------------------- GET BY ID (role-safe) --------------------
    [HttpGet("{id:int}")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager},{AppRoles.Customer}")]
    public async Task<ActionResult<VehicleResponseDto>> GetById(int id)
    {
        try
        {
            Console.WriteLine($"[VehiclesController.GetById] Fetching vehicle ID: {id}");
            var v = await _db.Vehicles.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
            if (v is null)
            {
                Console.WriteLine($"[VehiclesController.GetById] Vehicle ID {id} not found");
                return NotFound();
            }

            if (User.IsInRole(AppRoles.Customer))
            {
                var userId = GetUserId();
                if (string.IsNullOrWhiteSpace(userId))
                {
                    Console.WriteLine("[VehiclesController.GetById] ERROR: User ID not found in token.");
                    return StatusCode(401, "User ID not found in token.");
                }

                var customer = await GetLoggedInCustomerAsync();
                if (customer is null)
                {
                    Console.WriteLine($"[VehiclesController.GetById] ERROR: Customer profile not linked with user ID: {userId}");
                    return StatusCode(403, "Customer profile not linked.");
                }

                if (v.CustomerId != customer.Id)
                {
                    Console.WriteLine($"[VehiclesController.GetById] ERROR: Vehicle {id} belongs to customer {v.CustomerId}, but logged-in customer is {customer.Id}");
                    return StatusCode(403, "You can access only your own vehicle.");
                }
            }

            Console.WriteLine($"[VehiclesController.GetById] Successfully retrieved vehicle ID: {id}");
            return Ok(new VehicleResponseDto(v.Id, v.CustomerId, v.RegistrationNumber, v.Make, v.Model, v.Year, v.VehicleType));
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[VehiclesController.GetById] EXCEPTION: {ex.GetType().Name}: {ex.Message}");
            Console.WriteLine($"[VehiclesController.GetById] StackTrace: {ex.StackTrace}");
            if (ex.InnerException != null)
            {
                Console.WriteLine($"[VehiclesController.GetById] InnerException: {ex.InnerException.GetType().Name}: {ex.InnerException.Message}");
            }
            return StatusCode(500, $"Error retrieving vehicle: {ex.Message}");
        }
    }

    // -------------------- UPDATE (ADMIN/MANAGER + CUSTOMER OWN) --------------------
    [HttpPut("{id:int}")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager},{AppRoles.Customer}")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateVehicleRequestDto dto)
    {
        var vehicle = await _db.Vehicles.FirstOrDefaultAsync(x => x.Id == id);
        if (vehicle is null) return NotFound();

        if (User.IsInRole(AppRoles.Customer))
        {
            var customer = await GetLoggedInCustomerAsync();
            if (customer is null) return StatusCode(403, "Customer profile not linked with this login.");

            if (vehicle.CustomerId != customer.Id)
                return StatusCode(403, "You can edit only your own vehicle.");
        }

        var regNo = (dto.RegistrationNumber ?? "").Trim();
        var make = (dto.Make ?? "").Trim();
        var model = (dto.Model ?? "").Trim();

        if (string.IsNullOrWhiteSpace(regNo)) return BadRequest("RegistrationNumber is required.");
        if (string.IsNullOrWhiteSpace(make)) return BadRequest("Make is required.");
        if (string.IsNullOrWhiteSpace(model)) return BadRequest("Model is required.");

        vehicle.RegistrationNumber = regNo;
        vehicle.Make = make;
        vehicle.Model = model;
        vehicle.Year = dto.Year;
        vehicle.VehicleType = string.IsNullOrWhiteSpace(dto.VehicleType) ? null : dto.VehicleType.Trim();

        try
        {
            await _db.SaveChangesAsync();
        }
        catch (DbUpdateException)
        {
            return BadRequest("RegistrationNumber must be unique.");
        }

        return NoContent();
    }

    // -------------------- DELETE (ADMIN/MANAGER + CUSTOMER OWN) --------------------
    [HttpDelete("{id:int}")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager},{AppRoles.Customer}")]
    public async Task<IActionResult> Delete(int id)
    {
        var vehicle = await _db.Vehicles.FirstOrDefaultAsync(x => x.Id == id);
        if (vehicle is null) return NotFound();

        if (User.IsInRole(AppRoles.Customer))
        {
            var customer = await GetLoggedInCustomerAsync();
            if (customer is null) return StatusCode(403, "Customer profile not linked with this login.");

            if (vehicle.CustomerId != customer.Id)
                return StatusCode(403, "You can delete only your own vehicle.");
        }

        _db.Vehicles.Remove(vehicle);
        await _db.SaveChangesAsync();

        return NoContent();
    }
}
