﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Vsm.Api.Dtos.Reports;
using Vsm.Domain.Enums;
using Vsm.Infrastructure.Data;
using Vsm.Infrastructure.Identity;

namespace Vsm.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
public class ReportsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;

    public ReportsController(AppDbContext db, UserManager<ApplicationUser> userManager)
    {
        _db = db;
        _userManager = userManager;
    }

   
    [HttpGet("summary")]
    public async Task<ActionResult<ServiceSummaryReportDto>> Summary()
    {
        var total = await _db.ServiceRequests.AsNoTracking().CountAsync();

        var requested = await _db.ServiceRequests.AsNoTracking().CountAsync(x => x.Status == ServiceRequestStatus.Requested);
        var assigned = await _db.ServiceRequests.AsNoTracking().CountAsync(x => x.Status == ServiceRequestStatus.Assigned);
        var inProg = await _db.ServiceRequests.AsNoTracking().CountAsync(x => x.Status == ServiceRequestStatus.InProgress);
        var completed = await _db.ServiceRequests.AsNoTracking().CountAsync(x => x.Status == ServiceRequestStatus.Completed);
        var closed = await _db.ServiceRequests.AsNoTracking().CountAsync(x => x.Status == ServiceRequestStatus.Closed);
        var cancelled = await _db.ServiceRequests.AsNoTracking().CountAsync(x => x.Status == ServiceRequestStatus.Cancelled);

        var pending = requested + assigned + inProg;

        // Calculate revenue totals from paid invoices
        // Note: SQLite doesn't support Sum on decimal directly, so we materialize and sum in memory
        var paidInvoices = await _db.Invoices
            .AsNoTracking()
            .Where(i => i.IsPaid)
            .Select(i => i.TotalAmount)
            .ToListAsync();
        var totalRevenue = paidInvoices.Sum();

        // Calculate monthly revenue (current month, based on Indian Standard Time)
        var now = TimeZoneHelper.NowInIst;
        var monthlyPaidInvoices = await _db.Invoices
            .AsNoTracking()
            .Where(i => i.IsPaid && i.GeneratedAtUtc.Year == now.Year && i.GeneratedAtUtc.Month == now.Month)
            .Select(i => i.TotalAmount)
            .ToListAsync();
        var monthlyRevenue = monthlyPaidInvoices.Sum();

        return Ok(new ServiceSummaryReportDto(
            total,
            requested,
            assigned,
            inProg,
            completed,
            closed,
            cancelled,
            pending,
            totalRevenue,
            monthlyRevenue
        ));
    }

    
    [HttpGet("technician-workload")]
    public async Task<ActionResult<List<TechnicianWorkloadDto>>> TechnicianWorkload()
    {
        var grouped = await _db.ServiceRequests
            .AsNoTracking()
            .Where(x => x.AssignedTechnicianUserId != null)
            .GroupBy(x => x.AssignedTechnicianUserId!)
            .Select(g => new
            {
                TechnicianUserId = g.Key,
                TotalAssigned = g.Count(),
                InProgress = g.Count(x => x.Status == ServiceRequestStatus.InProgress),
                Completed = g.Count(x => x.Status == ServiceRequestStatus.Completed),
                Closed = g.Count(x => x.Status == ServiceRequestStatus.Closed)
            })
            .OrderByDescending(x => x.TotalAssigned)
            .ToListAsync();

        var ids = grouped.Select(x => x.TechnicianUserId).ToList();

        var idToName = await _userManager.Users
            .Where(u => ids.Contains(u.Id))
            .Select(u => new { u.Id, u.UserName })
            .ToDictionaryAsync(x => x.Id, x => x.UserName ?? "");

        var result = grouped.Select(x => new TechnicianWorkloadDto(
            x.TechnicianUserId,
            idToName.TryGetValue(x.TechnicianUserId, out var name) ? name : "(unknown)",
            x.TotalAssigned,
            x.InProgress,
            x.Completed,
            x.Closed
        )).ToList();

        return Ok(result);
    }


    [HttpGet("monthly")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<ActionResult<List<MonthlyReportDto>>> Monthly([FromQuery] int year)
    {
        if (year < 2000 || year > 2100) return BadRequest("Invalid year.");

        var allRequests = await _db.ServiceRequests
            .AsNoTracking()
            .Where(s => s.RequestedAtUtc.Year == year)
            .ToListAsync();

        var rows = allRequests
            .GroupBy(s => new { Year = s.RequestedAtUtc.Year, Month = s.RequestedAtUtc.Month })
            .Select(g => new MonthlyReportDto(
                g.Key.Year,
                g.Key.Month,
                g.Count(),
                g.Count(x => x.Status == ServiceRequestStatus.Requested),
                g.Count(x => x.Status == ServiceRequestStatus.Assigned),
                g.Count(x => x.Status == ServiceRequestStatus.InProgress),
                g.Count(x => x.Status == ServiceRequestStatus.Completed),
                g.Count(x => x.Status == ServiceRequestStatus.Closed),
                g.Count(x => x.Status == ServiceRequestStatus.Cancelled)
            ))
            .OrderBy(x => x.Year)
            .ThenBy(x => x.Month)
            .ToList();

        return Ok(rows);
    }


   
    [HttpGet("vehicle/{vehicleId:int}/history")]
    public async Task<ActionResult<List<VehicleHistoryDto>>> VehicleHistory(int vehicleId)
    {
        var list = await _db.ServiceRequests
            .AsNoTracking()
            .Where(x => x.VehicleId == vehicleId)
            .OrderByDescending(x => x.Id)
            .Select(x => new VehicleHistoryDto(
                x.Id,
                x.VehicleId,
                x.CustomerId,
                x.IssueDescription,
                x.Priority,
                x.Status,
                x.Remarks,
                x.RequestedAtUtc,
                x.ScheduledAtUtc,
                x.CompletedAtUtc,
                x.ClosedAtUtc,
                x.CancelledAtUtc
            ))
            .ToListAsync();

        return Ok(list);
    }

    // -------------------- MONTHLY REVENUE REPORT --------------------
    [HttpGet("revenue/monthly")]
    public async Task<ActionResult<List<MonthlyRevenueDto>>> MonthlyRevenue([FromQuery] int year)
    {
        if (year < 2000 || year > 2100) return BadRequest("Invalid year.");

        var allInvoices = await _db.Invoices
            .AsNoTracking()
            .Where(i => i.GeneratedAtUtc.Year == year && i.IsPaid)
            .ToListAsync();

        var rows = allInvoices
            .GroupBy(i => new { Year = i.GeneratedAtUtc.Year, Month = i.GeneratedAtUtc.Month })
            .Select(g => new MonthlyRevenueDto(
                g.Key.Year,
                g.Key.Month,
                g.Sum(i => i.TotalAmount),
                g.Count(),
                g.Sum(i => i.PartsTotal),
                g.Sum(i => i.LaborCharge),
                g.Sum(i => i.TaxAmount)
            ))
            .OrderBy(x => x.Year)
            .ThenBy(x => x.Month)
            .ToList();

        return Ok(rows);
    }

    // -------------------- REVENUE BY SERVICE CATEGORY --------------------
    [HttpGet("revenue/by-category")]
    public async Task<ActionResult<List<RevenueByCategoryDto>>> RevenueByCategory([FromQuery] int? year = null)
    {
        var query = _db.Invoices
            .AsNoTracking()
            .Include(i => i.ServiceRequest)
                .ThenInclude(sr => sr!.ServiceCategory)
            .Where(i => i.IsPaid);

        if (year.HasValue)
        {
            if (year.Value < 2000 || year.Value > 2100) return BadRequest("Invalid year.");
            var startDate = new DateTime(year.Value, 1, 1);
            var endDate = new DateTime(year.Value, 12, 31, 23, 59, 59);
            query = query.Where(i => i.GeneratedAtUtc >= startDate && i.GeneratedAtUtc <= endDate);
        }

        var grouped = await query
            .GroupBy(i => new
            {
                CategoryId = i.ServiceRequest!.ServiceCategoryId,
                CategoryName = i.ServiceRequest.ServiceCategory != null ? i.ServiceRequest.ServiceCategory.Name : "Uncategorized"
            })
            .Select(g => new RevenueByCategoryDto(
                g.Key.CategoryId,
                g.Key.CategoryName,
                g.Sum(i => i.TotalAmount),
                g.Count(),
                g.Sum(i => i.PartsTotal),
                g.Sum(i => i.LaborCharge),
                g.Sum(i => i.TaxAmount),
                g.Average(i => i.TotalAmount)
            ))
            .OrderByDescending(x => x.TotalRevenue)
            .ToListAsync();

        return Ok(grouped);
    }

    // -------------------- GROUP BY SERVICE CATEGORY --------------------
    [HttpGet("by-category")]
    public async Task<ActionResult<List<ServiceCategoryReportDto>>> ByCategory([FromQuery] ServiceRequestStatus? status = null)
    {
        var query = _db.ServiceRequests
            .AsNoTracking()
            .Include(x => x.ServiceCategory)
            .AsQueryable();

        if (status.HasValue)
            query = query.Where(x => x.Status == status.Value);

        var grouped = await query
            .GroupBy(x => new
            {
                CategoryId = x.ServiceCategoryId,
                CategoryName = x.ServiceCategory != null ? x.ServiceCategory.Name : "Uncategorized"
            })
            .Select(g => new ServiceCategoryReportDto(
                g.Key.CategoryId,
                g.Key.CategoryName,
                g.Count(),
                g.Count(x => x.Status == ServiceRequestStatus.Requested),
                g.Count(x => x.Status == ServiceRequestStatus.Assigned),
                g.Count(x => x.Status == ServiceRequestStatus.InProgress),
                g.Count(x => x.Status == ServiceRequestStatus.Completed),
                g.Count(x => x.Status == ServiceRequestStatus.Closed),
                g.Count(x => x.Status == ServiceRequestStatus.Cancelled)
            ))
            .OrderByDescending(x => x.TotalRequests)
            .ToListAsync();

        return Ok(grouped);
    }

    // -------------------- SERVICE REQUESTS BY CATEGORY --------------------
    [HttpGet("service-requests/by-category/{categoryId:int}")]
    public async Task<ActionResult<List<ServiceRequestByCategoryDto>>> ServiceRequestsByCategory(
        int categoryId,
        [FromQuery] ServiceRequestStatus? status = null)
    {
        var categoryExists = await _db.ServiceCategories.AnyAsync(c => c.Id == categoryId);
        if (!categoryExists) return NotFound("Service category not found.");

        var query = _db.ServiceRequests
            .AsNoTracking()
            .Include(x => x.ServiceCategory)
            .Where(x => x.ServiceCategoryId == categoryId);

        if (status.HasValue)
            query = query.Where(x => x.Status == status.Value);

        var list = await query
            .OrderByDescending(x => x.Id)
            .Select(x => new ServiceRequestByCategoryDto(
                x.Id,
                x.CustomerId,
                x.VehicleId,
                x.IssueDescription,
                x.Priority,
                x.Status,
                x.Remarks,
                x.ServiceCategoryId,
                x.ServiceCategory != null ? x.ServiceCategory.Name : null,
                x.RequestedAtUtc,
                x.ScheduledAtUtc,
                x.CompletedAtUtc,
                x.ClosedAtUtc
            ))
            .ToListAsync();

        return Ok(list);
    }
}
