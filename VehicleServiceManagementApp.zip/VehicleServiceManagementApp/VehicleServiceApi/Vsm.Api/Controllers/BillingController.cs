﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Vsm.Api.Dtos.Billing;
using Vsm.Api.Notifications;
using Vsm.Domain.Entities;
using Vsm.Infrastructure.Data;
using Vsm.Infrastructure.Identity;

namespace Vsm.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class BillingController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;

    public BillingController(AppDbContext db, UserManager<ApplicationUser> userManager)
    {
        _db = db;
        _userManager = userManager;
    }

    private string? GetUserId()
        => User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub");

    private async Task<Customer?> GetLoggedInCustomerAsync()
    {
        var userId = GetUserId();
        if (string.IsNullOrWhiteSpace(userId)) return null;

        return await _db.Customers.AsNoTracking()
            .FirstOrDefaultAsync(c => c.ApplicationUserId == userId);
    }

    private static Task EnqueueAsync(NotificationEvent evt)
        => NotificationQueue.Channel.Writer.WriteAsync(evt).AsTask();

    private async Task<string?> GetCustomerUserIdForServiceRequestAsync(int serviceRequestId)
    {
        return await _db.ServiceRequests.AsNoTracking()
            .Where(sr => sr.Id == serviceRequestId)
            .Join(_db.Customers.AsNoTracking(),
                sr => sr.CustomerId,
                c => c.Id,
                (sr, c) => c.ApplicationUserId)
            .FirstOrDefaultAsync();
    }

    private async Task<List<string>> GetServiceManagerUserIdsAsync()
    {
        var serviceManagers = await _userManager.GetUsersInRoleAsync(AppRoles.ServiceManager);
        return serviceManagers.Select(u => u.Id).ToList();
    }

    // -------------------- GENERATE INVOICE (Admin/Manager) --------------------
    [HttpPost("service-requests/{serviceRequestId:int}/generate")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<ActionResult<InvoiceResponseDto>> Generate(
        int serviceRequestId,
        [FromBody] GenerateInvoiceRequestDto dto)
    {
        if (dto is null) return BadRequest("Body is required.");
        if (dto.LaborCharge.HasValue && dto.LaborCharge.Value < 0) return BadRequest("LaborCharge cannot be negative.");
        if (dto.TaxRate < 0) return BadRequest("TaxRate cannot be negative.");

        var sr = await _db.ServiceRequests.AsNoTracking()
            .Include(x => x.ServiceCategory)
            .FirstOrDefaultAsync(x => x.Id == serviceRequestId);

        if (sr is null) return NotFound("ServiceRequest not found.");

        if (sr.Status != Domain.Enums.ServiceRequestStatus.Completed &&
            sr.Status != Domain.Enums.ServiceRequestStatus.Closed)
            return BadRequest("Invoice can be generated only after service request is Completed/Closed.");

        var already = await _db.Invoices.AnyAsync(x => x.ServiceRequestId == serviceRequestId);
        if (already) return BadRequest("Invoice already exists for this service request.");

        // ✅ Determine labor charge: use provided value, or ServiceCategory.BasePrice, or 0
        decimal laborCharge = 0;
        string laborItemName = "Service Labor";
        
        if (dto.LaborCharge.HasValue && dto.LaborCharge.Value > 0)
        {
            laborCharge = dto.LaborCharge.Value;
        }
        else if (sr.ServiceCategoryId.HasValue && sr.ServiceCategory != null)
        {
            laborCharge = sr.ServiceCategory.BasePrice;
            laborItemName = $"{sr.ServiceCategory.Name} Service";
        }

        var usages = await _db.ServicePartUsages.AsNoTracking()
            .Where(x => x.ServiceRequestId == serviceRequestId)
            .Join(_db.Parts.AsNoTracking(),
                u => u.PartId,
                p => p.Id,
                (u, p) => new { p.PartNumber, p.Name, u.Quantity, u.UnitPriceAtUse })
            .ToListAsync();

        var lines = new List<InvoiceLine>();

        foreach (var u in usages)
        {
            var lineTotal = u.UnitPriceAtUse * u.Quantity;
            lines.Add(new InvoiceLine
            {
                ItemType = "Part",
                ItemName = u.Name,
                ItemCode = u.PartNumber,
                Quantity = u.Quantity,
                UnitPrice = u.UnitPriceAtUse,
                LineTotal = lineTotal
            });
        }

        if (laborCharge > 0)
        {
            lines.Add(new InvoiceLine
            {
                ItemType = "Labor",
                ItemName = laborItemName,
                ItemCode = null,
                Quantity = 1,
                UnitPrice = laborCharge,
                LineTotal = laborCharge
            });
        }

        var partsTotal = lines.Where(x => x.ItemType == "Part").Sum(x => x.LineTotal);
        var labor = laborCharge;
        var subTotal = partsTotal + labor;

        var taxAmount = Math.Round(subTotal * dto.TaxRate, 2);
        var total = Math.Round(subTotal + taxAmount, 2);

        var invoice = new Invoice
        {
            ServiceRequestId = serviceRequestId,

            // ✅ Explicit enum avoids ambiguity
            Status = Vsm.Domain.Entities.InvoiceStatus.Generated,

            LaborCharge = labor,
            PartsTotal = partsTotal,
            TaxRate = dto.TaxRate,
            TaxAmount = taxAmount,
            TotalAmount = total,
            IsPaid = false,
            GeneratedAtUtc = DateTime.UtcNow,
            Lines = lines
        };

        _db.Invoices.Add(invoice);
        await _db.SaveChangesAsync();

        // ✅ Notification: Invoice Generated -> Customer
        var customerUserId = await GetCustomerUserIdForServiceRequestAsync(serviceRequestId);
        if (!string.IsNullOrWhiteSpace(customerUserId))
        {
            await EnqueueAsync(new NotificationEvent(
                UserId: customerUserId!,
                Title: "Invoice Generated",
                Message: $"Service Completed. Invoice #{invoice.Id} has been generated. Please view and pay to close the request.",
                Type: "Billing",
                RelatedServiceRequestId: serviceRequestId,
                RelatedInvoiceId: invoice.Id
            ));
        }

        // ✅ Notification: Invoice Generated -> Service Manager
        var serviceManagerUserIds = await GetServiceManagerUserIdsAsync();
        foreach (var managerUserId in serviceManagerUserIds)
        {
            await EnqueueAsync(new NotificationEvent(
                UserId: managerUserId,
                Title: "Invoice Generated",
                Message: $"Invoice #{invoice.Id} generated for Request #{serviceRequestId}.",
                Type: "Billing",
                RelatedServiceRequestId: serviceRequestId,
                RelatedInvoiceId: invoice.Id
            ));
        }

        var dtoRes = await BuildInvoiceDto(invoice.Id);
        return CreatedAtAction(nameof(GetById), new { id = invoice.Id }, dtoRes);
    }

    // -------------------- LIST INVOICES (Admin/Manager) --------------------
    [HttpGet]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<ActionResult<List<InvoiceResponseDto>>> List(
        [FromQuery] bool? isPaid,
        [FromQuery] int? serviceRequestId)
    {
        var q = _db.Invoices.AsNoTracking().Include(x => x.Lines).AsQueryable();

        if (isPaid.HasValue) q = q.Where(x => x.IsPaid == isPaid.Value);
        if (serviceRequestId.HasValue) q = q.Where(x => x.ServiceRequestId == serviceRequestId.Value);

        var invoices = await q.OrderByDescending(x => x.Id).ToListAsync();
        return Ok(invoices.Select(ToInvoiceDto).ToList());
    }

    // -------------------- GET INVOICE BY ID (role-safe) --------------------
    [HttpGet("{id:int}")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager},{AppRoles.Technician},{AppRoles.Customer}")]
    public async Task<ActionResult<InvoiceResponseDto>> GetById(int id)
    {
        var inv = await _db.Invoices.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        if (inv is null) return NotFound();

        if (User.IsInRole(AppRoles.Customer) || User.IsInRole(AppRoles.Technician))
        {
            var sr = await _db.ServiceRequests.AsNoTracking()
                .FirstOrDefaultAsync(x => x.Id == inv.ServiceRequestId);

            if (sr is null) return NotFound("ServiceRequest not found for invoice.");

            if (User.IsInRole(AppRoles.Customer))
            {
                var customer = await GetLoggedInCustomerAsync();
                if (customer is null) return Forbid();
                if (sr.CustomerId != customer.Id) return Forbid();
            }

            if (User.IsInRole(AppRoles.Technician))
            {
                var techId = GetUserId();
                if (string.IsNullOrWhiteSpace(techId)) return Unauthorized();
                if (sr.AssignedTechnicianUserId != techId) return Forbid();
            }
        }

        return Ok(await BuildInvoiceDto(id));
    }

    // -------------------- GET BY SERVICE REQUEST ID --------------------
    [HttpGet("by-service-request/{serviceRequestId:int}")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager},{AppRoles.Technician},{AppRoles.Customer}")]
    public async Task<ActionResult<InvoiceResponseDto>> GetByServiceRequest(int serviceRequestId)
    {
        var inv = await _db.Invoices.AsNoTracking()
            .FirstOrDefaultAsync(x => x.ServiceRequestId == serviceRequestId);

        if (inv is null) return NotFound("Invoice not found for this service request.");
        return await GetById(inv.Id);
    }

    // -------------------- CUSTOMER: MY INVOICES --------------------
    [HttpGet("my")]
    [Authorize(Roles = AppRoles.Customer)]
    public async Task<ActionResult<List<InvoiceResponseDto>>> MyInvoices()
    {
        var customer = await GetLoggedInCustomerAsync();
        if (customer is null) return StatusCode(403, "Customer profile not linked.");

        var invoices = await _db.Invoices
            .AsNoTracking()
            .Include(x => x.Lines)
            .Join(_db.ServiceRequests.AsNoTracking(),
                i => i.ServiceRequestId,
                sr => sr.Id,
                (i, sr) => new { Invoice = i, sr.CustomerId })
            .Where(x => x.CustomerId == customer.Id)
            .Select(x => x.Invoice)
            .OrderByDescending(x => x.Id)
            .ToListAsync();

        return Ok(invoices.Select(ToInvoiceDto).ToList());
    }

    // -------------------- PAY INVOICE --------------------
    [HttpPut("{id:int}/pay")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager},{AppRoles.Customer}")]
    public async Task<ActionResult<InvoiceResponseDto>> Pay(int id, [FromBody] PayInvoiceRequestDto dto)
    {
        if (dto is null) return BadRequest("Body is required.");

        var inv = await _db.Invoices.FirstOrDefaultAsync(x => x.Id == id);
        if (inv is null) return NotFound();

        if (inv.IsPaid) return BadRequest("Invoice is already paid.");

        var refNo = (dto.PaymentReference ?? "").Trim();
        if (string.IsNullOrWhiteSpace(refNo)) return BadRequest("PaymentReference is required.");

        if (User.IsInRole(AppRoles.Customer))
        {
            var customer = await GetLoggedInCustomerAsync();
            if (customer is null) return Forbid();

            var sr = await _db.ServiceRequests.AsNoTracking()
                .FirstOrDefaultAsync(x => x.Id == inv.ServiceRequestId);

            if (sr is null) return NotFound("ServiceRequest not found for invoice.");
            if (sr.CustomerId != customer.Id) return Forbid();
        }

        inv.IsPaid = true;
        inv.PaidAtUtc = DateTime.UtcNow;
        inv.PaymentReference = refNo;

        // ✅ Explicit enum avoids ambiguity
        inv.Status = Vsm.Domain.Entities.InvoiceStatus.Paid;

        await _db.SaveChangesAsync();

        // ✅ AUTO-CLOSE SERVICE REQUEST when invoice is paid
        var serviceRequest = await _db.ServiceRequests.FirstOrDefaultAsync(x => x.Id == inv.ServiceRequestId);
        string? technicianUserId = null;
        
        if (serviceRequest != null)
        {
            // Store technician ID before closing the request
            technicianUserId = serviceRequest.AssignedTechnicianUserId;
            
            if (serviceRequest.Status != Domain.Enums.ServiceRequestStatus.Closed)
            {
                serviceRequest.Status = Domain.Enums.ServiceRequestStatus.Closed;
                serviceRequest.ClosedAtUtc = DateTime.UtcNow;
                
                // Log status change in remarks if not already set
                var statusChangeNote = "Request closed automatically via payment.";
                if (string.IsNullOrWhiteSpace(serviceRequest.Remarks))
                {
                    serviceRequest.Remarks = statusChangeNote;
                }
                else if (!serviceRequest.Remarks.Contains(statusChangeNote))
                {
                    serviceRequest.Remarks = $"{serviceRequest.Remarks.Trim()}. {statusChangeNote}";
                }

                await _db.SaveChangesAsync();
            }
        }

        // ✅ Notification: Payment Made -> Customer
        var customerUserId = await GetCustomerUserIdForServiceRequestAsync(inv.ServiceRequestId);
        if (!string.IsNullOrWhiteSpace(customerUserId))
        {
            await EnqueueAsync(new NotificationEvent(
                UserId: customerUserId!,
                Title: "Payment Successful",
                Message: $"Payment Successful. Thank you! Your Service Request #{inv.ServiceRequestId} is now Closed.",
                Type: "Billing",
                RelatedServiceRequestId: inv.ServiceRequestId,
                RelatedInvoiceId: inv.Id
            ));
        }

        // ✅ Notification: Payment Made -> Service Manager
        var serviceManagerUserIds = await GetServiceManagerUserIdsAsync();
        foreach (var managerUserId in serviceManagerUserIds)
        {
            await EnqueueAsync(new NotificationEvent(
                UserId: managerUserId,
                Title: "Payment Received",
                Message: $"Payment Received for Invoice #{inv.Id}. Request #{inv.ServiceRequestId} is now Closed.",
                Type: "Billing",
                RelatedServiceRequestId: inv.ServiceRequestId,
                RelatedInvoiceId: inv.Id
            ));
        }

        // ✅ Notification: Payment Made -> Assigned Technician
        if (!string.IsNullOrWhiteSpace(technicianUserId))
        {
            await EnqueueAsync(new NotificationEvent(
                UserId: technicianUserId,
                Title: "Payment Received",
                Message: $"Payment Received for Request #{inv.ServiceRequestId}. Job is now closed.",
                Type: "Billing",
                RelatedServiceRequestId: inv.ServiceRequestId,
                RelatedInvoiceId: inv.Id
            ));
        }

        return Ok(await BuildInvoiceDto(id));
    }

    // -------------------- helpers --------------------
    private async Task<InvoiceResponseDto> BuildInvoiceDto(int invoiceId)
    {
        var inv = await _db.Invoices.AsNoTracking()
            .Include(x => x.Lines)
            .FirstAsync(x => x.Id == invoiceId);

        return ToInvoiceDto(inv);
    }

    private static InvoiceResponseDto ToInvoiceDto(Invoice inv)
    {
        var lines = (inv.Lines ?? new List<InvoiceLine>())
            .OrderBy(x => x.ItemType)
            .ThenBy(x => x.ItemName)
            .Select(x => new InvoiceLineDto(
                x.Id, x.ItemType, x.ItemName, x.ItemCode, x.Quantity, x.UnitPrice, x.LineTotal
            ))
            .ToList();

        return new InvoiceResponseDto(
     inv.Id,
     inv.ServiceRequestId,
     inv.Status,
     inv.LaborCharge,
     inv.PartsTotal,
     inv.TaxRate,
     inv.TaxAmount,
     inv.TotalAmount,
     inv.IsPaid,
     inv.GeneratedAtUtc,
     inv.PaidAtUtc,
     inv.PaymentReference,
     lines
 );

    }
}
