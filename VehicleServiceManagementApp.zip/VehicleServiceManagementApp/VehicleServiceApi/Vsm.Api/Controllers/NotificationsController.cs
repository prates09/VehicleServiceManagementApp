﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Vsm.Infrastructure.Data;
using Vsm.Infrastructure.Identity;

namespace Vsm.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class NotificationsController : ControllerBase
{
    private readonly AppDbContext _db;

    public NotificationsController(AppDbContext db)
    {
        _db = db;
    }

    private string? GetUserId()
        => User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub");

    // ✅ Get latest notifications for logged-in user
    [HttpGet("my")]
    public async Task<IActionResult> My([FromQuery] int take = 20)
    {
        if (take < 1) take = 20;
        if (take > 100) take = 100;

        var userId = GetUserId();
        if (string.IsNullOrWhiteSpace(userId)) return Unauthorized();

        var data = await _db.Notifications
            .AsNoTracking()
            .Where(n => n.UserId == userId)
            .OrderByDescending(n => n.CreatedAtUtc)
            .Take(take)
            .Select(n => new
            {
                n.Id,
                n.Title,
                n.Message,
                n.Type,
                n.RelatedServiceRequestId,
                n.RelatedInvoiceId,
                n.CreatedAtUtc,
                n.IsRead,
                n.ReadAtUtc
            })
            .ToListAsync();

        return Ok(data);
    }

    // ✅ Mark one notification as read (logged-in user's own)
    [HttpPut("{id:int}/read")]
    public async Task<IActionResult> MarkRead(int id)
    {
        var userId = GetUserId();
        if (string.IsNullOrWhiteSpace(userId)) return Unauthorized();

        var n = await _db.Notifications.FirstOrDefaultAsync(x => x.Id == id && x.UserId == userId);
        if (n is null) return NotFound();

        if (!n.IsRead)
        {
            n.IsRead = true;
            n.ReadAtUtc = DateTime.UtcNow;
            await _db.SaveChangesAsync();
        }

        return NoContent();
    }

    // ✅ Unread count (nice for UI badge)
    [HttpGet("my/unread-count")]
    public async Task<IActionResult> UnreadCount()
    {
        var userId = GetUserId();
        if (string.IsNullOrWhiteSpace(userId)) return Unauthorized();

        var count = await _db.Notifications
            .AsNoTracking()
            .CountAsync(n => n.UserId == userId && !n.IsRead);

        return Ok(new { unread = count });
    }

    // ✅ Admin/Manager can view latest notifications for auditing (optional)
    [HttpGet("latest")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<IActionResult> Latest([FromQuery] int take = 50)
    {
        if (take < 1) take = 50;
        if (take > 200) take = 200;

        var data = await _db.Notifications
            .AsNoTracking()
            .OrderByDescending(n => n.CreatedAtUtc)
            .Take(take)
            .Select(n => new
            {
                n.Id,
                n.UserId,
                n.Title,
                n.Message,
                n.Type,
                n.RelatedServiceRequestId,
                n.RelatedInvoiceId,
                n.CreatedAtUtc,
                n.IsRead,
                n.ReadAtUtc
            })
            .ToListAsync();

        return Ok(data);
    }
}
