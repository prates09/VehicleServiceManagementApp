﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Vsm.Api.Dtos.ServiceRequests;
using Vsm.Api.Notifications;
using Vsm.Domain.Entities;
using Vsm.Domain.Enums;
using Vsm.Infrastructure.Data;
using Vsm.Infrastructure.Identity;

namespace Vsm.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ServiceRequestsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;

    public ServiceRequestsController(AppDbContext db, UserManager<ApplicationUser> userManager)
    {
        _db = db;
        _userManager = userManager;
    }

    private string? GetUserId()
    {
        return User.FindFirstValue(ClaimTypes.NameIdentifier)
            ?? User.FindFirstValue("sub");
    }

    private async Task<Customer?> GetLoggedInCustomerAsync()
    {
        var userId = GetUserId();
        if (string.IsNullOrWhiteSpace(userId)) return null;

        return await _db.Customers
            .AsNoTracking()
            .FirstOrDefaultAsync(c => c.ApplicationUserId == userId);
    }

    private Task EnqueueAsync(NotificationEvent evt)
        => NotificationQueue.Channel.Writer.WriteAsync(evt, HttpContext.RequestAborted).AsTask();

    private async Task<string?> GetCustomerUserIdByCustomerIdAsync(int customerId)
    {
        return await _db.Customers
            .AsNoTracking()
            .Where(c => c.Id == customerId)
            .Select(c => c.ApplicationUserId)
            .FirstOrDefaultAsync();
    }

    private async Task<List<string>> GetServiceManagerUserIdsAsync()
    {
        var serviceManagers = await _userManager.GetUsersInRoleAsync(AppRoles.ServiceManager);
        return serviceManagers.Select(u => u.Id).ToList();
    }

    private async Task<List<string>> GetAdminUserIdsAsync()
    {
        var admins = await _userManager.GetUsersInRoleAsync(AppRoles.Admin);
        return admins.Select(u => u.Id).ToList();
    }

    // -------------------- CREATE (CUSTOMER) --------------------
    [HttpPost]
    [Authorize(Roles = AppRoles.Customer)]
    public async Task<ActionResult<ServiceRequestResponseDto>> Create([FromBody] CreateServiceRequestRequestDto dto)
    {
        var customer = await GetLoggedInCustomerAsync();
        if (customer is null) return StatusCode(403, "Customer profile not linked with this login.");

        var issue = (dto.IssueDescription ?? "").Trim();
        if (string.IsNullOrWhiteSpace(issue)) return BadRequest("IssueDescription is required.");

        var vehicleBelongs = await _db.Vehicles.AnyAsync(v => v.Id == dto.VehicleId && v.CustomerId == customer.Id);
        if (!vehicleBelongs) return StatusCode(403, "You can create requests only for your own vehicle.");

        // ✅ Validate ServiceCategoryId if provided
        if (dto.ServiceCategoryId.HasValue)
        {
            var categoryExists = await _db.ServiceCategories
                .AnyAsync(c => c.Id == dto.ServiceCategoryId.Value && c.IsActive);
            if (!categoryExists) return BadRequest("Invalid or inactive service category.");
        }

        var sr = new ServiceRequest
        {
            CustomerId = customer.Id,
            VehicleId = dto.VehicleId,
            ServiceCategoryId = dto.ServiceCategoryId,
            IssueDescription = issue,
            Priority = dto.Priority,
            Status = ServiceRequestStatus.Requested,
            Remarks = null,
            AssignedTechnicianUserId = null,
            RequestedAtUtc = DateTime.UtcNow
        };

        _db.ServiceRequests.Add(sr);
        await _db.SaveChangesAsync();

        // ✅ Load category name for response
        var categoryName = sr.ServiceCategoryId.HasValue
            ? await _db.ServiceCategories
                .Where(c => c.Id == sr.ServiceCategoryId.Value)
                .Select(c => c.Name)
                .FirstOrDefaultAsync()
            : null;

        // ✅ Notification: Service Request Created -> Customer
        var customerUserId = customer.ApplicationUserId ?? GetUserId();
        if (!string.IsNullOrWhiteSpace(customerUserId))
        {
            await EnqueueAsync(new NotificationEvent(
                UserId: customerUserId,
                Title: "Service Request Received",
                Message: $"Your Service Request #{sr.Id} has been received successfully.",
                Type: "Booking",
                RelatedServiceRequestId: sr.Id
            ));
        }

        // ✅ Notification: Service Request Created -> Service Manager
        var serviceManagerUserIds = await GetServiceManagerUserIdsAsync();
        foreach (var managerUserId in serviceManagerUserIds)
        {
            await EnqueueAsync(new NotificationEvent(
                UserId: managerUserId,
                Title: "New Service Request",
                Message: $"New Service Request #{sr.Id} received from {customer.FullName}.",
                Type: "Booking",
                RelatedServiceRequestId: sr.Id
            ));
        }

        return CreatedAtAction(nameof(GetById), new { id = sr.Id },
            new ServiceRequestResponseDto(sr.Id, sr.CustomerId, sr.VehicleId, sr.IssueDescription, sr.Priority, sr.Status, sr.Remarks, sr.RequestedAtUtc, sr.ServiceCategoryId, categoryName, null, null));
    }

    // -------------------- LIST (ADMIN/MANAGER) --------------------
    [HttpGet]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<ActionResult<List<ServiceRequestResponseDto>>> GetAll(
        [FromQuery] ServiceRequestStatus? status,
        [FromQuery] ServicePriority? priority,
        [FromQuery] int? serviceCategoryId = null)
    {
        var query = _db.ServiceRequests.AsNoTracking();

        if (status.HasValue) query = query.Where(x => x.Status == status.Value);
        if (priority.HasValue) query = query.Where(x => x.Priority == priority.Value);
        if (serviceCategoryId.HasValue) query = query.Where(x => x.ServiceCategoryId == serviceCategoryId.Value);

        var serviceRequests = await query
            .Include(x => x.ServiceCategory)
            .OrderByDescending(x => x.Id)
            .ToListAsync();

        // Get all unique technician IDs
        var technicianIds = serviceRequests
            .Where(x => !string.IsNullOrWhiteSpace(x.AssignedTechnicianUserId))
            .Select(x => x.AssignedTechnicianUserId!)
            .Distinct()
            .ToList();

        // Load all technicians in one query
        var technicians = new Dictionary<string, string>();
        if (technicianIds.Count > 0)
        {
            var techUsers = await _userManager.Users
                .Where(u => technicianIds.Contains(u.Id))
                .Select(u => new { u.Id, u.UserName })
                .ToListAsync();
            
            foreach (var tech in techUsers)
            {
                if (tech.UserName != null)
                    technicians[tech.Id] = tech.UserName;
            }
        }

        var list = serviceRequests.Select(x => new ServiceRequestResponseDto(
            x.Id, x.CustomerId, x.VehicleId, x.IssueDescription, x.Priority, x.Status, x.Remarks, x.RequestedAtUtc,
            x.ServiceCategoryId, x.ServiceCategory?.Name,
            x.AssignedTechnicianUserId,
            !string.IsNullOrWhiteSpace(x.AssignedTechnicianUserId) && technicians.TryGetValue(x.AssignedTechnicianUserId, out var userName) ? userName : null))
            .ToList();

        return Ok(list);
    }

    // -------------------- GET BY ID (role-safe) --------------------
    [HttpGet("{id:int}")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager},{AppRoles.Technician},{AppRoles.Customer}")]
    public async Task<ActionResult<ServiceRequestResponseDto>> GetById(int id)
    {
        var srEntity = await _db.ServiceRequests
            .AsNoTracking()
            .Include(x => x.ServiceCategory)
            .FirstOrDefaultAsync(x => x.Id == id);
        if (srEntity is null) return NotFound();

        // Customer -> only their SR
        if (User.IsInRole(AppRoles.Customer))
        {
            var customer = await GetLoggedInCustomerAsync();
            if (customer is null) return Forbid();

            if (srEntity.CustomerId != customer.Id) return Forbid();
        }

        // Technician -> only assigned SR
        if (User.IsInRole(AppRoles.Technician))
        {
            var techId = GetUserId();
            if (string.IsNullOrWhiteSpace(techId)) return Unauthorized();

            if (srEntity.AssignedTechnicianUserId != techId) return Forbid();
        }

        // Get technician details if assigned
        string? technicianId = srEntity.AssignedTechnicianUserId;
        string? technicianUserName = null;
        if (!string.IsNullOrWhiteSpace(technicianId))
        {
            var technician = await _userManager.FindByIdAsync(technicianId);
            technicianUserName = technician?.UserName;
        }

        return Ok(new ServiceRequestResponseDto(
            srEntity.Id, srEntity.CustomerId, srEntity.VehicleId,
            srEntity.IssueDescription, srEntity.Priority, srEntity.Status, srEntity.Remarks, srEntity.RequestedAtUtc,
            srEntity.ServiceCategoryId, srEntity.ServiceCategory?.Name, technicianId, technicianUserName));
    }

    // -------------------- BY CUSTOMER (ADMIN/MANAGER or self) --------------------
    [HttpGet("by-customer/{customerId:int}")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager},{AppRoles.Customer}")]
    public async Task<ActionResult<List<ServiceRequestResponseDto>>> GetByCustomer(int customerId)
    {
        if (User.IsInRole(AppRoles.Customer))
        {
            var customer = await GetLoggedInCustomerAsync();
            if (customer is null) return Forbid();
            if (customer.Id != customerId) return Forbid();
        }

        var serviceRequests = await _db.ServiceRequests
            .AsNoTracking()
            .Include(x => x.ServiceCategory)
            .Where(x => x.CustomerId == customerId)
            .OrderByDescending(x => x.Id)
            .ToListAsync();

        // Get all unique technician IDs
        var technicianIds = serviceRequests
            .Where(x => !string.IsNullOrWhiteSpace(x.AssignedTechnicianUserId))
            .Select(x => x.AssignedTechnicianUserId!)
            .Distinct()
            .ToList();

        // Load all technicians in one query
        var technicians = new Dictionary<string, string>();
        if (technicianIds.Count > 0)
        {
            var techUsers = await _userManager.Users
                .Where(u => technicianIds.Contains(u.Id))
                .Select(u => new { u.Id, u.UserName })
                .ToListAsync();
            
            foreach (var tech in techUsers)
            {
                if (tech.UserName != null)
                    technicians[tech.Id] = tech.UserName;
            }
        }

        var list = serviceRequests.Select(x => new ServiceRequestResponseDto(
            x.Id, x.CustomerId, x.VehicleId, x.IssueDescription, x.Priority, x.Status, x.Remarks, x.RequestedAtUtc,
            x.ServiceCategoryId, x.ServiceCategory?.Name,
            x.AssignedTechnicianUserId,
            !string.IsNullOrWhiteSpace(x.AssignedTechnicianUserId) && technicians.TryGetValue(x.AssignedTechnicianUserId, out var userName) ? userName : null))
            .ToList();

        return Ok(list);
    }

    // -------------------- BY VEHICLE (ADMIN/MANAGER or customer who owns the vehicle) --------------------
    [HttpGet("by-vehicle/{vehicleId:int}")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager},{AppRoles.Customer}")]
    public async Task<ActionResult<List<ServiceRequestResponseDto>>> GetByVehicle(int vehicleId)
    {
        // Check if vehicle exists
        var vehicle = await _db.Vehicles
            .AsNoTracking()
            .FirstOrDefaultAsync(v => v.Id == vehicleId);
        if (vehicle is null) return NotFound("Vehicle not found.");

        // Customer can only see their own vehicle's history
        if (User.IsInRole(AppRoles.Customer))
        {
            var customer = await GetLoggedInCustomerAsync();
            if (customer is null) return Forbid();
            if (vehicle.CustomerId != customer.Id) return Forbid();
        }

        var serviceRequests = await _db.ServiceRequests
            .AsNoTracking()
            .Include(x => x.ServiceCategory)
            .Where(x => x.VehicleId == vehicleId)
            .OrderByDescending(x => x.RequestedAtUtc)
            .ToListAsync();

        // Get all unique technician IDs
        var technicianIds = serviceRequests
            .Where(x => !string.IsNullOrWhiteSpace(x.AssignedTechnicianUserId))
            .Select(x => x.AssignedTechnicianUserId!)
            .Distinct()
            .ToList();

        // Load all technicians in one query
        var technicians = new Dictionary<string, string>();
        if (technicianIds.Count > 0)
        {
            var techUsers = await _userManager.Users
                .Where(u => technicianIds.Contains(u.Id))
                .Select(u => new { u.Id, u.UserName })
                .ToListAsync();
            
            foreach (var tech in techUsers)
            {
                if (tech.UserName != null)
                    technicians[tech.Id] = tech.UserName;
            }
        }

        var list = serviceRequests.Select(x => new ServiceRequestResponseDto(
            x.Id, x.CustomerId, x.VehicleId, x.IssueDescription, x.Priority, x.Status, x.Remarks, x.RequestedAtUtc,
            x.ServiceCategoryId, x.ServiceCategory?.Name,
            x.AssignedTechnicianUserId,
            !string.IsNullOrWhiteSpace(x.AssignedTechnicianUserId) && technicians.TryGetValue(x.AssignedTechnicianUserId, out var userName) ? userName : null))
            .ToList();

        return Ok(list);
    }

    // -------------------- CUSTOMER: MY REQUESTS --------------------
    [HttpGet("my")]
    [Authorize(Roles = AppRoles.Customer)]
    public async Task<ActionResult<List<ServiceRequestResponseDto>>> MyRequests()
    {
        var customer = await GetLoggedInCustomerAsync();
        if (customer is null) return StatusCode(403, "Customer profile not linked.");

        var serviceRequests = await _db.ServiceRequests
            .AsNoTracking()
            .Include(x => x.ServiceCategory)
            .Where(x => x.CustomerId == customer.Id)
            .OrderByDescending(x => x.Id)
            .ToListAsync();

        // Get all unique technician IDs
        var technicianIds = serviceRequests
            .Where(x => !string.IsNullOrWhiteSpace(x.AssignedTechnicianUserId))
            .Select(x => x.AssignedTechnicianUserId!)
            .Distinct()
            .ToList();

        // Load all technicians in one query
        var technicians = new Dictionary<string, string>();
        if (technicianIds.Count > 0)
        {
            var techUsers = await _userManager.Users
                .Where(u => technicianIds.Contains(u.Id))
                .Select(u => new { u.Id, u.UserName })
                .ToListAsync();
            
            foreach (var tech in techUsers)
            {
                if (tech.UserName != null)
                    technicians[tech.Id] = tech.UserName;
            }
        }

        var list = serviceRequests.Select(x => new ServiceRequestResponseDto(
            x.Id, x.CustomerId, x.VehicleId, x.IssueDescription, x.Priority, x.Status, x.Remarks, x.RequestedAtUtc,
            x.ServiceCategoryId, x.ServiceCategory?.Name,
            x.AssignedTechnicianUserId,
            !string.IsNullOrWhiteSpace(x.AssignedTechnicianUserId) && technicians.TryGetValue(x.AssignedTechnicianUserId, out var userName) ? userName : null))
            .ToList();

        return Ok(list);
    }

    // -------------------- TECH: MY ASSIGNED --------------------
    [HttpGet("my-assigned")]
    [Authorize(Roles = AppRoles.Technician)]
    public async Task<ActionResult<List<ServiceRequestResponseDto>>> MyAssigned()
    {
        var techId = GetUserId();
        if (string.IsNullOrWhiteSpace(techId)) return Unauthorized();

        var serviceRequests = await _db.ServiceRequests
            .AsNoTracking()
            .Include(x => x.ServiceCategory)
            .Where(x => x.AssignedTechnicianUserId == techId)
            .OrderByDescending(x => x.Id)
            .ToListAsync();

        // Get technician username (should be the same for all since they're all assigned to this tech)
        var technician = await _userManager.FindByIdAsync(techId);
        var technicianUserName = technician?.UserName;

        var list = serviceRequests.Select(x => new ServiceRequestResponseDto(
            x.Id, x.CustomerId, x.VehicleId, x.IssueDescription, x.Priority, x.Status, x.Remarks, x.RequestedAtUtc,
            x.ServiceCategoryId, x.ServiceCategory?.Name,
            techId,
            technicianUserName))
            .ToList();

        return Ok(list);
    }

    // -------------------- UPDATE (ADMIN/MANAGER/CUSTOMER) --------------------
    [HttpPut("{id:int}")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager},{AppRoles.Customer}")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateServiceRequestRequestDto dto)
    {
        var sr = await _db.ServiceRequests.FirstOrDefaultAsync(x => x.Id == id);
        if (sr is null) return NotFound();

        // Security: Customers can only update their own requests, and ONLY if status is 'Requested'
        if (User.IsInRole(AppRoles.Customer))
        {
            var customer = await GetLoggedInCustomerAsync();
            if (customer is null) return Forbid();

            if (sr.CustomerId != customer.Id)
                return Forbid();

            if (sr.Status != ServiceRequestStatus.Requested)
                return BadRequest("Customers can only update requests with 'Requested' status.");
        }

        if (sr.Status is ServiceRequestStatus.Closed or ServiceRequestStatus.Cancelled)
            return BadRequest("Cannot edit a closed/cancelled service request.");

        var vehicleBelongs = await _db.Vehicles.AnyAsync(v => v.Id == dto.VehicleId && v.CustomerId == sr.CustomerId);
        if (!vehicleBelongs) return BadRequest("VehicleId not found for this ServiceRequest's Customer.");

        // ✅ Validate ServiceCategoryId if provided
        if (dto.ServiceCategoryId.HasValue)
        {
            var categoryExists = await _db.ServiceCategories
                .AnyAsync(c => c.Id == dto.ServiceCategoryId.Value && c.IsActive);
            if (!categoryExists) return BadRequest("Invalid or inactive service category.");
        }

        sr.VehicleId = dto.VehicleId;
        sr.IssueDescription = (dto.IssueDescription ?? "").Trim();
        sr.Priority = dto.Priority;
        sr.ServiceCategoryId = dto.ServiceCategoryId;

        await _db.SaveChangesAsync();
        return NoContent();
    }

    // -------------------- ASSIGN TECH (ADMIN/MANAGER) --------------------
    [HttpPut("{id:int}/assign")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<IActionResult> AssignTechnician(int id, [FromBody] AssignTechnicianDto dto)
    {
        // Validate DTO is not null
        if (dto == null)
            return BadRequest("Request body is required.");

        var sr = await _db.ServiceRequests.FirstOrDefaultAsync(x => x.Id == id);
        if (sr is null) return NotFound($"ServiceRequest with id {id} not found.");

        if (sr.Status != ServiceRequestStatus.Requested)
            return BadRequest("Only requests in 'Requested' status can be assigned.");

        var userName = dto.TechnicianUserName?.Trim();
        if (string.IsNullOrWhiteSpace(userName))
            return BadRequest("TechnicianUserName is required and cannot be empty.");

        var tech = await _userManager.FindByNameAsync(userName);
        if (tech is null)
            return BadRequest($"Technician user '{userName}' not found.");

        // Verify user has Technician role
        var userRoles = await _userManager.GetRolesAsync(tech);
        if (!userRoles.Contains(AppRoles.Technician))
            return BadRequest($"User '{userName}' is not a Technician. Current roles: {string.Join(", ", userRoles)}");

        sr.AssignedTechnicianUserId = tech.Id;
        sr.Status = ServiceRequestStatus.Assigned;
        sr.ScheduledAtUtc = DateTime.UtcNow;

        await _db.SaveChangesAsync();

        // ✅ Notification: Technician Assigned -> Technician
        await EnqueueAsync(new NotificationEvent(
            UserId: tech.Id,
            Title: "Task Assigned",
            Message: $"You have been assigned to Service Request #{sr.Id}.",
            Type: "StatusUpdate",
            RelatedServiceRequestId: sr.Id
        ));

        // ✅ Notification: Technician Assigned -> Customer
        var customerUserId = await GetCustomerUserIdByCustomerIdAsync(sr.CustomerId);
        if (!string.IsNullOrWhiteSpace(customerUserId))
        {
            await EnqueueAsync(new NotificationEvent(
                UserId: customerUserId!,
                Title: "Technician Assigned",
                Message: $"A technician has been assigned to your vehicle (Request #{sr.Id}).",
                Type: "StatusUpdate",
                RelatedServiceRequestId: sr.Id
            ));
        }

        return NoContent();
    }

    // -------------------- TECH UPDATE STATUS --------------------
    [HttpPut("{id:int}/technician-status")]
    [Authorize(Roles = AppRoles.Technician)]
    public async Task<IActionResult> TechnicianUpdateStatus(int id, [FromBody] UpdateServiceRequestStatusDto dto)
    {
        var techId = GetUserId();
        if (string.IsNullOrWhiteSpace(techId)) return Unauthorized();

        var sr = await _db.ServiceRequests.FirstOrDefaultAsync(x => x.Id == id);
        if (sr is null) return NotFound();

        if (sr.AssignedTechnicianUserId != techId)
            return Forbid();

        if (dto.Status == ServiceRequestStatus.InProgress)
        {
            if (sr.Status != ServiceRequestStatus.Assigned)
                return BadRequest("Can move to InProgress only from Assigned.");
            sr.Status = ServiceRequestStatus.InProgress;
        }
        else if (dto.Status == ServiceRequestStatus.Completed)
        {
            if (sr.Status != ServiceRequestStatus.InProgress)
                return BadRequest("Can move to Completed only from InProgress.");
            sr.Status = ServiceRequestStatus.Completed;
            sr.CompletedAtUtc = DateTime.UtcNow;
        }
        else
        {
            return BadRequest("Technician can set only InProgress or Completed.");
        }

        if (!string.IsNullOrWhiteSpace(dto.Remarks))
            sr.Remarks = dto.Remarks.Trim();

        await _db.SaveChangesAsync();

        // ✅ AUTO-GENERATE INVOICE when status becomes Completed
        if (dto.Status == ServiceRequestStatus.Completed)
        {
            // Check if invoice already exists (avoid duplicates)
            var existingInvoice = await _db.Invoices
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.ServiceRequestId == sr.Id);
            
            if (existingInvoice == null)
            {
                // Load ServiceCategory for BasePrice
                await _db.Entry(sr).Reference(x => x.ServiceCategory).LoadAsync();
                
                // Calculate Labor Charge from ServiceCategory.BasePrice
                decimal laborCharge = 0;
                string laborItemName = "Service Labor";
                
                if (sr.ServiceCategoryId.HasValue && sr.ServiceCategory != null)
                {
                    laborCharge = sr.ServiceCategory.BasePrice;
                    laborItemName = $"{sr.ServiceCategory.Name} Service";
                }

                // Get parts usage for this service request
                var usages = await _db.ServicePartUsages
                    .AsNoTracking()
                    .Where(x => x.ServiceRequestId == sr.Id)
                    .Join(_db.Parts.AsNoTracking(),
                        u => u.PartId,
                        p => p.Id,
                        (u, p) => new { p.PartNumber, p.Name, u.Quantity, u.UnitPriceAtUse })
                    .ToListAsync();

                var lines = new List<InvoiceLine>();

                // Add parts lines
                foreach (var u in usages)
                {
                    var lineTotal = u.UnitPriceAtUse * u.Quantity;
                    lines.Add(new InvoiceLine
                    {
                        ItemType = "Part",
                        ItemName = u.Name,
                        ItemCode = u.PartNumber,
                        Quantity = u.Quantity,
                        UnitPrice = u.UnitPriceAtUse,
                        LineTotal = lineTotal
                    });
                }

                // Add labor line if applicable
                if (laborCharge > 0)
                {
                    lines.Add(new InvoiceLine
                    {
                        ItemType = "Labor",
                        ItemName = laborItemName,
                        ItemCode = null,
                        Quantity = 1,
                        UnitPrice = laborCharge,
                        LineTotal = laborCharge
                    });
                }

                // Calculate totals
                var partsTotal = lines.Where(x => x.ItemType == "Part").Sum(x => x.LineTotal);
                var labor = laborCharge;
                var subTotal = partsTotal + labor;

                // Default tax rate: 10% (0.10)
                const decimal defaultTaxRate = 0.10m;
                var taxAmount = Math.Round(subTotal * defaultTaxRate, 2);
                var total = Math.Round(subTotal + taxAmount, 2);

                // Create and save invoice
                var invoice = new Invoice
                {
                    ServiceRequestId = sr.Id,
                    Status = Vsm.Domain.Entities.InvoiceStatus.Generated,
                    LaborCharge = labor,
                    PartsTotal = partsTotal,
                    TaxRate = defaultTaxRate,
                    TaxAmount = taxAmount,
                    TotalAmount = total,
                    IsPaid = false,
                    GeneratedAtUtc = DateTime.UtcNow,
                    Lines = lines
                };

                _db.Invoices.Add(invoice);
                await _db.SaveChangesAsync();

                // ✅ Notification: Invoice Generated -> Customer
                var customerUserId = await GetCustomerUserIdByCustomerIdAsync(sr.CustomerId);
                if (!string.IsNullOrWhiteSpace(customerUserId))
                {
                    await EnqueueAsync(new NotificationEvent(
                        UserId: customerUserId!,
                        Title: "Service Completed",
                        Message: $"Service Completed. Invoice #{invoice.Id} has been generated. Please view and pay to close the request.",
                        Type: "StatusUpdate",
                        RelatedServiceRequestId: sr.Id,
                        RelatedInvoiceId: invoice.Id
                    ));
                }

                // ✅ Notification: Invoice Generated -> Service Manager
                var serviceManagerUserIds = await GetServiceManagerUserIdsAsync();
                foreach (var managerUserId in serviceManagerUserIds)
                {
                    await EnqueueAsync(new NotificationEvent(
                        UserId: managerUserId,
                        Title: "Invoice Generated",
                        Message: $"Invoice #{invoice.Id} generated for Request #{sr.Id}.",
                        Type: "Billing",
                        RelatedServiceRequestId: sr.Id,
                        RelatedInvoiceId: invoice.Id
                    ));
                }
            }
            else
            {
                // Invoice already exists, just notify about completion
                var customerUserId = await GetCustomerUserIdByCustomerIdAsync(sr.CustomerId);
                if (!string.IsNullOrWhiteSpace(customerUserId))
                {
                    await EnqueueAsync(new NotificationEvent(
                        UserId: customerUserId!,
                        Title: "Service Status Updated",
                        Message: $"Update: Your service request #{sr.Id} is now {sr.Status}.",
                        Type: "StatusUpdate",
                        RelatedServiceRequestId: sr.Id
                    ));
                }

                // ✅ Notification: Status Update (by Technician) -> Service Manager
                var serviceManagerUserIds = await GetServiceManagerUserIdsAsync();
                foreach (var managerUserId in serviceManagerUserIds)
                {
                    await EnqueueAsync(new NotificationEvent(
                        UserId: managerUserId,
                        Title: "Status Updated",
                        Message: $"Technician updated Request #{sr.Id} to {sr.Status}.",
                        Type: "StatusUpdate",
                        RelatedServiceRequestId: sr.Id
                    ));
                }
            }
        }
        else
        {
            // ✅ Notification: Status Update -> Customer (for InProgress)
            var customerUserId = await GetCustomerUserIdByCustomerIdAsync(sr.CustomerId);
            if (!string.IsNullOrWhiteSpace(customerUserId))
            {
                await EnqueueAsync(new NotificationEvent(
                    UserId: customerUserId!,
                    Title: "Service Status Updated",
                    Message: $"Update: Your service request #{sr.Id} is now {sr.Status}.",
                    Type: "StatusUpdate",
                    RelatedServiceRequestId: sr.Id
                ));
            }

            // ✅ Notification: Status Update (by Technician) -> Service Manager
            var serviceManagerUserIds = await GetServiceManagerUserIdsAsync();
            foreach (var managerUserId in serviceManagerUserIds)
            {
                await EnqueueAsync(new NotificationEvent(
                    UserId: managerUserId,
                    Title: "Status Updated",
                    Message: $"Technician updated Request #{sr.Id} to {sr.Status}.",
                    Type: "StatusUpdate",
                    RelatedServiceRequestId: sr.Id
                ));
            }
        }

        return NoContent();
    }

    // -------------------- CLOSE (ADMIN/MANAGER) --------------------
    [HttpPut("{id:int}/close")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<IActionResult> Close(int id, [FromBody] UpdateServiceRequestStatusDto dto)
    {
        var sr = await _db.ServiceRequests.FirstOrDefaultAsync(x => x.Id == id);
        if (sr is null) return NotFound();

        if (sr.Status != ServiceRequestStatus.Completed)
            return BadRequest("Only Completed requests can be closed.");

        sr.Status = ServiceRequestStatus.Closed;
        sr.ClosedAtUtc = DateTime.UtcNow;

        if (!string.IsNullOrWhiteSpace(dto.Remarks))
            sr.Remarks = dto.Remarks.Trim();

        await _db.SaveChangesAsync();

        // ✅ Notification: Closed -> Customer
        var customerUserId = await GetCustomerUserIdByCustomerIdAsync(sr.CustomerId);
        if (!string.IsNullOrWhiteSpace(customerUserId))
        {
            await EnqueueAsync(new NotificationEvent(
                UserId: customerUserId!,
                Title: "Service closed",
                Message: $"Your service request #{sr.Id} has been closed.",
                Type: "StatusUpdate",
                RelatedServiceRequestId: sr.Id
            ));
        }

        return NoContent();
    }

    // -------------------- CANCEL (CUSTOMER) --------------------
    [HttpPut("{id:int}/cancel")]
    [Authorize(Roles = AppRoles.Customer)]
    public async Task<IActionResult> Cancel(int id, [FromBody] UpdateServiceRequestStatusDto dto)
    {
        var customer = await GetLoggedInCustomerAsync();
        if (customer is null) return StatusCode(403, "Customer profile not linked.");

        var sr = await _db.ServiceRequests.FirstOrDefaultAsync(x => x.Id == id);
        if (sr is null) return NotFound();

        if (sr.CustomerId != customer.Id) return StatusCode(403, "You can cancel only your own requests.");

        if (sr.Status is ServiceRequestStatus.Completed or ServiceRequestStatus.Closed)
            return BadRequest("Cannot cancel after completion/closure.");

        sr.Status = ServiceRequestStatus.Cancelled;
        sr.CancelledAtUtc = DateTime.UtcNow;

        if (!string.IsNullOrWhiteSpace(dto.Remarks))
            sr.Remarks = dto.Remarks.Trim();

        await _db.SaveChangesAsync();

        // ✅ Notification: Cancelled -> Customer
        var customerUserId = customer.ApplicationUserId ?? GetUserId();
        if (!string.IsNullOrWhiteSpace(customerUserId))
        {
            await EnqueueAsync(new NotificationEvent(
                UserId: customerUserId!,
                Title: "Service cancelled",
                Message: $"Your service request #{sr.Id} has been cancelled.",
                Type: "StatusUpdate",
                RelatedServiceRequestId: sr.Id
            ));
        }

        return NoContent();
    }

    // -------------------- PARTS: VIEW USED PARTS (role-safe) --------------------
    [HttpGet("{id:int}/parts")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager},{AppRoles.Technician},{AppRoles.Customer}")]
    public async Task<IActionResult> GetPartsUsed(int id)
    {
        var sr = await _db.ServiceRequests.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        if (sr is null) return NotFound("ServiceRequest not found.");

        if (User.IsInRole(AppRoles.Customer))
        {
            var customer = await GetLoggedInCustomerAsync();
            if (customer is null) return Forbid();
            if (sr.CustomerId != customer.Id) return Forbid();
        }

        if (User.IsInRole(AppRoles.Technician))
        {
            var techId = GetUserId();
            if (string.IsNullOrWhiteSpace(techId)) return Unauthorized();
            if (sr.AssignedTechnicianUserId != techId) return Forbid();
        }

        var items = await _db.ServicePartUsages
            .AsNoTracking()
            .Where(x => x.ServiceRequestId == id)
            .Include(x => x.Part)
            .OrderByDescending(x => x.UsedAtUtc)
            .Select(x => new
            {
                x.Id,
                x.PartId,
                partNumber = x.Part!.PartNumber,
                partName = x.Part!.Name,
                x.Quantity,
                x.UnitPriceAtUse,
                lineTotal = x.UnitPriceAtUse * x.Quantity,
                x.UsedAtUtc
            })
            .ToListAsync();

        return Ok(new
        {
            serviceRequestId = id,
            items,
            totalPartsCost = items.Sum(x => x.lineTotal)
        });
    }

    // -------------------- PARTS: USE PARTS (deduct stock + save usage) --------------------
    [HttpPost("{id:int}/parts/use")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager},{AppRoles.Technician}")]
    public async Task<IActionResult> UseParts(int id, [FromBody] UsePartsRequestDto dto)
    {
        if (dto?.Items == null || dto.Items.Count == 0)
            return BadRequest("Items are required.");

        var sr = await _db.ServiceRequests.FirstOrDefaultAsync(x => x.Id == id);
        if (sr is null) return NotFound("ServiceRequest not found.");

        // Technician can only use parts on their assigned SR
        if (User.IsInRole(AppRoles.Technician))
        {
            var techId = GetUserId();
            if (string.IsNullOrWhiteSpace(techId)) return Unauthorized();
            if (sr.AssignedTechnicianUserId != techId) return Forbid();
        }

        if (sr.Status is ServiceRequestStatus.Cancelled or ServiceRequestStatus.Closed)
            return BadRequest("Cannot use parts on Cancelled/Closed requests.");

        if (sr.Status != ServiceRequestStatus.Assigned && sr.Status != ServiceRequestStatus.InProgress)
            return BadRequest("Can use parts only when request is Assigned or InProgress.");

        // validate + merge duplicates
        var items = dto.Items
            .Where(x => x.PartId > 0 && x.Quantity > 0)
            .GroupBy(x => x.PartId)
            .Select(g => new { PartId = g.Key, Quantity = g.Sum(z => z.Quantity) })
            .ToList();

        if (items.Count == 0)
            return BadRequest("Each item must have PartId > 0 and Quantity > 0.");

        var partIds = items.Select(x => x.PartId).ToList();

        await using var tx = await _db.Database.BeginTransactionAsync();

        var parts = await _db.Parts.Where(p => partIds.Contains(p.Id)).ToListAsync();
        if (parts.Count != partIds.Count)
        {
            await tx.RollbackAsync();
            return BadRequest("One or more PartId values are invalid.");
        }

        // stock checks first
        foreach (var it in items)
        {
            var part = parts.First(p => p.Id == it.PartId);
            if (part.StockQty < it.Quantity)
            {
                await tx.RollbackAsync();
                return BadRequest(
                    $"Not enough stock for Part '{part.PartNumber}'. Available: {part.StockQty}, required: {it.Quantity}"
                );
            }
        }

        // deduct + add usage
        foreach (var it in items)
        {
            var part = parts.First(p => p.Id == it.PartId);

            part.StockQty -= it.Quantity;

            _db.ServicePartUsages.Add(new ServicePartUsage
            {
                ServiceRequestId = sr.Id,
                PartId = part.Id,
                Quantity = it.Quantity,
                UnitPriceAtUse = part.UnitPrice,
                UsedAtUtc = DateTime.UtcNow
            });
        }

        await _db.SaveChangesAsync();
        await tx.CommitAsync();

        // ✅ Check for low stock and notify Admin
        var adminUserIds = await GetAdminUserIdsAsync();
        foreach (var it in items)
        {
            var part = parts.First(p => p.Id == it.PartId);
            if (part.StockQty <= part.LowStockThreshold)
            {
                foreach (var adminUserId in adminUserIds)
                {
                    await EnqueueAsync(new NotificationEvent(
                        UserId: adminUserId,
                        Title: "Low Stock Alert",
                        Message: $"Alert: Part {part.Name} is low on stock ({part.StockQty} remaining).",
                        Type: "General"
                    ));
                }
            }
        }

        return Ok(new { message = "Parts used successfully and stock updated." });
    }

    // -------------------- DELETE (ADMIN) --------------------
    [HttpDelete("{id:int}")]
    [Authorize(Roles = AppRoles.Admin)]
    public async Task<IActionResult> Delete(int id)
    {
        var sr = await _db.ServiceRequests.FirstOrDefaultAsync(x => x.Id == id);
        if (sr is null) return NotFound();

        _db.ServiceRequests.Remove(sr);
        await _db.SaveChangesAsync();

        return NoContent();
    }
}
