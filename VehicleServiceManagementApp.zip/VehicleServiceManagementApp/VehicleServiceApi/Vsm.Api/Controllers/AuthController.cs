﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Vsm.Api.Dtos.Auth;
using Vsm.Domain.Entities;
using Vsm.Domain.Enums;
using Vsm.Infrastructure.Data;
using Vsm.Infrastructure.Identity;

namespace Vsm.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly RoleManager<IdentityRole> _roleManager;
    private readonly IConfiguration _config;
    private readonly AppDbContext _db;

    public AuthController(
        UserManager<ApplicationUser> userManager,
        RoleManager<IdentityRole> roleManager,
        IConfiguration config,
        AppDbContext db)
    {
        _userManager = userManager;
        _roleManager = roleManager;
        _config = config;
        _db = db;
    }

    [HttpPost("register")]
    [AllowAnonymous]
    public async Task<IActionResult> Register([FromBody] RegisterRequestDto dto)
    {
        var userName = (dto.UserName ?? "").Trim();
        if (string.IsNullOrWhiteSpace(userName)) return BadRequest("UserName is required.");

        // Validate required fields for new registrations
        var fullName = (dto.FullName ?? "").Trim();
        if (string.IsNullOrWhiteSpace(fullName)) return BadRequest("FullName is required.");

        var email = (dto.Email ?? "").Trim();
        if (string.IsNullOrWhiteSpace(email)) return BadRequest("Email is required.");

        var existing = await _userManager.FindByNameAsync(userName);
        if (existing != null) return BadRequest("User already exists.");

        // Create user with extended profile fields
        var user = new ApplicationUser 
        { 
            UserName = userName,
            FullName = fullName,
            Email = email,
            PhoneNumber = !string.IsNullOrWhiteSpace(dto.PhoneNumber) ? dto.PhoneNumber.Trim() : null
        };
        
        var createResult = await _userManager.CreateAsync(user, dto.Password);
        if (!createResult.Succeeded) return BadRequest(createResult.Errors);

       
        var role = AppRoles.Customer;

        if (!await _roleManager.RoleExistsAsync(role))
            await _roleManager.CreateAsync(new IdentityRole(role));

        await _userManager.AddToRoleAsync(user, role);

       
        await EnsureCustomerProfileLinkedAsync(user);

        return Ok(new { message = "Registered successfully as Customer." });
    }

    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<ActionResult<TokenResponseDto>> Login([FromBody] LoginRequestDto dto)
    {
        var userName = (dto.UserName ?? "").Trim();
        var user = await _userManager.FindByNameAsync(userName);
        if (user == null) return Unauthorized();

        var ok = await _userManager.CheckPasswordAsync(user, dto.Password);
        if (!ok) return Unauthorized();

        // Check if user is active
        if (!user.IsActive)
        {
            return StatusCode(403, new { message = "Your account is deactivated. Please contact the administrator." });
        }

        var roles = await _userManager.GetRolesAsync(user);
        var token = CreateToken(user, roles);

        return Ok(new TokenResponseDto { Token = token });
    }

    [HttpPost("users")]
    [Authorize(Roles = AppRoles.Admin)]
    public async Task<ActionResult<CreateUserResponseDto>> CreateUser([FromBody] CreateUserRequestDto dto)
    {
        var userName = (dto.UserName ?? "").Trim();
        if (string.IsNullOrWhiteSpace(userName)) return BadRequest("UserName is required.");

        var role = (dto.Role ?? "").Trim();
        if (string.IsNullOrWhiteSpace(role)) return BadRequest("Role is required.");

        // Validate required fields for new user creation
        var fullName = (dto.FullName ?? "").Trim();
        if (string.IsNullOrWhiteSpace(fullName)) return BadRequest("FullName is required.");

        var email = (dto.Email ?? "").Trim();
        if (string.IsNullOrWhiteSpace(email)) return BadRequest("Email is required.");

        // Prevent creating Admin role - only one admin exists
        if (role == AppRoles.Admin)
            return BadRequest("Cannot create users with Admin role. Only one admin exists in the system.");

        // Validate role
        if (!AppRoles.All.Contains(role))
            return BadRequest($"Invalid role. Allowed: {string.Join(", ", AppRoles.All.Where(r => r != AppRoles.Admin))}");

        // Check if user already exists
        var existing = await _userManager.FindByNameAsync(userName);
        if (existing != null) return BadRequest("User already exists.");

        // Ensure role exists
        if (!await _roleManager.RoleExistsAsync(role))
            await _roleManager.CreateAsync(new IdentityRole(role));

        // Generate secure random password
        var password = GenerateSecurePassword();

        // Create user with extended profile fields
        var user = new ApplicationUser 
        { 
            UserName = userName,
            FullName = fullName,
            Email = email,
            PhoneNumber = !string.IsNullOrWhiteSpace(dto.PhoneNumber) ? dto.PhoneNumber.Trim() : null
        };
        
        var createResult = await _userManager.CreateAsync(user, password);
        if (!createResult.Succeeded)
            return BadRequest($"Failed to create user: {string.Join(", ", createResult.Errors.Select(e => e.Description))}");

        // Assign role
        var addRoleResult = await _userManager.AddToRoleAsync(user, role);
        if (!addRoleResult.Succeeded)
        {
            // Rollback: deactivate user if role assignment fails (instead of deleting)
            user.IsActive = false;
            await _userManager.UpdateAsync(user);
            return BadRequest($"Failed to assign role: {string.Join(", ", addRoleResult.Errors.Select(e => e.Description))}");
        }

        // Link customer profile if role is Customer
        if (role == AppRoles.Customer)
        {
            await EnsureCustomerProfileLinkedAsync(user);
        }

        return Ok(new CreateUserResponseDto(
            UserId: user.Id,
            UserName: userName,
            Password: password,
            Role: role,
            Message: $"User '{userName}' created successfully with role '{role}'. Please save the password as it will not be shown again.",
            FullName: user.FullName,
            Email: user.Email,
            PhoneNumber: user.PhoneNumber
        ));
    }

    [HttpGet("users")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<ActionResult<PagedUsersResponseDto>> GetUsers(
        [FromQuery] string? search,
        [FromQuery] string? role,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20)
    {
        if (page < 1) page = 1;
        if (pageSize < 1) pageSize = 20;
        if (pageSize > 100) pageSize = 100;

        var q = _userManager.Users.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim();
            q = q.Where(u => u.UserName!.Contains(s));
        }

        var total = await q.CountAsync();

        var users = await q
            .OrderBy(u => u.UserName)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();

        var items = new List<UserListItemDto>(users.Count);
        foreach (var u in users)
        {
            var roles = (await _userManager.GetRolesAsync(u)).ToList();
            items.Add(new UserListItemDto(
                u.Id, 
                u.UserName ?? "", 
                roles, 
                u.IsActive,
                u.FullName,
                u.Email,
                u.PhoneNumber
            ));
        }

        if (!string.IsNullOrWhiteSpace(role))
        {
            var r = role.Trim();
            items = items.Where(x => x.Roles.Contains(r)).ToList();
        }

        return Ok(new PagedUsersResponseDto(page, pageSize, total, items));
    }

    [HttpPut("users/{userName}/role")]
    [Authorize(Roles = AppRoles.Admin)]
    public async Task<IActionResult> SetRole(string userName, [FromBody] SetUserRoleRequestDto dto)
    {
        var uname = (userName ?? "").Trim();
        if (string.IsNullOrWhiteSpace(uname)) return BadRequest("UserName is required.");

        var user = await _userManager.FindByNameAsync(uname);
        if (user is null) return NotFound("User not found.");

        var newRole = (dto.Role ?? "").Trim();
        if (string.IsNullOrWhiteSpace(newRole)) return BadRequest("Role is required.");

        if (!AppRoles.All.Contains(newRole))
            return BadRequest($"Invalid role. Allowed: {string.Join(", ", AppRoles.All)}");

        if (!await _roleManager.RoleExistsAsync(newRole))
            await _roleManager.CreateAsync(new IdentityRole(newRole));

        // Get current roles before removing them
        var currentRoles = await _userManager.GetRolesAsync(user);
        var isCurrentlyTechnician = currentRoles.Contains(AppRoles.Technician);
        var isChangingFromTechnician = isCurrentlyTechnician && newRole != AppRoles.Technician;

        // Cascade unassign: If user is being moved from Technician role, unassign all active service requests
        if (isChangingFromTechnician)
        {
            var activeServiceRequests = await _db.ServiceRequests
                .Where(sr => sr.AssignedTechnicianUserId == user.Id &&
                           (sr.Status == ServiceRequestStatus.Assigned || sr.Status == ServiceRequestStatus.InProgress))
                .ToListAsync();

            foreach (var request in activeServiceRequests)
            {
                request.AssignedTechnicianUserId = null;
                request.Status = ServiceRequestStatus.Requested;
            }

            if (activeServiceRequests.Count > 0)
            {
                await _db.SaveChangesAsync();
            }
        }

        // Enforce single role policy: Remove ALL existing roles first
        if (currentRoles.Count > 0)
        {
            var removeResult = await _userManager.RemoveFromRolesAsync(user, currentRoles);
            if (!removeResult.Succeeded)
                return BadRequest($"Failed to remove existing roles: {string.Join(", ", removeResult.Errors.Select(e => e.Description))}");
        }

        // Add the new role
        var addResult = await _userManager.AddToRoleAsync(user, newRole);
        if (!addResult.Succeeded)
            return BadRequest($"Failed to add role: {string.Join(", ", addResult.Errors.Select(e => e.Description))}");

        // Verify: User should have exactly one role (the new one)
        var finalRoles = await _userManager.GetRolesAsync(user);
        if (finalRoles.Count != 1 || !finalRoles.Contains(newRole))
            return StatusCode(500, $"Role assignment verification failed. User has {finalRoles.Count} role(s): {string.Join(", ", finalRoles)}");

     
        if (newRole == AppRoles.Customer)
        {
            await EnsureCustomerProfileLinkedAsync(user);
        }

        return Ok(new { message = $"Role updated to '{newRole}' for '{uname}'. User now has exactly one role." });
    }

    [HttpPut("users/{userName}")]
    [Authorize(Roles = AppRoles.Admin)]
    public async Task<ActionResult<UserListItemDto>> UpdateUser(string userName, [FromBody] UpdateUserDto dto)
    {
        var uname = (userName ?? "").Trim();
        if (string.IsNullOrWhiteSpace(uname)) return BadRequest("UserName is required.");

        var user = await _userManager.FindByNameAsync(uname);
        if (user is null) return NotFound("User not found.");

        // Update only provided fields (all fields are optional in DTO)
        bool hasChanges = false;

        if (dto.FullName != null)
        {
            var fullName = dto.FullName.Trim();
            if (!string.IsNullOrWhiteSpace(fullName) && user.FullName != fullName)
            {
                user.FullName = fullName;
                hasChanges = true;
            }
        }

        if (dto.Email != null)
        {
            var email = dto.Email.Trim();
            if (!string.IsNullOrWhiteSpace(email) && user.Email != email)
            {
                user.Email = email;
                hasChanges = true;
            }
        }

        if (dto.PhoneNumber != null)
        {
            var phoneNumber = dto.PhoneNumber.Trim();
            // Allow setting to null/empty to clear phone number
            if (user.PhoneNumber != phoneNumber)
            {
                user.PhoneNumber = string.IsNullOrWhiteSpace(phoneNumber) ? null : phoneNumber;
                hasChanges = true;
            }
        }

        if (hasChanges)
        {
            var updateResult = await _userManager.UpdateAsync(user);
            if (!updateResult.Succeeded)
                return BadRequest($"Failed to update user: {string.Join(", ", updateResult.Errors.Select(e => e.Description))}");
        }

        // Return updated user DTO
        var roles = (await _userManager.GetRolesAsync(user)).ToList();
        var userDto = new UserListItemDto(
            user.Id, 
            user.UserName ?? "", 
            roles, 
            user.IsActive,
            user.FullName,
            user.Email,
            user.PhoneNumber
        );

        return Ok(userDto);
    }

    [HttpPost("users/{id}/toggle-status")]
    [Authorize(Roles = AppRoles.Admin)]
    public async Task<ActionResult<UserListItemDto>> ToggleUserStatus(string id)
    {
        var userId = (id ?? "").Trim();
        if (string.IsNullOrWhiteSpace(userId)) return BadRequest("User ID is required.");

        var user = await _userManager.FindByIdAsync(userId);
        if (user is null) return NotFound("User not found.");

        // Prevent admin from deactivating themselves
        var currentUserId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (currentUserId == user.Id)
            return BadRequest("You cannot deactivate your own account.");

        // Get user roles to check if admin
        var userRoles = await _userManager.GetRolesAsync(user);
        var isAdmin = userRoles.Contains(AppRoles.Admin);

        // Prevent deactivating the last remaining admin
        if (isAdmin && user.IsActive) // If trying to deactivate an admin (currently active)
        {
            var adminCount = await _userManager.GetUsersInRoleAsync(AppRoles.Admin);
            var activeAdminCount = adminCount.Count(u => u.IsActive);
            if (activeAdminCount <= 1)
                return BadRequest("Cannot deactivate the last remaining admin user.");
        }

        // Toggle IsActive status
        user.IsActive = !user.IsActive;
        var updateResult = await _userManager.UpdateAsync(user);
        if (!updateResult.Succeeded)
            return BadRequest($"Failed to update user status: {string.Join(", ", updateResult.Errors.Select(e => e.Description))}");

        // If deactivating, handle cascading updates (similar to old delete logic but without deleting)
        if (!user.IsActive)
        {
            // 1. Unassign user from all service requests (if they were a technician)
            var serviceRequests = await _db.ServiceRequests
                .Where(sr => sr.AssignedTechnicianUserId == user.Id)
                .ToListAsync();

            foreach (var request in serviceRequests)
            {
                request.AssignedTechnicianUserId = null;
                // If request was assigned or in progress, reset to requested
                if (request.Status == ServiceRequestStatus.Assigned || request.Status == ServiceRequestStatus.InProgress)
                {
                    request.Status = ServiceRequestStatus.Requested;
                }
            }

            // Save cascading changes
            if (serviceRequests.Count > 0)
            {
                await _db.SaveChangesAsync();
            }
        }

        // Return updated user DTO
        var roles = (await _userManager.GetRolesAsync(user)).ToList();
        var userDto = new UserListItemDto(
            user.Id, 
            user.UserName ?? "", 
            roles, 
            user.IsActive,
            user.FullName,
            user.Email,
            user.PhoneNumber
        );

        return Ok(userDto);
    }

    private string GenerateSecurePassword()
    {
        // Generate a secure random password with:
        // - At least 12 characters
        // - Uppercase letters
        // - Lowercase letters
        // - Numbers
        // - Special characters
        const string uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const string lowercase = "abcdefghijklmnopqrstuvwxyz";
        const string numbers = "0123456789";
        const string special = "!@#$%^&*";
        const string allChars = uppercase + lowercase + numbers + special;

        var password = new StringBuilder();
        var random = RandomNumberGenerator.Create();

        // Ensure at least one character from each category
        password.Append(GetRandomChar(uppercase, random));
        password.Append(GetRandomChar(lowercase, random));
        password.Append(GetRandomChar(numbers, random));
        password.Append(GetRandomChar(special, random));

        // Fill the rest to make it 12 characters total
        for (int i = password.Length; i < 12; i++)
        {
            password.Append(GetRandomChar(allChars, random));
        }

        // Shuffle the password characters
        var passwordArray = password.ToString().ToCharArray();
        for (int i = passwordArray.Length - 1; i > 0; i--)
        {
            var j = GetRandomInt(0, i + 1, random);
            (passwordArray[i], passwordArray[j]) = (passwordArray[j], passwordArray[i]);
        }

        return new string(passwordArray);
    }

    private char GetRandomChar(string chars, RandomNumberGenerator random)
    {
        var bytes = new byte[4];
        random.GetBytes(bytes);
        var index = BitConverter.ToUInt32(bytes, 0) % (uint)chars.Length;
        return chars[(int)index];
    }

    private int GetRandomInt(int min, int max, RandomNumberGenerator random)
    {
        var bytes = new byte[4];
        random.GetBytes(bytes);
        var value = BitConverter.ToUInt32(bytes, 0);
        return (int)(value % (uint)(max - min)) + min;
    }

    private async Task EnsureCustomerProfileLinkedAsync(ApplicationUser user)
    {
      
        var exists = await _db.Customers.AnyAsync(c => c.ApplicationUserId == user.Id);
        if (exists) return;

       
        var uname = user.UserName ?? "customer";
        var customer = new Customer
        {
            ApplicationUserId = user.Id,
            FullName = uname,
            Phone = "NA",
            Email = $"{uname}@example.com"
        };

        _db.Customers.Add(customer);
        await _db.SaveChangesAsync();
    }

    private string CreateToken(ApplicationUser user, IList<string> roles)
    {
        var key = _config["Jwt:Key"]!;
        var issuer = _config["Jwt:Issuer"]!;
        var audience = _config["Jwt:Audience"]!;
        var expMinutes = int.TryParse(_config["Jwt:ExpireMinutes"], out var m) ? m : 120;

        var claims = new List<Claim>
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.Id),
            new Claim(ClaimTypes.NameIdentifier, user.Id),
            new Claim(JwtRegisteredClaimNames.UniqueName, user.UserName ?? ""),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
        };

        foreach (var r in roles)
            claims.Add(new Claim(ClaimTypes.Role, r));

        var signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
        var creds = new SigningCredentials(signingKey, SecurityAlgorithms.HmacSha256);

        var jwt = new JwtSecurityToken(
            issuer: issuer,
            audience: audience,
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(expMinutes),
            signingCredentials: creds
        );

        return new JwtSecurityTokenHandler().WriteToken(jwt);
    }
}
