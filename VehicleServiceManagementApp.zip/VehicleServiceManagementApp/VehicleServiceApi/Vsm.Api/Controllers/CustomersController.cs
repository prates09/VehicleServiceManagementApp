﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Vsm.Api.Dtos.Customers;
using Vsm.Domain.Entities;
using Vsm.Infrastructure.Data;
using Vsm.Infrastructure.Identity;

namespace Vsm.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class CustomersController : ControllerBase
{
    private readonly AppDbContext _db;

    public CustomersController(AppDbContext db)
    {
        _db = db;
    }

    private string? GetUserId()
        => User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub");

    private async Task<Customer?> GetLoggedInCustomerAsync()
    {
        var userId = GetUserId();
        if (string.IsNullOrWhiteSpace(userId)) return null;

        return await _db.Customers
            .AsNoTracking()
            .FirstOrDefaultAsync(c => c.ApplicationUserId == userId);
    }

    // -------------------- CUSTOMER: GET MY PROFILE --------------------
    [HttpGet("my-profile")]
    [Authorize(Roles = AppRoles.Customer)]
    public async Task<ActionResult<CustomerResponseDto>> GetMyProfile()
    {
        var customer = await GetLoggedInCustomerAsync();
        if (customer is null) return StatusCode(403, "Customer profile not linked with this login.");

        return Ok(new CustomerResponseDto(customer.Id, customer.FullName, customer.Phone, customer.Email));
    }

    // -------------------- CUSTOMER: UPDATE MY PROFILE --------------------
    [HttpPut("my-profile")]
    [Authorize(Roles = AppRoles.Customer)]
    public async Task<IActionResult> UpdateMyProfile([FromBody] UpdateCustomerRequestDto dto)
    {
        var customer = await _db.Customers
            .FirstOrDefaultAsync(c => c.ApplicationUserId == GetUserId());
        
        if (customer is null) return StatusCode(403, "Customer profile not linked with this login.");

        var fullName = (dto.FullName ?? "").Trim();
        var phone = (dto.Phone ?? "").Trim();
        var email = (dto.Email ?? "").Trim();

        if (string.IsNullOrWhiteSpace(fullName)) return BadRequest("FullName is required.");
        if (string.IsNullOrWhiteSpace(phone)) return BadRequest("Phone is required.");
        if (string.IsNullOrWhiteSpace(email)) return BadRequest("Email is required.");

        customer.FullName = fullName;
        customer.Phone = phone;
        customer.Email = email;

        await _db.SaveChangesAsync();
        return NoContent();
    }

    
    [HttpGet("with-users")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<IActionResult> GetCustomersWithUsers()
    {
        var list = await _db.Customers
            .AsNoTracking()
            .OrderBy(x => x.Id)
            .Select(c => new
            {
                c.Id,
                c.FullName,
                c.Email,
                c.Phone,
                c.ApplicationUserId
            })
            .ToListAsync();

        return Ok(list);
    }

    [HttpPost]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<ActionResult<CustomerResponseDto>> Create([FromBody] CreateCustomerRequestDto dto)
    {
        var fullName = (dto.FullName ?? "").Trim();
        var phone = (dto.Phone ?? "").Trim();
        var email = (dto.Email ?? "").Trim();

        if (string.IsNullOrWhiteSpace(fullName)) return BadRequest("FullName is required.");
        if (string.IsNullOrWhiteSpace(phone)) return BadRequest("Phone is required.");
        if (string.IsNullOrWhiteSpace(email)) return BadRequest("Email is required.");

        var customer = new Customer
        {
            FullName = fullName,
            Phone = phone,
            Email = email
        };

        _db.Customers.Add(customer);
        await _db.SaveChangesAsync();

        var res = new CustomerResponseDto(customer.Id, customer.FullName, customer.Phone, customer.Email);
        return CreatedAtAction(nameof(GetById), new { id = customer.Id }, res);
    }

    [HttpGet]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<ActionResult<List<CustomerResponseDto>>> GetAll()
    {
        var list = await _db.Customers
            .AsNoTracking()
            .OrderBy(x => x.Id)
            .Select(x => new CustomerResponseDto(x.Id, x.FullName, x.Phone, x.Email))
            .ToListAsync();

        return Ok(list);
    }

    [HttpGet("{id:int}")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<ActionResult<CustomerResponseDto>> GetById(int id)
    {
        var customer = await _db.Customers
            .AsNoTracking()
            .Where(x => x.Id == id)
            .Select(x => new CustomerResponseDto(x.Id, x.FullName, x.Phone, x.Email))
            .FirstOrDefaultAsync();

        if (customer is null) return NotFound();

        return Ok(customer);
    }

    [HttpPut("{id:int}")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateCustomerRequestDto dto)
    {
        var customer = await _db.Customers.FirstOrDefaultAsync(x => x.Id == id);
        if (customer is null) return NotFound();

        var fullName = (dto.FullName ?? "").Trim();
        var phone = (dto.Phone ?? "").Trim();
        var email = (dto.Email ?? "").Trim();

        if (string.IsNullOrWhiteSpace(fullName)) return BadRequest("FullName is required.");
        if (string.IsNullOrWhiteSpace(phone)) return BadRequest("Phone is required.");
        if (string.IsNullOrWhiteSpace(email)) return BadRequest("Email is required.");

        customer.FullName = fullName;
        customer.Phone = phone;
        customer.Email = email;

        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<IActionResult> Delete(int id)
    {
        var customer = await _db.Customers.FirstOrDefaultAsync(x => x.Id == id);
        if (customer is null) return NotFound();

        _db.Customers.Remove(customer);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
