﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Vsm.Api.Dtos.Parts;
using Vsm.Api.Notifications;
using Vsm.Domain.Entities;
using Vsm.Infrastructure.Data;
using Vsm.Infrastructure.Identity;

namespace Vsm.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize] // must be logged in
public class PartsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;

    public PartsController(AppDbContext db, UserManager<ApplicationUser> userManager)
    {
        _db = db;
        _userManager = userManager;
    }

    private Task EnqueueAsync(NotificationEvent evt)
        => NotificationQueue.Channel.Writer.WriteAsync(evt).AsTask();

    private async Task<List<string>> GetAdminUserIdsAsync()
    {
        var admins = await _userManager.GetUsersInRoleAsync(AppRoles.Admin);
        return admins.Select(u => u.Id).ToList();
    }

    private async Task NotifyLowStockIfNeededAsync(Part part)
    {
        if (part.StockQty <= part.LowStockThreshold)
        {
            var adminUserIds = await GetAdminUserIdsAsync();
            foreach (var adminUserId in adminUserIds)
            {
                await EnqueueAsync(new NotificationEvent(
                    UserId: adminUserId,
                    Title: "Low Stock Alert",
                    Message: $"Alert: Part {part.Name} is low on stock ({part.StockQty} remaining).",
                    Type: "General"
                ));
            }
        }
    }

    // View parts: Admin + ServiceManager + Technician
    [HttpGet]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager},{AppRoles.Technician}")]
    public async Task<ActionResult<List<PartResponseDto>>> GetAll(
        [FromQuery] string? search,
        [FromQuery] bool lowStockOnly = false,
        CancellationToken ct = default)
    {
        var q = _db.Parts.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim();
            q = q.Where(p =>
                EF.Functions.Like(p.Name, $"%{s}%") ||
                EF.Functions.Like(p.PartNumber, $"%{s}%"));
        }

        if (lowStockOnly)
            q = q.Where(p => p.StockQty <= p.LowStockThreshold);

        var list = await q
            .OrderBy(p => p.Name)
            .Select(p => new PartResponseDto(
                p.Id,
                p.PartNumber,
                p.Name,
                p.UnitPrice,
                p.StockQty,
                p.LowStockThreshold,
                p.StockQty <= p.LowStockThreshold
            ))
            .ToListAsync(ct);

        return Ok(list);
    }

    [HttpGet("{id:int}")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager},{AppRoles.Technician}")]
    public async Task<ActionResult<PartResponseDto>> GetById(int id, CancellationToken ct = default)
    {
        var p = await _db.Parts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id, ct);
        if (p is null) return NotFound();

        return Ok(new PartResponseDto(
            p.Id, p.PartNumber, p.Name, p.UnitPrice, p.StockQty, p.LowStockThreshold,
            p.StockQty <= p.LowStockThreshold
        ));
    }

    [HttpGet("low-stock")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager},{AppRoles.Technician}")]
    public async Task<ActionResult<List<PartResponseDto>>> LowStock(CancellationToken ct = default)
    {
        var list = await _db.Parts
            .AsNoTracking()
            .Where(p => p.StockQty <= p.LowStockThreshold)
            .OrderBy(p => p.StockQty)
            .Select(p => new PartResponseDto(
                p.Id,
                p.PartNumber,
                p.Name,
                p.UnitPrice,
                p.StockQty,
                p.LowStockThreshold,
                true
            ))
            .ToListAsync(ct);

        return Ok(list);
    }

    // Create part: Admin + ServiceManager
    [HttpPost]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<ActionResult<PartResponseDto>> Create([FromBody] CreatePartRequestDto dto, CancellationToken ct = default)
    {
        var partNo = (dto.PartNumber ?? "").Trim();
        var name = (dto.Name ?? "").Trim();

        if (string.IsNullOrWhiteSpace(partNo)) return BadRequest("PartNumber is required.");
        if (string.IsNullOrWhiteSpace(name)) return BadRequest("Name is required.");
        if (dto.UnitPrice <= 0) return BadRequest("UnitPrice must be > 0.");
        if (dto.StockQty < 0) return BadRequest("StockQty cannot be negative.");
        if (dto.LowStockThreshold < 0) return BadRequest("LowStockThreshold cannot be negative.");

        // quick check (still keep try/catch for race conditions)
        if (await _db.Parts.AnyAsync(p => p.PartNumber == partNo, ct))
            return BadRequest("PartNumber must be unique.");

        var p = new Part
        {
            PartNumber = partNo,
            Name = name,
            UnitPrice = dto.UnitPrice,
            StockQty = dto.StockQty,
            LowStockThreshold = dto.LowStockThreshold
        };

        _db.Parts.Add(p);

        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch (DbUpdateException)
        {
            return BadRequest("PartNumber must be unique.");
        }

        // ✅ Check for low stock and notify Admin
        await NotifyLowStockIfNeededAsync(p);

        return CreatedAtAction(nameof(GetById), new { id = p.Id },
            new PartResponseDto(
                p.Id, p.PartNumber, p.Name, p.UnitPrice, p.StockQty, p.LowStockThreshold,
                p.StockQty <= p.LowStockThreshold
            ));
    }

    // Update full part: Admin + ServiceManager
    [HttpPut("{id:int}")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdatePartRequestDto dto, CancellationToken ct = default)
    {
        var p = await _db.Parts.FirstOrDefaultAsync(x => x.Id == id, ct);
        if (p is null) return NotFound();

        var partNo = (dto.PartNumber ?? "").Trim();
        var name = (dto.Name ?? "").Trim();

        if (string.IsNullOrWhiteSpace(partNo)) return BadRequest("PartNumber is required.");
        if (string.IsNullOrWhiteSpace(name)) return BadRequest("Name is required.");
        if (dto.UnitPrice <= 0) return BadRequest("UnitPrice must be > 0.");
        if (dto.StockQty < 0) return BadRequest("StockQty cannot be negative.");
        if (dto.LowStockThreshold < 0) return BadRequest("LowStockThreshold cannot be negative.");

        var duplicate = await _db.Parts.AnyAsync(x => x.PartNumber == partNo && x.Id != id, ct);
        if (duplicate) return BadRequest("PartNumber must be unique.");

        p.PartNumber = partNo;
        p.Name = name;
        p.UnitPrice = dto.UnitPrice;
        p.StockQty = dto.StockQty;
        p.LowStockThreshold = dto.LowStockThreshold;

        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch (DbUpdateException)
        {
            return BadRequest("PartNumber must be unique.");
        }

        // ✅ Check for low stock and notify Admin
        await NotifyLowStockIfNeededAsync(p);

        return NoContent();
    }

    // Adjust stock (add/remove): Admin + ServiceManager
    [HttpPut("{id:int}/stock")]
    [Authorize(Roles = $"{AppRoles.Admin},{AppRoles.ServiceManager}")]
    public async Task<ActionResult<PartResponseDto>> AdjustStock(int id, [FromBody] AdjustStockRequestDto dto, CancellationToken ct = default)
    {
        var p = await _db.Parts.FirstOrDefaultAsync(x => x.Id == id, ct);
        if (p is null) return NotFound();

        if (dto.Delta == 0) return BadRequest("Delta cannot be 0.");

        var newQty = p.StockQty + dto.Delta;
        if (newQty < 0) return BadRequest("StockQty cannot go below 0.");

        p.StockQty = newQty;
        await _db.SaveChangesAsync(ct);

        // ✅ Check for low stock and notify Admin
        await NotifyLowStockIfNeededAsync(p);

        return Ok(new PartResponseDto(
            p.Id, p.PartNumber, p.Name, p.UnitPrice, p.StockQty, p.LowStockThreshold,
            p.StockQty <= p.LowStockThreshold
        ));
    }

    // Delete: Admin only
    [HttpDelete("{id:int}")]
    [Authorize(Roles = AppRoles.Admin)]
    public async Task<IActionResult> Delete(int id, CancellationToken ct = default)
    {
        var p = await _db.Parts.FirstOrDefaultAsync(x => x.Id == id, ct);
        if (p is null) return NotFound();

        _db.Parts.Remove(p);
        await _db.SaveChangesAsync(ct);

        return NoContent();
    }
}
