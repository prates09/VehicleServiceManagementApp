﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Vsm.Api.Dtos.ServiceCategories;
using Vsm.Domain.Entities;
using Vsm.Infrastructure.Data;
using Vsm.Infrastructure.Identity;

namespace Vsm.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize] // ✅ any logged-in role can view categories (needed for booking)
public class ServiceCategoriesController : ControllerBase
{
    private readonly AppDbContext _db;

    public ServiceCategoriesController(AppDbContext db)
    {
        _db = db;
    }

    // ✅ View categories (Customer/Technician/Manager/Admin)
    [HttpGet]
    public async Task<ActionResult<List<ServiceCategoryResponseDto>>> GetAll(
        [FromQuery] bool activeOnly = false,
        CancellationToken ct = default)
    {
        var q = _db.ServiceCategories.AsNoTracking();

        if (activeOnly)
            q = q.Where(c => c.IsActive);

        var list = await q
            .OrderBy(c => c.Name)
            .Select(c => new ServiceCategoryResponseDto(
                c.Id,
                c.Name,
                c.Description,
                c.BasePrice,
                c.IsActive
            ))
            .ToListAsync(ct);

        return Ok(list);
    }

    // ✅ View single category (any logged-in role)
    [HttpGet("{id:int}")]
    public async Task<ActionResult<ServiceCategoryResponseDto>> GetById(int id, CancellationToken ct = default)
    {
        var category = await _db.ServiceCategories.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id, ct);
        if (category is null) return NotFound();

        return Ok(new ServiceCategoryResponseDto(
            category.Id,
            category.Name,
            category.Description,
            category.BasePrice,
            category.IsActive
        ));
    }

    // ✅ Admin-only manage categories (strict RBAC)
    [HttpPost]
    [Authorize(Roles = AppRoles.Admin)]
    public async Task<ActionResult<ServiceCategoryResponseDto>> Create([FromBody] CreateServiceCategoryRequestDto dto, CancellationToken ct = default)
    {
        var name = (dto.Name ?? "").Trim();
        var description = (dto.Description ?? "").Trim();

        if (string.IsNullOrWhiteSpace(name)) return BadRequest("Name is required.");
        if (dto.BasePrice < 0) return BadRequest("BasePrice cannot be negative.");

        if (await _db.ServiceCategories.AnyAsync(c => c.Name == name, ct))
            return BadRequest("Category name must be unique.");

        var category = new ServiceCategory
        {
            Name = name,
            Description = description,
            BasePrice = dto.BasePrice,
            IsActive = true
        };

        _db.ServiceCategories.Add(category);

        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch (DbUpdateException)
        {
            return BadRequest("Category name must be unique.");
        }

        return CreatedAtAction(nameof(GetById), new { id = category.Id },
            new ServiceCategoryResponseDto(
                category.Id,
                category.Name,
                category.Description,
                category.BasePrice,
                category.IsActive
            ));
    }

    [HttpPut("{id:int}")]
    [Authorize(Roles = AppRoles.Admin)]
    public async Task<ActionResult<ServiceCategoryResponseDto>> Update(int id, [FromBody] UpdateServiceCategoryRequestDto dto, CancellationToken ct = default)
    {
        var category = await _db.ServiceCategories.FirstOrDefaultAsync(x => x.Id == id, ct);
        if (category is null) return NotFound();

        var name = (dto.Name ?? "").Trim();
        var description = (dto.Description ?? "").Trim();

        if (string.IsNullOrWhiteSpace(name)) return BadRequest("Name is required.");
        if (dto.BasePrice < 0) return BadRequest("BasePrice cannot be negative.");

        var duplicate = await _db.ServiceCategories.AnyAsync(c => c.Name == name && c.Id != id, ct);
        if (duplicate) return BadRequest("Category name must be unique.");

        category.Name = name;
        category.Description = description;
        category.BasePrice = dto.BasePrice;
        category.IsActive = dto.IsActive;

        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch (DbUpdateException)
        {
            return BadRequest("Category name must be unique.");
        }

        return Ok(new ServiceCategoryResponseDto(
            category.Id,
            category.Name,
            category.Description,
            category.BasePrice,
            category.IsActive
        ));
    }

    [HttpDelete("{id:int}")]
    [Authorize(Roles = AppRoles.Admin)]
    public async Task<IActionResult> Delete(int id, CancellationToken ct = default)
    {
        var category = await _db.ServiceCategories.FirstOrDefaultAsync(x => x.Id == id, ct);
        if (category is null) return NotFound();

        var isUsed = await _db.ServiceRequests.AnyAsync(sr => sr.ServiceCategoryId == id, ct);
        if (isUsed)
        {
            category.IsActive = false;
            await _db.SaveChangesAsync(ct);
            return Ok(new { message = "Category deactivated (in use by service requests)." });
        }

        _db.ServiceCategories.Remove(category);
        await _db.SaveChangesAsync(ct);

        return NoContent();
    }
}
