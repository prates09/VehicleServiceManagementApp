﻿namespace Vsm.Api.Dtos.ServiceRequests;

public class UsePartsRequestDto
{
    public List<UsePartItemDto> Items { get; set; } = new();
}

public class UsePartItemDto
{
    public int PartId { get; set; }
    public int Quantity { get; set; }
}
 