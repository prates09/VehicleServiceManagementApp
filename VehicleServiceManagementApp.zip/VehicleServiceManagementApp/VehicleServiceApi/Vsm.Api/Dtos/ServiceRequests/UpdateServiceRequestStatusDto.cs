﻿using Vsm.Domain.Enums;

namespace Vsm.Api.Dtos.ServiceRequests;

public record UpdateServiceRequestStatusDto(
    ServiceRequestStatus Status,
    string? Remarks
);
