﻿using Vsm.Domain.Enums;

namespace Vsm.Api.Dtos.ServiceRequests;

public record UpdateServiceRequestRequestDto(
    int VehicleId,
    string IssueDescription,
    ServicePriority Priority,
    int? ServiceCategoryId = null
);
