﻿using Vsm.Domain.Enums;

namespace Vsm.Api.Dtos.ServiceRequests;

public record ServiceRequestResponseDto(
    int Id,
    int CustomerId,
    int VehicleId,
    string IssueDescription,
    ServicePriority Priority,
    ServiceRequestStatus Status,
    string? Remarks,
    DateTime CreatedAt,
    int? ServiceCategoryId = null,
    string? ServiceCategoryName = null,
    string? TechnicianId = null,
    string? TechnicianUserName = null
);
