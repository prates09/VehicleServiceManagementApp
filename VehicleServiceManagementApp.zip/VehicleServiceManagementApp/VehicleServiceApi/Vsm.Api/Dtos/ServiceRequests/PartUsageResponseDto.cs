﻿namespace Vsm.Api.Dtos.ServiceRequests;

public record PartUsageResponseDto(
    int Id,
    int ServiceRequestId,
    int PartId,
    string PartNumber,
    string PartName,
    int Quantity,
    decimal UnitPriceAtUse,
    decimal LineTotal,
    DateTime UsedAtUtc
);
