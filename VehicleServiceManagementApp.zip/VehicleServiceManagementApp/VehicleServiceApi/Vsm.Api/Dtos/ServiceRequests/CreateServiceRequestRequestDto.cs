﻿using Vsm.Domain.Enums;

namespace Vsm.Api.Dtos.ServiceRequests;

public record CreateServiceRequestRequestDto(
    int VehicleId,
    string IssueDescription,
    ServicePriority Priority,
    int? ServiceCategoryId = null
);
