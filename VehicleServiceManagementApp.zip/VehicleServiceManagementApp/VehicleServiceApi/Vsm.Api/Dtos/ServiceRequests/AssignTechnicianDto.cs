﻿namespace Vsm.Api.Dtos.ServiceRequests;

public record AssignTechnicianDto(string TechnicianUserName);
