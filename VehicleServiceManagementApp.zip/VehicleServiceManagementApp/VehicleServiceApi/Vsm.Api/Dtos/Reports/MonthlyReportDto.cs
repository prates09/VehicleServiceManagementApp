namespace Vsm.Api.Dtos.Reports;

public record MonthlyReportDto(
    int Year,
    int Month,
    int Total,
    int Requested,
    int Assigned,
    int InProgress,
    int Completed,
    int Closed,
    int Cancelled
);

