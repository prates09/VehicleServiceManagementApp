using Vsm.Domain.Enums;

namespace Vsm.Api.Dtos.Reports;

public record ServiceCategoryReportDto(
    int? CategoryId,
    string CategoryName,
    int TotalRequests,
    int Requested,
    int Assigned,
    int InProgress,
    int Completed,
    int Closed,
    int Cancelled
);

