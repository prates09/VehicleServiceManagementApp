﻿namespace Vsm.Api.Dtos.Reports;

public record TechnicianWorkloadDto(
    string TechnicianUserId,
    string TechnicianUserName,
    int TotalAssigned,
    int InProgress,
    int Completed,
    int Closed
);
