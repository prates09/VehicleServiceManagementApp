using Vsm.Domain.Enums;

namespace Vsm.Api.Dtos.Reports;

public record VehicleHistoryDto(
    int Id,
    int VehicleId,
    int CustomerId,
    string IssueDescription,
    ServicePriority Priority,
    ServiceRequestStatus Status,
    string? Remarks,
    DateTime RequestedAtUtc,
    DateTime? ScheduledAtUtc,
    DateTime? CompletedAtUtc,
    DateTime? ClosedAtUtc,
    DateTime? CancelledAtUtc
);

