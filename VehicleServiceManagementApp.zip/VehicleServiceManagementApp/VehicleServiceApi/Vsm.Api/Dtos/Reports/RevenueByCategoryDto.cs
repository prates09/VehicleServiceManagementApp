namespace Vsm.Api.Dtos.Reports;

public record RevenueByCategoryDto(
    int? CategoryId,
    string CategoryName,
    decimal TotalRevenue,
    int TotalInvoices,
    decimal PartsRevenue,
    decimal LaborRevenue,
    decimal TaxCollected,
    decimal AverageInvoiceAmount
);

