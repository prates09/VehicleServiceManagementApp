using Vsm.Domain.Enums;

namespace Vsm.Api.Dtos.Reports;

public record ServiceRequestByCategoryDto(
    int Id,
    int CustomerId,
    int VehicleId,
    string IssueDescription,
    ServicePriority Priority,
    ServiceRequestStatus Status,
    string? Remarks,
    int? ServiceCategoryId,
    string? ServiceCategoryName,
    DateTime RequestedAtUtc,
    DateTime? ScheduledAtUtc,
    DateTime? CompletedAtUtc,
    DateTime? ClosedAtUtc
);

