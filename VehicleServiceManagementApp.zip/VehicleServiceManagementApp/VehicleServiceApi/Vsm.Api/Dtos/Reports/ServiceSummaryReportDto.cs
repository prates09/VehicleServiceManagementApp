﻿namespace Vsm.Api.Dtos.Reports;

public record ServiceSummaryReportDto(
    int Total,
    int Requested,
    int Assigned,
    int InProgress,
    int Completed,
    int Closed,
    int Cancelled,
    int Pending,
    decimal TotalRevenue,
    decimal MonthlyRevenue
);
