namespace Vsm.Api.Dtos.Reports;

public record MonthlyRevenueDto(
    int Year,
    int Month,
    decimal TotalRevenue,
    int TotalInvoices,
    decimal PartsRevenue,
    decimal LaborRevenue,
    decimal TaxCollected
);

