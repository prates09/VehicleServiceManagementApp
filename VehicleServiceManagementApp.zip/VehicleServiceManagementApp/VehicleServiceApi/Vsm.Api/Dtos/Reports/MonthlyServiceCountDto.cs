﻿namespace Vsm.Api.Dtos.Reports;

public record MonthlyServiceCountDto(
    int Year,
    int Month,
    int TotalRequests,
    int CompletedRequests,
    int ClosedRequests
);
