﻿namespace Vsm.Api.Dtos.Vehicles;

public record VehicleResponseDto(
    int Id,
    int CustomerId,
    string RegistrationNumber,
    string Make,
    string Model,
    int Year,
    string? VehicleType = null
);
