﻿namespace Vsm.Api.Dtos.Vehicles;

public record CreateMyVehicleRequestDto(
    string RegistrationNumber,
    string Make,
    string Model,
    int Year,
    string? VehicleType = null
);
