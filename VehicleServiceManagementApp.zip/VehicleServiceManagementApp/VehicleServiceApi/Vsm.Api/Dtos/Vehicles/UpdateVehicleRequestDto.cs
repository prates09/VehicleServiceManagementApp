﻿namespace Vsm.Api.Dtos.Vehicles;

public record UpdateVehicleRequestDto(
    string RegistrationNumber,
    string Make,
    string Model,
    int Year,
    string? VehicleType = null
);
