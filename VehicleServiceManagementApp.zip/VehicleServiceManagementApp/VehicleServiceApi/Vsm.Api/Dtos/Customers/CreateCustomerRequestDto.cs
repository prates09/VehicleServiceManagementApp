﻿namespace Vsm.Api.Dtos.Customers;

public record CreateCustomerRequestDto(string FullName, string Phone, string Email);
