﻿namespace Vsm.Api.Dtos.Customers;

public record UpdateCustomerRequestDto(string FullName, string Phone, string Email);
