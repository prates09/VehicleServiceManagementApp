﻿namespace Vsm.Api.Dtos.Customers;

public record CustomerResponseDto(int Id, string FullName, string Phone, string Email);
