﻿namespace Vsm.Api.Dtos.Billing;

public class PayInvoiceRequestDto
{
    public string PaymentReference { get; set; } = string.Empty;
}
