﻿namespace Vsm.Api.Dtos.Billing;

public record InvoiceLineDto(
    int Id,
    string ItemType,
    string ItemName,
    string? ItemCode,
    int Quantity,
    decimal UnitPrice,
    decimal LineTotal
);
