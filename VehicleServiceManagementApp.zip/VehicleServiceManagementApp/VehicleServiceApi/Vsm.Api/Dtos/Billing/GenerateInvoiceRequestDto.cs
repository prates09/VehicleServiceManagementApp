﻿namespace Vsm.Api.Dtos.Billing;

public class GenerateInvoiceRequestDto
{
    public decimal? LaborCharge { get; set; } // Optional: if null, uses ServiceCategory.BasePrice
    public decimal TaxRate { get; set; } = 0.18m; // default 18%
}
