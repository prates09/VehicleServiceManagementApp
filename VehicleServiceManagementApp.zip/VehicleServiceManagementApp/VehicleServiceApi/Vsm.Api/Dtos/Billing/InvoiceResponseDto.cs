﻿using Vsm.Domain.Entities;

namespace Vsm.Api.Dtos.Billing;

public record InvoiceResponseDto(
    int Id,
    int ServiceRequestId,
    InvoiceStatus Status,
    decimal LaborCharge,
    decimal PartsTotal,
    decimal TaxRate,
    decimal TaxAmount,
    decimal TotalAmount,
    bool IsPaid,
    DateTime GeneratedAtUtc,
    DateTime? PaidAtUtc,
    string? PaymentReference,
    List<InvoiceLineDto> Lines
);
