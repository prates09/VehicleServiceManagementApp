namespace Vsm.Api.Dtos.Auth;

// Response DTO for user creation with extended profile fields
public record CreateUserResponseDto(
    string UserId, 
    string UserName, 
    string Password, 
    string Role, 
    string Message,
    string? FullName = null,
    string? Email = null,
    string? PhoneNumber = null
);

