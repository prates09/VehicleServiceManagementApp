﻿namespace Vsm.Api.Dtos.Auth;

public record PagedUsersResponseDto(
    int Page,
    int PageSize,
    int Total,
    List<UserListItemDto> Items
);
