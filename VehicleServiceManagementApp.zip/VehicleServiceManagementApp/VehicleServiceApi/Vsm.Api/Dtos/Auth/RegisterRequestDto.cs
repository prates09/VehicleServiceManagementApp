﻿namespace Vsm.Api.Dtos.Auth;

// Registration DTO with extended profile fields
// FullName and Email are required for new registrations
// PhoneNumber is optional
public record RegisterRequestDto(
    string UserName, 
    string Password,
    string FullName,
    string Email,
    string? PhoneNumber = null
);
