﻿namespace Vsm.Api.Dtos.Auth;

// User list item DTO with extended profile fields
public record UserListItemDto(
    string Id,
    string UserName,
    List<string> Roles,
    bool IsActive,
    string? FullName = null,
    string? Email = null,
    string? PhoneNumber = null
);
