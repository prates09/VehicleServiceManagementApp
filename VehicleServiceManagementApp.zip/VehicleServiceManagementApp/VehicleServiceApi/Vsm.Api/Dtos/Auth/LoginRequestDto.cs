﻿namespace Vsm.Api.Dtos.Auth;

public record LoginRequestDto(string UserName, string Password);
