﻿namespace Vsm.Api.Dtos.Auth;

public class TokenResponseDto
{
    public string Token { get; set; } = "";
}
