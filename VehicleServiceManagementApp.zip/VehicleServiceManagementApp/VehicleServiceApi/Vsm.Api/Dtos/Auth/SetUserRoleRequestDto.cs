﻿namespace Vsm.Api.Dtos.Auth;

public record SetUserRoleRequestDto(string Role);
