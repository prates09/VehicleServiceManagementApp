namespace Vsm.Api.Dtos.Auth;

// Admin user creation DTO with extended profile fields
public record CreateUserRequestDto(
    string UserName, 
    string Role,
    string FullName,
    string Email,
    string? PhoneNumber = null
);

