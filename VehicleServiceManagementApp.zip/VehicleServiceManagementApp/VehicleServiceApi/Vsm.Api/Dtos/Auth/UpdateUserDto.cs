namespace Vsm.Api.Dtos.Auth;

// DTO for admin to update user profile fields
// All fields are optional - only provided fields will be updated
public record UpdateUserDto(
    string? FullName = null,
    string? Email = null,
    string? PhoneNumber = null
);

