﻿namespace Vsm.Api.Dtos.Notifications;

public record NotificationResponseDto(
    int Id,
    string Title,
    string Message,
    string Type,
    int? RelatedServiceRequestId,
    int? RelatedInvoiceId,
    DateTime CreatedAtUtc,
    bool IsRead,
    DateTime? ReadAtUtc
);
