namespace Vsm.Api.Dtos.ServiceCategories;

public record CreateServiceCategoryRequestDto(
    string Name,
    string Description,
    decimal BasePrice
);

