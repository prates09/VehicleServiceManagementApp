namespace Vsm.Api.Dtos.ServiceCategories;

public record UpdateServiceCategoryRequestDto(
    string Name,
    string Description,
    decimal BasePrice,
    bool IsActive
);

