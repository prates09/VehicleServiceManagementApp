namespace Vsm.Api.Dtos.ServiceCategories;

public record ServiceCategoryResponseDto(
    int Id,
    string Name,
    string Description,
    decimal BasePrice,
    bool IsActive
);

