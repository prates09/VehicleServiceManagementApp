﻿namespace Vsm.Api.Dtos.Parts;

public record CreatePartRequestDto(
    string PartNumber,
    string Name,
    decimal UnitPrice,
    int StockQty,
    int LowStockThreshold = 5
);
