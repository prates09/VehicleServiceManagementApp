﻿namespace Vsm.Api.Dtos.Parts;

public record PartResponseDto(
    int Id,
    string PartNumber,
    string Name,
    decimal UnitPrice,
    int StockQty,
    int LowStockThreshold,
    bool IsLowStock
);
