﻿namespace Vsm.Api.Dtos.Parts;

public record UpdatePartRequestDto(
    string PartNumber,
    string Name,
    decimal UnitPrice,
    int StockQty,
    int LowStockThreshold
);
