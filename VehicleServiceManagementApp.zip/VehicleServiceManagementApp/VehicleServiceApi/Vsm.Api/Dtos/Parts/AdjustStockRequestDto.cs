﻿namespace Vsm.Api.Dtos.Parts;

public record AdjustStockRequestDto(
    int Delta
);
