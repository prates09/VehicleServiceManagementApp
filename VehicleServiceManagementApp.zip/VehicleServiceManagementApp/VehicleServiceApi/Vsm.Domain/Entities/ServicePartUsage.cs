﻿namespace Vsm.Domain.Entities;

public class ServicePartUsage
{
    public int Id { get; set; }

    public int ServiceRequestId { get; set; }
    public ServiceRequest? ServiceRequest { get; set; }

    public int PartId { get; set; }
    public Part? Part { get; set; }

    public int Quantity { get; set; }

    public decimal UnitPriceAtUse { get; set; }
    public DateTime UsedAtUtc { get; set; } = DateTime.UtcNow;
}
