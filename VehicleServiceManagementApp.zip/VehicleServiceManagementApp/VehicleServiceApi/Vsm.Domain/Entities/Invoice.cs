﻿namespace Vsm.Domain.Entities;
public enum InvoiceStatus
{
    Generated = 0,
    Sent = 1,
    Paid = 2,
    Cancelled = 3
}

public class Invoice
{
    public int Id { get; set; }

    public int ServiceRequestId { get; set; }
    public ServiceRequest? ServiceRequest { get; set; }
    public InvoiceStatus Status { get; set; } = InvoiceStatus.Generated;


    public decimal LaborCharge { get; set; }
    public decimal PartsTotal { get; set; }
    public decimal TaxRate { get; set; }     // e.g. 0.18 for 18%
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }

    public bool IsPaid { get; set; }
    public DateTime GeneratedAtUtc { get; set; } = DateTime.UtcNow;

    public DateTime? PaidAtUtc { get; set; }
    public string? PaymentReference { get; set; }

    public List<InvoiceLine> Lines { get; set; } = new();
}
