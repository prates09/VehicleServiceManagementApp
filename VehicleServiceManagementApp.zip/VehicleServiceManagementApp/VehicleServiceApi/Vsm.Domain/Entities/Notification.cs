﻿using System.ComponentModel.DataAnnotations;

namespace Vsm.Domain.Entities;

public class Notification
{
    [Key]
    public int Id { get; set; }

    // Identity user id (AspNetUsers PK) - string (usually 450 max in SQL Server)
    [Required]
    [MaxLength(450)]
    public string UserId { get; set; } = "";

    [Required]
    [MaxLength(200)]
    public string Title { get; set; } = "";

    [Required]
    [MaxLength(2000)]
    public string Message { get; set; } = "";

    // Examples: "Booking", "StatusUpdate", "Billing"
    [Required]
    [MaxLength(50)]
    public string Type { get; set; } = "General";

    // Optional reference to SR/Invoice etc.
    public int? RelatedServiceRequestId { get; set; }
    public int? RelatedInvoiceId { get; set; }

    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;

    public bool IsRead { get; set; } = false;
    public DateTime? ReadAtUtc { get; set; }
}
