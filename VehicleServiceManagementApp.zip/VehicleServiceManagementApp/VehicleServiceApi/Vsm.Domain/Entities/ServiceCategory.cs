namespace Vsm.Domain.Entities;

public class ServiceCategory
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public decimal BasePrice { get; set; } // Base pricing for this category
    public bool IsActive { get; set; } = true;
    
    // Navigation property for service requests
    public List<ServiceRequest> ServiceRequests { get; set; } = new();
}

