﻿namespace Vsm.Domain.Entities;

public class InvoiceLine
{
    public int Id { get; set; }

    public int InvoiceId { get; set; }
    public Invoice? Invoice { get; set; }

    public string ItemType { get; set; } = "Part";  // "Part" / "Labor"
    public string ItemName { get; set; } = string.Empty;
    public string? ItemCode { get; set; }

    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal LineTotal { get; set; }
}
