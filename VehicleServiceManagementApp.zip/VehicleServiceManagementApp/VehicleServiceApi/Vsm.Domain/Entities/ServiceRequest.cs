﻿using Vsm.Domain.Enums;

namespace Vsm.Domain.Entities;

public class ServiceRequest
{
    public int Id { get; set; }

   
    public int CustomerId { get; set; }
    public Customer? Customer { get; set; }

    public int VehicleId { get; set; }
    public Vehicle? Vehicle { get; set; }

    public int? ServiceCategoryId { get; set; }
    public ServiceCategory? ServiceCategory { get; set; }

    
    public string IssueDescription { get; set; } = string.Empty;

    public ServicePriority Priority { get; set; } = ServicePriority.Normal;
    public ServiceRequestStatus Status { get; set; } = ServiceRequestStatus.Requested;

 
    public string? Remarks { get; set; }

    
    public string? AssignedTechnicianUserId { get; set; }

    
    public DateTime RequestedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime? ScheduledAtUtc { get; set; }
    public DateTime? CompletedAtUtc { get; set; }
    public DateTime? ClosedAtUtc { get; set; }
    public DateTime? CancelledAtUtc { get; set; }
    public Invoice? Invoice { get; set; }

}
