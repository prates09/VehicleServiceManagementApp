﻿namespace Vsm.Domain.Entities;

public class Part
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string PartNumber { get; set; } = string.Empty;

    public decimal UnitPrice { get; set; }
    public int StockQty { get; set; }

    public int LowStockThreshold { get; set; } = 5;
}
