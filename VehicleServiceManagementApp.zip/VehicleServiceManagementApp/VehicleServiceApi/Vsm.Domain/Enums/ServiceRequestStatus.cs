﻿namespace Vsm.Domain.Enums;

public enum ServiceRequestStatus
{
    Requested = 1,
    Assigned = 2,
    InProgress = 3,
    Completed = 4,
    Closed = 5,
    Cancelled = 6
}
