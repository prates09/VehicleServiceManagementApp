﻿namespace Vsm.Domain.Enums;

public enum ServicePriority
{
    Normal = 1,
    Urgent = 2
}
