﻿using System.Net.Http.Headers;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Vsm.Api.Dtos.Billing;
using Vsm.Api.Dtos.ServiceRequests;
using Vsm.Domain.Entities;
using Vsm.Domain.Enums;
using Vsm.Infrastructure.Data;
using Vsm.Infrastructure.Identity;
using Xunit;

namespace Vsm.Tests;

public class BillingFlowTests : IClassFixture<CustomWebApplicationFactory>
{
    private readonly CustomWebApplicationFactory _factory;
    private readonly HttpClient _client;

    public BillingFlowTests(CustomWebApplicationFactory factory)
    {
        _factory = factory;

        _client = factory.CreateClient(new WebApplicationFactoryClientOptions
        {
            AllowAutoRedirect = false,
            BaseAddress = new Uri("http://localhost")
        });
    }

    private void SetBearer(string token) =>
        _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

    private void ClearBearer() => _client.DefaultRequestHeaders.Authorization = null;

    private async Task ResetDbAsync()
    {
        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

        await db.Database.EnsureDeletedAsync();
        await db.Database.EnsureCreatedAsync();
    }

    private async Task<int> EnsureCustomerProfileAndVehicleAsync(string customerUserName)
    {
        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();

        var user = await userManager.FindByNameAsync(customerUserName);
        if (user is null) throw new Exception("Identity user missing: " + customerUserName);

        var customer = await db.Customers.FirstOrDefaultAsync(c => c.ApplicationUserId == user.Id);
        if (customer == null)
        {
            customer = new Customer
            {
                ApplicationUserId = user.Id,
                FullName = "Test Customer",
                Phone = "9999999999",
                Email = $"{customerUserName}@test.com"
            };
            db.Customers.Add(customer);
            await db.SaveChangesAsync();
        }

        var vehicle = await db.Vehicles.FirstOrDefaultAsync(v => v.CustomerId == customer.Id);
        if (vehicle == null)
        {
            vehicle = new Vehicle
            {
                CustomerId = customer.Id,
                RegistrationNumber = "TR-" + Guid.NewGuid().ToString("N")[..6].ToUpper(),
                Make = "Tata",
                Model = "Nexon",
                Year = 2024
            };
            db.Vehicles.Add(vehicle);
            await db.SaveChangesAsync();
        }

        return vehicle.Id;
    }

    private async Task<int> EnsurePartAsync()
    {
        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

        var existing = await db.Parts.FirstOrDefaultAsync();
        if (existing != null) return existing.Id;

        var part = new Part
        {
            PartNumber = "P-001",
            Name = "Oil Filter",
            UnitPrice = 250m,
            StockQty = 10,
            LowStockThreshold = 2
        };

        db.Parts.Add(part);
        await db.SaveChangesAsync();
        return part.Id;
    }

    private async Task<int> EnsureServiceCategoryAsync()
    {
        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

        var existing = await db.ServiceCategories.FirstOrDefaultAsync();
        if (existing != null) return existing.Id;

        var category = new ServiceCategory
        {
            Name = "Test Service",
            Description = "Test service category",
            BasePrice = 1000m,
            IsActive = true
        };

        db.ServiceCategories.Add(category);
        await db.SaveChangesAsync();
        return category.Id;
    }

    [Fact]
    public async Task Auto_Billing_Uses_ServiceCategory_BasePrice()
    {
        await ResetDbAsync();

        const string pass = "Pass@123";

        var techUser = TestAuthHelpers.ShortUser("tech");
        var custUser = TestAuthHelpers.ShortUser("cust");

        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, techUser, pass, AppRoles.Technician);
        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, custUser, pass, AppRoles.Customer);

        var vehicleId = await EnsureCustomerProfileAndVehicleAsync(custUser);
        var partId = await EnsurePartAsync();
        var categoryId = await EnsureServiceCategoryAsync();

        // Get the category to verify BasePrice
        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var category = await db.ServiceCategories.FirstAsync(c => c.Id == categoryId);
        var expectedLaborCharge = category.BasePrice;

        // Customer creates SR with ServiceCategory
        var custToken = await TestAuthHelpers.LoginViaApiAsync(_client, custUser, pass);
        SetBearer(custToken);

        var srCreateRes = await _client.PostAsJsonAsync("/api/ServiceRequests",
            new CreateServiceRequestRequestDto(vehicleId, "Test issue", ServicePriority.Normal, categoryId));

        await TestAuthHelpers.EnsureOkAsync(srCreateRes, "Create ServiceRequest");
        var srDto = await TestAuthHelpers.ReadJsonAsync<ServiceRequestResponseDto>(srCreateRes.Content);
        var srId = srDto.Id;

        ClearBearer();

        // Manager assigns technician (need manager for this)
        var mgrUser = TestAuthHelpers.ShortUser("mgr");
        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, mgrUser, pass, AppRoles.ServiceManager);
        var mgrToken = await TestAuthHelpers.LoginViaApiAsync(_client, mgrUser, pass);
        SetBearer(mgrToken);

        await _client.PutAsJsonAsync($"/api/ServiceRequests/{srId}/assign",
            new AssignTechnicianDto(techUser));

        ClearBearer();

        // Technician -> InProgress
        var techToken = await TestAuthHelpers.LoginViaApiAsync(_client, techUser, pass);
        SetBearer(techToken);

        await _client.PutAsJsonAsync($"/api/ServiceRequests/{srId}/technician-status",
            new UpdateServiceRequestStatusDto(ServiceRequestStatus.InProgress, "Started work"));

        // Technician uses parts
        await _client.PostAsJsonAsync($"/api/ServiceRequests/{srId}/parts/use",
            new UsePartsRequestDto
            {
                Items = new List<UsePartItemDto>
                {
                    new() { PartId = partId, Quantity = 1 }
                }
            });

        // Technician completes -> AUTO-GENERATES INVOICE
        await _client.PutAsJsonAsync($"/api/ServiceRequests/{srId}/technician-status",
            new UpdateServiceRequestStatusDto(ServiceRequestStatus.Completed, "Completed"));

        ClearBearer();

        // Verify invoice was auto-generated with correct labor charge from ServiceCategory.BasePrice
        SetBearer(mgrToken);
        var invoiceRes = await _client.GetAsync($"/api/Billing/by-service-request/{srId}");
        await TestAuthHelpers.EnsureOkAsync(invoiceRes, "Get Auto-Generated Invoice");
        var invoice = await TestAuthHelpers.ReadJsonAsync<InvoiceResponseDto>(invoiceRes.Content);

        Assert.Equal(srId, invoice.ServiceRequestId);
        Assert.Equal(expectedLaborCharge, invoice.LaborCharge);
        Assert.True(invoice.PartsTotal > 0);
        Assert.Equal(0.10m, invoice.TaxRate); // Default tax rate
        Assert.False(invoice.IsPaid);

        ClearBearer();
    }
}