﻿using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using Vsm.Api.Dtos.Auth;
using Vsm.Infrastructure.Identity;

namespace Vsm.Tests;

public static class TestAuthHelpers
{
    private static readonly JsonSerializerOptions JsonOpts = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public static string ShortUser(string prefix)
        => $"{prefix}_{Guid.NewGuid().ToString("N")[..7]}";

    public static async Task EnsureUserWithRoleAsync(
        IServiceProvider root,
        string userName,
        string password,
        string role)
    {
        using var scope = root.CreateScope();
        var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
        var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();

        if (!await roleManager.RoleExistsAsync(role))
            await roleManager.CreateAsync(new IdentityRole(role));

        var user = await userManager.FindByNameAsync(userName);
        if (user == null)
        {
            user = new ApplicationUser { UserName = userName };
            var create = await userManager.CreateAsync(user, password);
            if (!create.Succeeded)
                throw new Exception("Create user failed: " + string.Join("; ", create.Errors.Select(e => e.Description)));
        }

        if (!await userManager.IsInRoleAsync(user, role))
            await userManager.AddToRoleAsync(user, role);
    }

    public static async Task<string> LoginViaApiAsync(HttpClient client, string userName, string password)
    {
        // IMPORTANT: don't construct LoginRequestDto (yours varies). Just send the shape the API expects.
        var res = await client.PostAsJsonAsync("/api/Auth/login", new
        {
            userName,
            password
        });

        if (res.StatusCode == HttpStatusCode.Unauthorized)
        {
            var body = await res.Content.ReadAsStringAsync();
            throw new Exception($"Login failed (401) for '{userName}'. Body: {body}");
        }

        if (!res.IsSuccessStatusCode)
        {
            var body = await res.Content.ReadAsStringAsync();
            throw new Exception($"Login failed ({(int)res.StatusCode}) for '{userName}'. Body: {body}");
        }

        var dto = await res.Content.ReadFromJsonAsync<TokenResponseDto>(JsonOpts);
        if (dto == null || string.IsNullOrWhiteSpace(dto.Token))
            throw new Exception("TokenResponseDto deserialization failed / token empty.");

        return dto.Token;
    }

    public static async Task EnsureOkAsync(HttpResponseMessage res, string label)
    {
        if (!res.IsSuccessStatusCode)
        {
            var body = await res.Content.ReadAsStringAsync();
            throw new Exception($"{label} failed: {(int)res.StatusCode} {res.StatusCode}\nBody:\n{body}");
        }
    }

    public static async Task<T> ReadJsonAsync<T>(HttpContent content)
    {
        var obj = await content.ReadFromJsonAsync<T>(JsonOpts);
        if (obj == null) throw new Exception($"Failed to deserialize {typeof(T).Name}");
        return obj;
    }
}
