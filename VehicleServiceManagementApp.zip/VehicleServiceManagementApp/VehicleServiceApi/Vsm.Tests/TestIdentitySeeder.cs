﻿using Microsoft.AspNetCore.Identity;
using Vsm.Infrastructure.Identity;

namespace Vsm.Tests;

public static class TestIdentitySeeder
{
    public const string AdminUser = "admin_test";
    public const string ManagerUser = "manager_test";
    public const string TechUser = "tech_test";
    public const string CustomerUser = "customer_test";
    public const string Password = "Test@123";

    public static async Task SeedAsync(RoleManager<IdentityRole> roleManager, UserManager<ApplicationUser> userManager)
    {
        // IMPORTANT: role names must match your API EXACTLY
        await EnsureRoleAsync(roleManager, "Admin");
        await EnsureRoleAsync(roleManager, "ServiceManager");
        await EnsureRoleAsync(roleManager, "Technician");
        await EnsureRoleAsync(roleManager, "Customer");

        await EnsureUserAsync(userManager, AdminUser, Password, "Admin");
        await EnsureUserAsync(userManager, ManagerUser, Password, "ServiceManager");
        await EnsureUserAsync(userManager, TechUser, Password, "Technician");
        await EnsureUserAsync(userManager, CustomerUser, Password, "Customer");
    }

    private static async Task EnsureRoleAsync(RoleManager<IdentityRole> roleManager, string role)
    {
        if (!await roleManager.RoleExistsAsync(role))
        {
            var res = await roleManager.CreateAsync(new IdentityRole(role));
            if (!res.Succeeded)
                throw new Exception("Failed to create role: " + string.Join(", ", res.Errors.Select(e => e.Description)));
        }
    }

    private static async Task EnsureUserAsync(UserManager<ApplicationUser> userManager, string userName, string password, string role)
    {
        var user = await userManager.FindByNameAsync(userName);

        if (user == null)
        {
            user = new ApplicationUser { UserName = userName, Email = $"{userName}@test.local" };
            var create = await userManager.CreateAsync(user, password);
            if (!create.Succeeded)
                throw new Exception($"Failed to create user '{userName}': " + string.Join(", ", create.Errors.Select(e => e.Description)));
        }

        if (!await userManager.IsInRoleAsync(user, role))
        {
            var addRole = await userManager.AddToRoleAsync(user, role);
            if (!addRole.Succeeded)
                throw new Exception($"Failed to add role '{role}' to '{userName}': " + string.Join(", ", addRole.Errors.Select(e => e.Description)));
        }
    }
}
