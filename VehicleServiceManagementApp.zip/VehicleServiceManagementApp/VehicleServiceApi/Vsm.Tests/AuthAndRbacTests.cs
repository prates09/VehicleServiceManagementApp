﻿using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Vsm.Domain.Entities;
using Vsm.Infrastructure.Data;
using Vsm.Infrastructure.Identity;
using Xunit;

namespace Vsm.Tests;

public class AuthAndRbacTests : IClassFixture<CustomWebApplicationFactory>
{
    private readonly CustomWebApplicationFactory _factory;
    private readonly HttpClient _client;

    public AuthAndRbacTests(CustomWebApplicationFactory factory)
    {
        _factory = factory;

        _client = factory.CreateClient(new WebApplicationFactoryClientOptions
        {
            AllowAutoRedirect = false,
            BaseAddress = new Uri("http://localhost")
        });
    }

    private void SetBearer(string token) =>
        _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

    private void ClearBearer() => _client.DefaultRequestHeaders.Authorization = null;

    private async Task ResetDbAsync()
    {
        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

        await db.Database.EnsureDeletedAsync();
        await db.Database.EnsureCreatedAsync();
    }

    private async Task EnsureCustomerProfileAndVehicleAsync(string customerUserName)
    {
        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();

        var user = await userManager.FindByNameAsync(customerUserName);
        if (user is null) throw new Exception("Identity user missing: " + customerUserName);

        var customer = await db.Customers.FirstOrDefaultAsync(c => c.ApplicationUserId == user.Id);
        if (customer == null)
        {
            customer = new Customer
            {
                ApplicationUserId = user.Id,
                FullName = "Test Customer",
                Phone = "9999999999",
                Email = $"{customerUserName}@test.com"
            };
            db.Customers.Add(customer);
            await db.SaveChangesAsync();
        }

        var vehicle = await db.Vehicles.FirstOrDefaultAsync(v => v.CustomerId == customer.Id);
        if (vehicle == null)
        {
            vehicle = new Vehicle
            {
                CustomerId = customer.Id,
                RegistrationNumber = "TR-" + Guid.NewGuid().ToString("N")[..6].ToUpper(),
                Make = "Tata",
                Model = "Nexon",
                Year = 2024
            };
            db.Vehicles.Add(vehicle);
            await db.SaveChangesAsync();
        }
    }

    [Fact]
    public async Task Customer_CanAccess_MyVehicles_ButForbidden_On_AllVehicles()
    {
        await ResetDbAsync();

        const string pass = "Pass@123";
        var custUser = TestAuthHelpers.ShortUser("cust");

        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, custUser, pass, AppRoles.Customer);
        await EnsureCustomerProfileAndVehicleAsync(custUser);

        var token = await TestAuthHelpers.LoginViaApiAsync(_client, custUser, pass);
        SetBearer(token);

        var my = await _client.GetAsync("/api/Vehicles/my");
        Assert.Equal(HttpStatusCode.OK, my.StatusCode);

        var all = await _client.GetAsync("/api/Vehicles");
        Assert.True(all.StatusCode is HttpStatusCode.Forbidden or HttpStatusCode.Unauthorized);

        ClearBearer();
    }

    [Fact]
    public async Task ServiceManager_CanAccess_AllServiceRequests_ButCustomer_Forbidden()
    {
        await ResetDbAsync();

        const string pass = "Pass@123";
        var mgrUser = TestAuthHelpers.ShortUser("mgr");
        var custUser = TestAuthHelpers.ShortUser("cust");

        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, mgrUser, pass, AppRoles.ServiceManager);
        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, custUser, pass, AppRoles.Customer);
        await EnsureCustomerProfileAndVehicleAsync(custUser);

        var mgrToken = await TestAuthHelpers.LoginViaApiAsync(_client, mgrUser, pass);
        SetBearer(mgrToken);

        var mgrRes = await _client.GetAsync("/api/ServiceRequests");
        Assert.Equal(HttpStatusCode.OK, mgrRes.StatusCode);

        ClearBearer();

        var custToken = await TestAuthHelpers.LoginViaApiAsync(_client, custUser, pass);
        SetBearer(custToken);

        var custRes = await _client.GetAsync("/api/ServiceRequests");
        Assert.True(custRes.StatusCode is HttpStatusCode.Forbidden or HttpStatusCode.Unauthorized);

        ClearBearer();
    }

    [Fact]
    public async Task SetRole_RemovesOldRole_EnforcesSingleRolePolicy()
    {
        await ResetDbAsync();

        const string pass = "Pass@123";
        var testUser = TestAuthHelpers.ShortUser("testuser");
        var adminUser = TestAuthHelpers.ShortUser("admin");

        // Create user with Customer role
        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, testUser, pass, AppRoles.Customer);
        
        // Create admin user
        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, adminUser, pass, AppRoles.Admin);

        // Verify user starts with Customer role
        using (var scope = _factory.Services.CreateScope())
        {
            var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
            var user = await userManager.FindByNameAsync(testUser);
            Assert.NotNull(user);
            
            var initialRoles = await userManager.GetRolesAsync(user);
            Assert.Single(initialRoles);
            Assert.Contains(AppRoles.Customer, initialRoles);
        }

        // Admin assigns Technician role
        var adminToken = await TestAuthHelpers.LoginViaApiAsync(_client, adminUser, pass);
        SetBearer(adminToken);

        var setRoleResponse = await _client.PutAsJsonAsync(
            $"/api/Auth/users/{testUser}/role",
            new { Role = AppRoles.Technician });

        await TestAuthHelpers.EnsureOkAsync(setRoleResponse, "SetRole to Technician");

        ClearBearer();

        // Verify user now has ONLY Technician role (not Customer)
        using (var scope = _factory.Services.CreateScope())
        {
            var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
            var user = await userManager.FindByNameAsync(testUser);
            Assert.NotNull(user);
            
            var finalRoles = await userManager.GetRolesAsync(user);
            Assert.Single(finalRoles); // Must have exactly one role
            Assert.Contains(AppRoles.Technician, finalRoles);
            Assert.DoesNotContain(AppRoles.Customer, finalRoles); // Old role must be removed
        }

        // Test again: Change from Technician to ServiceManager
        SetBearer(adminToken);
        var setRoleResponse2 = await _client.PutAsJsonAsync(
            $"/api/Auth/users/{testUser}/role",
            new { Role = AppRoles.ServiceManager });

        await TestAuthHelpers.EnsureOkAsync(setRoleResponse2, "SetRole to ServiceManager");
        ClearBearer();

        // Verify user now has ONLY ServiceManager role
        using (var scope = _factory.Services.CreateScope())
        {
            var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
            var user = await userManager.FindByNameAsync(testUser);
            Assert.NotNull(user);
            
            var finalRoles = await userManager.GetRolesAsync(user);
            Assert.Single(finalRoles); // Must have exactly one role
            Assert.Contains(AppRoles.ServiceManager, finalRoles);
            Assert.DoesNotContain(AppRoles.Technician, finalRoles); // Old role must be removed
            Assert.DoesNotContain(AppRoles.Customer, finalRoles); // Original role must still be removed
        }
    }

    [Fact]
    public async Task Admin_CanDeleteUser_ButNonAdmin_Cannot()
    {
        await ResetDbAsync();

        const string pass = "Pass@123";
        var adminUser = TestAuthHelpers.ShortUser("admin");
        var testUser = TestAuthHelpers.ShortUser("testuser");
        var managerUser = TestAuthHelpers.ShortUser("manager");

        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, adminUser, pass, AppRoles.Admin);
        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, testUser, pass, AppRoles.Customer);
        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, managerUser, pass, AppRoles.ServiceManager);

        // Get test user ID
        string testUserId;
        using (var scope = _factory.Services.CreateScope())
        {
            var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
            var user = await userManager.FindByNameAsync(testUser);
            testUserId = user!.Id;
        }

        // Manager cannot toggle user status
        var managerToken = await TestAuthHelpers.LoginViaApiAsync(_client, managerUser, pass);
        SetBearer(managerToken);

        var managerToggleResponse = await _client.PostAsync($"/api/Auth/users/{testUserId}/toggle-status", null);
        Assert.True(managerToggleResponse.StatusCode is HttpStatusCode.Forbidden or HttpStatusCode.Unauthorized);

        ClearBearer();

        // Admin can deactivate user
        var adminToken = await TestAuthHelpers.LoginViaApiAsync(_client, adminUser, pass);
        SetBearer(adminToken);

        var adminToggleResponse = await _client.PostAsync($"/api/Auth/users/{testUserId}/toggle-status", null);
        await TestAuthHelpers.EnsureOkAsync(adminToggleResponse, "Admin toggle user status");

        // Verify user is deactivated (not deleted)
        using (var scope = _factory.Services.CreateScope())
        {
            var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
            var deactivatedUser = await userManager.FindByNameAsync(testUser);
            Assert.NotNull(deactivatedUser); // User still exists
            Assert.False(deactivatedUser.IsActive); // But is deactivated
        }

        ClearBearer();
    }

    [Fact]
    public async Task Admin_CannotDelete_Themselves()
    {
        await ResetDbAsync();

        const string pass = "Pass@123";
        var adminUser = TestAuthHelpers.ShortUser("admin");

        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, adminUser, pass, AppRoles.Admin);

        // Get admin user ID
        string adminUserId;
        using (var scope = _factory.Services.CreateScope())
        {
            var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
            var user = await userManager.FindByNameAsync(adminUser);
            adminUserId = user!.Id;
        }

        var adminToken = await TestAuthHelpers.LoginViaApiAsync(_client, adminUser, pass);
        SetBearer(adminToken);

        var toggleResponse = await _client.PostAsync($"/api/Auth/users/{adminUserId}/toggle-status", null);
        Assert.Equal(HttpStatusCode.BadRequest, toggleResponse.StatusCode);

        // Verify user still exists and is active
        using (var scope = _factory.Services.CreateScope())
        {
            var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
            var user = await userManager.FindByNameAsync(adminUser);
            Assert.NotNull(user);
            Assert.True(user.IsActive); // Should still be active
        }

        ClearBearer();
    }

    [Fact]
    public async Task DeleteUser_HandlesCascadingDeletes_Correctly()
    {
        await ResetDbAsync();

        const string pass = "Pass@123";
        var adminUser = TestAuthHelpers.ShortUser("admin");
        var techUser = TestAuthHelpers.ShortUser("tech");
        var customerUser = TestAuthHelpers.ShortUser("customer");

        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, adminUser, pass, AppRoles.Admin);
        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, techUser, pass, AppRoles.Technician);
        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, customerUser, pass, AppRoles.Customer);

        // Setup customer profile and vehicle
        await EnsureCustomerProfileAndVehicleAsync(customerUser);

        // Create service request assigned to technician
        string techId;
        using (var scope = _factory.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();

            var tech = await userManager.FindByNameAsync(techUser);
            techId = tech!.Id; // Store techId before deletion
            var customerUserEntity = await userManager.FindByNameAsync(customerUser);
            var customer = await db.Customers.FirstOrDefaultAsync(c => c.ApplicationUserId == customerUserEntity!.Id);
            var vehicle = await db.Vehicles.FirstOrDefaultAsync(v => v.CustomerId == customer!.Id);

            var serviceRequest = new ServiceRequest
            {
                CustomerId = customer!.Id,
                VehicleId = vehicle!.Id,
                IssueDescription = "Test issue",
                Status = Vsm.Domain.Enums.ServiceRequestStatus.Assigned,
                AssignedTechnicianUserId = tech.Id
            };
            db.ServiceRequests.Add(serviceRequest);

            // Create notification for technician
            var notification = new Notification
            {
                UserId = tech.Id,
                Title = "Test Notification",
                Message = "Test message"
            };
            db.Notifications.Add(notification);

            await db.SaveChangesAsync();
        }

        // Deactivate technician user
        var adminToken = await TestAuthHelpers.LoginViaApiAsync(_client, adminUser, pass);
        SetBearer(adminToken);

        var toggleResponse = await _client.PostAsync($"/api/Auth/users/{techId}/toggle-status", null);
        await TestAuthHelpers.EnsureOkAsync(toggleResponse, "Deactivate technician user");

        ClearBearer();

        // Verify cascading updates (user is deactivated, not deleted)
        using (var scope = _factory.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();

            // User should still exist but be deactivated
            var deactivatedUser = await userManager.FindByNameAsync(techUser);
            Assert.NotNull(deactivatedUser); // User still exists
            Assert.False(deactivatedUser.IsActive); // But is deactivated

            // Service request should have AssignedTechnicianUserId set to null and status reset
            var serviceRequest = await db.ServiceRequests
                .FirstOrDefaultAsync(sr => sr.AssignedTechnicianUserId == null && sr.IssueDescription == "Test issue");
            Assert.NotNull(serviceRequest);
            Assert.Null(serviceRequest.AssignedTechnicianUserId);
            Assert.Equal(Vsm.Domain.Enums.ServiceRequestStatus.Requested, serviceRequest.Status);

            // Notifications should still exist (not deleted, as per requirement to preserve all data)
            var notifications = await db.Notifications
                .Where(n => n.UserId == techId)
                .ToListAsync();
            Assert.NotEmpty(notifications); // Notifications are preserved
        }
    }

    [Fact]
    public async Task Admin_CanCreateUser_WithAnyRole_ExceptAdmin()
    {
        await ResetDbAsync();

        const string pass = "Pass@123";
        var adminUser = TestAuthHelpers.ShortUser("admin");
        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, adminUser, pass, AppRoles.Admin);

        var adminToken = await TestAuthHelpers.LoginViaApiAsync(_client, adminUser, pass);
        SetBearer(adminToken);

        // Test creating ServiceManager
        var createServiceManagerResponse = await _client.PostAsJsonAsync("/api/Auth/users",
            new { UserName = "newmanager", Role = AppRoles.ServiceManager, FullName = "New Manager", Email = "newmanager@test.com" });
        await TestAuthHelpers.EnsureOkAsync(createServiceManagerResponse, "Create ServiceManager");

        var serviceManagerResult = await JsonDocument.ParseAsync(await createServiceManagerResponse.Content.ReadAsStreamAsync());
        Assert.NotNull(serviceManagerResult);
        Assert.NotNull(serviceManagerResult.RootElement.GetProperty("userName").GetString());
        Assert.NotNull(serviceManagerResult.RootElement.GetProperty("password").GetString());
        Assert.Equal(AppRoles.ServiceManager, serviceManagerResult.RootElement.GetProperty("role").GetString());

        // Test creating Technician
        var createTechResponse = await _client.PostAsJsonAsync("/api/Auth/users",
            new { UserName = "newtech", Role = AppRoles.Technician, FullName = "New Technician", Email = "newtech@test.com" });
        await TestAuthHelpers.EnsureOkAsync(createTechResponse, "Create Technician");

        // Test creating Customer
        var createCustomerResponse = await _client.PostAsJsonAsync("/api/Auth/users",
            new { UserName = "newcustomer", Role = AppRoles.Customer, FullName = "New Customer", Email = "newcustomer@test.com" });
        await TestAuthHelpers.EnsureOkAsync(createCustomerResponse, "Create Customer");

        var customerResult = await JsonDocument.ParseAsync(await createCustomerResponse.Content.ReadAsStreamAsync());
        Assert.NotNull(customerResult);
        var customerId = customerResult.RootElement.GetProperty("userId").GetString();
        Assert.NotNull(customerId);

        // Verify customer profile is linked
        using (var scope = _factory.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            var customer = await db.Customers.FirstOrDefaultAsync(c => c.ApplicationUserId == customerId);
            Assert.NotNull(customer);
        }

        ClearBearer();
    }

    [Fact]
    public async Task DeactivatedUser_CannotLogin_ButCanLoginAfterReactivation()
    {
        await ResetDbAsync();

        const string pass = "Pass@123";
        var adminUser = TestAuthHelpers.ShortUser("admin");
        var testUser = TestAuthHelpers.ShortUser("testuser");

        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, adminUser, pass, AppRoles.Admin);
        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, testUser, pass, AppRoles.Customer);

        // Get test user ID
        string testUserId;
        using (var scope = _factory.Services.CreateScope())
        {
            var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
            var user = await userManager.FindByNameAsync(testUser);
            testUserId = user!.Id;
        }

        // Verify active user can login
        var loginResponse1 = await _client.PostAsJsonAsync("/api/Auth/login", new { userName = testUser, password = pass });
        Assert.Equal(HttpStatusCode.OK, loginResponse1.StatusCode);

        // Deactivate user
        var adminToken = await TestAuthHelpers.LoginViaApiAsync(_client, adminUser, pass);
        SetBearer(adminToken);

        var toggleResponse = await _client.PostAsync($"/api/Auth/users/{testUserId}/toggle-status", null);
        await TestAuthHelpers.EnsureOkAsync(toggleResponse, "Deactivate user");

        ClearBearer();

        // Verify deactivated user cannot login (should return 403)
        var loginResponse2 = await _client.PostAsJsonAsync("/api/Auth/login", new { userName = testUser, password = pass });
        Assert.Equal(HttpStatusCode.Forbidden, loginResponse2.StatusCode);
        
        var errorBody = await loginResponse2.Content.ReadAsStringAsync();
        Assert.Contains("deactivated", errorBody, StringComparison.OrdinalIgnoreCase);

        // Reactivate user
        SetBearer(adminToken);
        var reactivateResponse = await _client.PostAsync($"/api/Auth/users/{testUserId}/toggle-status", null);
        await TestAuthHelpers.EnsureOkAsync(reactivateResponse, "Reactivate user");
        ClearBearer();

        // Verify reactivated user can login again
        var loginResponse3 = await _client.PostAsJsonAsync("/api/Auth/login", new { userName = testUser, password = pass });
        Assert.Equal(HttpStatusCode.OK, loginResponse3.StatusCode);
    }

    [Fact]
    public async Task Admin_CannotCreateUser_WithAdminRole()
    {
        await ResetDbAsync();

        const string pass = "Pass@123";
        var adminUser = TestAuthHelpers.ShortUser("admin");
        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, adminUser, pass, AppRoles.Admin);

        var adminToken = await TestAuthHelpers.LoginViaApiAsync(_client, adminUser, pass);
        SetBearer(adminToken);

        var createAdminResponse = await _client.PostAsJsonAsync("/api/Auth/users",
            new { UserName = "newadmin", Role = AppRoles.Admin, FullName = "New Admin", Email = "newadmin@test.com" });
        
        Assert.Equal(HttpStatusCode.BadRequest, createAdminResponse.StatusCode);

        // Verify user was not created
        using (var scope = _factory.Services.CreateScope())
        {
            var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
            var user = await userManager.FindByNameAsync("newadmin");
            Assert.Null(user);
        }

        ClearBearer();
    }

    [Fact]
    public async Task NonAdmin_CannotCreateUsers()
    {
        await ResetDbAsync();

        const string pass = "Pass@123";
        var managerUser = TestAuthHelpers.ShortUser("manager");
        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, managerUser, pass, AppRoles.ServiceManager);

        var managerToken = await TestAuthHelpers.LoginViaApiAsync(_client, managerUser, pass);
        SetBearer(managerToken);

        var createUserResponse = await _client.PostAsJsonAsync("/api/Auth/users",
            new { UserName = "newuser", Role = AppRoles.Customer, FullName = "New User", Email = "newuser@test.com" });
        
        Assert.True(createUserResponse.StatusCode is HttpStatusCode.Forbidden or HttpStatusCode.Unauthorized);

        ClearBearer();
    }

    [Fact]
    public async Task CreateUser_ReturnsGeneratedPassword_AndUserDetails()
    {
        await ResetDbAsync();

        const string pass = "Pass@123";
        var adminUser = TestAuthHelpers.ShortUser("admin");
        await TestAuthHelpers.EnsureUserWithRoleAsync(_factory.Services, adminUser, pass, AppRoles.Admin);

        var adminToken = await TestAuthHelpers.LoginViaApiAsync(_client, adminUser, pass);
        SetBearer(adminToken);

        var newUserName = "testuser_" + Guid.NewGuid().ToString("N")[..8];
        var createResponse = await _client.PostAsJsonAsync("/api/Auth/users",
            new { UserName = newUserName, Role = AppRoles.Customer, FullName = "Test User", Email = $"{newUserName}@test.com" });
        
        await TestAuthHelpers.EnsureOkAsync(createResponse, "Create user");

        var result = await JsonDocument.ParseAsync(await createResponse.Content.ReadAsStreamAsync());
        Assert.NotNull(result);
        
        var userId = result.RootElement.GetProperty("userId").GetString();
        var userName = result.RootElement.GetProperty("userName").GetString();
        var generatedPassword = result.RootElement.GetProperty("password").GetString();
        var role = result.RootElement.GetProperty("role").GetString();

        Assert.NotNull(userId);
        Assert.Equal(newUserName, userName);
        Assert.NotNull(generatedPassword);
        Assert.True(generatedPassword.Length >= 12); // Password should be at least 12 characters
        Assert.Equal(AppRoles.Customer, role);

        // Verify user can login with generated password
        ClearBearer();
        var loginResponse = await _client.PostAsJsonAsync("/api/Auth/login",
            new { UserName = newUserName, Password = generatedPassword });
        Assert.Equal(HttpStatusCode.OK, loginResponse.StatusCode);

        ClearBearer();
    }
}