﻿using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.IdentityModel.Tokens;
using Vsm.Infrastructure.Data;

namespace Vsm.Tests;

public class CustomWebApplicationFactory : WebApplicationFactory<Program>
{
    // Keep this EXACT same key as you use in ConfigureAppConfiguration
    private const string TestJwtKey = "THIS_IS_A_TEST_KEY_1234567890_ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    private SqliteConnection? _connection;

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");

        builder.ConfigureAppConfiguration((context, config) =>
        {
            var jwt = new Dictionary<string, string?>
            {
                ["Jwt:Key"] = TestJwtKey,
                ["Jwt:Issuer"] = "Vsm.Test",
                ["Jwt:Audience"] = "Vsm.Test",
                ["Jwt:ExpireMinutes"] = "120"
            };

            config.AddInMemoryCollection(jwt);
        });

        builder.ConfigureServices(services =>
        {
            // ✅ Remove SQL Server DbContext registrations
            services.RemoveAll<DbContextOptions<AppDbContext>>();
            services.RemoveAll<AppDbContext>();

            // ✅ Single in-memory SQLite connection for the whole factory lifetime
            _connection ??= new SqliteConnection("DataSource=:memory:;Cache=Shared");
            if (_connection.State != System.Data.ConnectionState.Open)
                _connection.Open();

            services.AddDbContext<AppDbContext>(options =>
            {
                options.UseSqlite(_connection);
            });

            // ✅ CRITICAL: Force JWT bearer to use the SAME test key + relax issuer/audience in Testing
            services.PostConfigureAll<JwtBearerOptions>(opt =>
            {
                opt.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    ValidateIssuerSigningKey = true,
                    ValidateLifetime = true,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(TestJwtKey)),
                    ClockSkew = TimeSpan.Zero
                };
            });

            // ✅ Create schema once
            var sp = services.BuildServiceProvider();
            using var scope = sp.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            db.Database.EnsureCreated();
        });
    }

    protected override void Dispose(bool disposing)
    {
        base.Dispose(disposing);

        if (disposing)
        {
            _connection?.Close();
            _connection?.Dispose();
            _connection = null;
        }
    }
}