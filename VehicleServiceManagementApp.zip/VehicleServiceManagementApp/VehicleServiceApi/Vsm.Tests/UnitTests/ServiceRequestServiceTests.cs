using Vsm.Application.Services;
using Vsm.Domain.Enums;
using Xunit;

namespace Vsm.Tests.UnitTests;

public class ServiceRequestServiceTests
{
    private readonly ServiceRequestService _service;

    public ServiceRequestServiceTests()
    {
        _service = new ServiceRequestService();
    }

    [Fact]
    public void IsValidStatusTransition_FromRequestedToAssigned_ReturnsTrue()
    {
        // Act
        var result = _service.IsValidStatusTransition(
            ServiceRequestStatus.Requested, 
            ServiceRequestStatus.Assigned);

        // Assert
        Assert.True(result);
    }

    [Fact]
    public void IsValidStatusTransition_FromAssignedToInProgress_ReturnsTrue()
    {
        // Act
        var result = _service.IsValidStatusTransition(
            ServiceRequestStatus.Assigned, 
            ServiceRequestStatus.InProgress);

        // Assert
        Assert.True(result);
    }

    [Fact]
    public void IsValidStatusTransition_FromInProgressToCompleted_ReturnsTrue()
    {
        // Act
        var result = _service.IsValidStatusTransition(
            ServiceRequestStatus.InProgress, 
            ServiceRequestStatus.Completed);

        // Assert
        Assert.True(result);
    }

    [Fact]
    public void IsValidStatusTransition_FromCompletedToClosed_ReturnsTrue()
    {
        // Act
        var result = _service.IsValidStatusTransition(
            ServiceRequestStatus.Completed, 
            ServiceRequestStatus.Closed);

        // Assert
        Assert.True(result);
    }

    [Fact]
    public void IsValidStatusTransition_FromRequestedToCompleted_ReturnsFalse()
    {
        // Act
        var result = _service.IsValidStatusTransition(
            ServiceRequestStatus.Requested, 
            ServiceRequestStatus.Completed);

        // Assert
        Assert.False(result);
    }

    [Fact]
    public void IsValidStatusTransition_FromClosedToAny_ReturnsFalse()
    {
        // Act
        var result = _service.IsValidStatusTransition(
            ServiceRequestStatus.Closed, 
            ServiceRequestStatus.InProgress);

        // Assert
        Assert.False(result);
    }

    [Fact]
    public void IsValidStatusTransition_FromCancelledToAny_ReturnsFalse()
    {
        // Act
        var result = _service.IsValidStatusTransition(
            ServiceRequestStatus.Cancelled, 
            ServiceRequestStatus.InProgress);

        // Assert
        Assert.False(result);
    }

    [Fact]
    public void CanCancel_WithRequestedStatus_ReturnsTrue()
    {
        // Act
        var result = _service.CanCancel(ServiceRequestStatus.Requested);

        // Assert
        Assert.True(result);
    }

    [Fact]
    public void CanCancel_WithInProgressStatus_ReturnsTrue()
    {
        // Act
        var result = _service.CanCancel(ServiceRequestStatus.InProgress);

        // Assert
        Assert.True(result);
    }

    [Fact]
    public void CanCancel_WithCompletedStatus_ReturnsFalse()
    {
        // Act
        var result = _service.CanCancel(ServiceRequestStatus.Completed);

        // Assert
        Assert.False(result);
    }

    [Fact]
    public void CanAssign_WithRequestedStatus_ReturnsTrue()
    {
        // Act
        var result = _service.CanAssign(ServiceRequestStatus.Requested);

        // Assert
        Assert.True(result);
    }

    [Fact]
    public void CanAssign_WithAssignedStatus_ReturnsFalse()
    {
        // Act
        var result = _service.CanAssign(ServiceRequestStatus.Assigned);

        // Assert
        Assert.False(result);
    }

    [Fact]
    public void ValidateServiceRequestData_WithValidData_ReturnsValid()
    {
        // Arrange
        var vehicleId = 1;
        var issueDescription = "Engine oil leakage needs immediate attention";
        var priority = ServicePriority.Normal;

        // Act
        var result = _service.ValidateServiceRequestData(vehicleId, issueDescription, priority);

        // Assert
        Assert.True(result.IsValid);
        Assert.Empty(result.Errors);
    }

    [Fact]
    public void ValidateServiceRequestData_WithZeroVehicleId_ReturnsInvalid()
    {
        // Arrange
        var vehicleId = 0;
        var issueDescription = "Engine oil leakage";
        var priority = ServicePriority.Normal;

        // Act
        var result = _service.ValidateServiceRequestData(vehicleId, issueDescription, priority);

        // Assert
        Assert.False(result.IsValid);
        Assert.Contains("Vehicle ID must be greater than zero.", result.Errors);
    }

    [Fact]
    public void ValidateServiceRequestData_WithEmptyIssueDescription_ReturnsInvalid()
    {
        // Arrange
        var vehicleId = 1;
        var issueDescription = "";
        var priority = ServicePriority.Normal;

        // Act
        var result = _service.ValidateServiceRequestData(vehicleId, issueDescription, priority);

        // Assert
        Assert.False(result.IsValid);
        Assert.Contains("Issue description is required.", result.Errors);
    }

}

