using Vsm.Application.Services;
using Vsm.Domain.Enums;
using Xunit;

namespace Vsm.Tests.UnitTests;

public class ReportServiceTests
{
    private readonly ReportService _service;

    public ReportServiceTests()
    {
        _service = new ReportService();
    }

    [Fact]
    public void CalculateSummary_WithValidCounts_ReturnsCorrectSummary()
    {
        // Arrange
        var total = 100;
        var requested = 20;
        var assigned = 15;
        var inProgress = 10;
        var completed = 30;
        var closed = 20;
        var cancelled = 5;

        // Act
        var result = _service.CalculateSummary(
            total, requested, assigned, inProgress, completed, closed, cancelled);

        // Assert
        Assert.Equal(100, result.Total);
        Assert.Equal(20, result.Requested);
        Assert.Equal(15, result.Assigned);
        Assert.Equal(10, result.InProgress);
        Assert.Equal(30, result.Completed);
        Assert.Equal(20, result.Closed);
        Assert.Equal(5, result.Cancelled);
        Assert.Equal(45, result.Pending); // 20 + 15 + 10
    }

    [Fact]
    public void CalculateSummary_WithMismatchedTotal_ThrowsArgumentException()
    {
        // Arrange
        var requested = 20;
        var assigned = 15;
        var inProgress = 10;
        var completed = 30;
        var closed = 20;
        var cancelled = 5; // Sum = 100, but let's say total is 99

        // Act & Assert
        var ex = Assert.Throws<ArgumentException>(() => 
            _service.CalculateSummary(99, requested, assigned, inProgress, completed, closed, cancelled));
        Assert.Contains("does not match sum", ex.Message);
    }

    [Fact]
    public void CalculateSummary_WithNegativeCount_ThrowsArgumentException()
    {
        // Arrange
        var total = 100;
        var requested = -5; // Invalid

        // Act & Assert
        var ex = Assert.Throws<ArgumentException>(() => 
            _service.CalculateSummary(total, requested, 15, 10, 30, 20, 5));
        Assert.Contains("cannot be negative", ex.Message);
    }

    [Fact]
    public void GroupByStatus_WithMultipleStatuses_ReturnsCorrectGrouping()
    {
        // Arrange
        var statuses = new List<ServiceRequestStatus>
        {
            ServiceRequestStatus.Requested,
            ServiceRequestStatus.Requested,
            ServiceRequestStatus.InProgress,
            ServiceRequestStatus.Completed,
            ServiceRequestStatus.Completed,
            ServiceRequestStatus.Completed
        };

        // Act
        var result = _service.GroupByStatus(statuses);

        // Assert
        Assert.Equal(3, result.Count);
        Assert.Equal(2, result[ServiceRequestStatus.Requested]);
        Assert.Equal(1, result[ServiceRequestStatus.InProgress]);
        Assert.Equal(3, result[ServiceRequestStatus.Completed]);
    }

    [Fact]
    public void GroupByStatus_WithNullInput_ThrowsArgumentNullException()
    {
        // Act & Assert
        Assert.Throws<ArgumentNullException>(() => 
            _service.GroupByStatus(null!));
    }

    [Fact]
    public void GroupByStatus_WithEmptyList_ReturnsEmptyDictionary()
    {
        // Arrange
        var statuses = new List<ServiceRequestStatus>();

        // Act
        var result = _service.GroupByStatus(statuses);

        // Assert
        Assert.Empty(result);
    }

    [Fact]
    public void CalculateCompletionRate_WithValidInputs_ReturnsCorrectRate()
    {
        // Arrange
        var completed = 75;
        var total = 100;

        // Act
        var result = _service.CalculateCompletionRate(completed, total);

        // Assert
        Assert.Equal(75m, result);
    }

    [Fact]
    public void CalculateCompletionRate_WithZeroTotal_ReturnsZero()
    {
        // Arrange
        var completed = 0;
        var total = 0;

        // Act
        var result = _service.CalculateCompletionRate(completed, total);

        // Assert
        Assert.Equal(0m, result);
    }

    [Fact]
    public void CalculateCompletionRate_WithAllCompleted_ReturnsHundred()
    {
        // Arrange
        var completed = 50;
        var total = 50;

        // Act
        var result = _service.CalculateCompletionRate(completed, total);

        // Assert
        Assert.Equal(100m, result);
    }

    [Fact]
    public void CalculateCompletionRate_WithPartialCompletion_ReturnsCorrectRate()
    {
        // Arrange
        var completed = 33;
        var total = 100;

        // Act
        var result = _service.CalculateCompletionRate(completed, total);

        // Assert
        Assert.Equal(33m, result);
    }

    [Fact]
    public void CalculateCompletionRate_WithInvalidCompletedCount_ThrowsArgumentException()
    {
        // Arrange
        var completed = 150; // More than total
        var total = 100;

        // Act & Assert
        var ex = Assert.Throws<ArgumentException>(() => 
            _service.CalculateCompletionRate(completed, total));
        Assert.Contains("Invalid completion count", ex.Message);
    }

    [Fact]
    public void CalculateCompletionRate_WithNegativeCompleted_ThrowsArgumentException()
    {
        // Arrange
        var completed = -10;
        var total = 100;

        // Act & Assert
        var ex = Assert.Throws<ArgumentException>(() => 
            _service.CalculateCompletionRate(completed, total));
        Assert.Contains("Invalid completion count", ex.Message);
    }
}

