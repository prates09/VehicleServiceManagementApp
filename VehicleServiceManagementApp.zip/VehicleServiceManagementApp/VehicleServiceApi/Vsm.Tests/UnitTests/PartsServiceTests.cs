using Vsm.Application.Services;
using Xunit;

namespace Vsm.Tests.UnitTests;

public class PartsServiceTests
{
    private readonly PartsService _service;

    public PartsServiceTests()
    {
        _service = new PartsService();
    }

    [Fact]
    public void IsLowStock_WhenStockBelowThreshold_ReturnsTrue()
    {
        // Arrange
        var stockQty = 3;
        var threshold = 5;

        // Act
        var result = _service.IsLowStock(stockQty, threshold);

        // Assert
        Assert.True(result);
    }

    [Fact]
    public void IsLowStock_WhenStockEqualsThreshold_ReturnsTrue()
    {
        // Arrange
        var stockQty = 5;
        var threshold = 5;

        // Act
        var result = _service.IsLowStock(stockQty, threshold);

        // Assert
        Assert.True(result);
    }

    [Fact]
    public void IsLowStock_WhenStockAboveThreshold_ReturnsFalse()
    {
        // Arrange
        var stockQty = 10;
        var threshold = 5;

        // Act
        var result = _service.IsLowStock(stockQty, threshold);

        // Assert
        Assert.False(result);
    }

    [Fact]
    public void IsLowStock_WithNegativeStock_ThrowsArgumentException()
    {
        // Arrange
        var stockQty = -5;
        var threshold = 5;

        // Act & Assert
        var ex = Assert.Throws<ArgumentException>(() => 
            _service.IsLowStock(stockQty, threshold));
        Assert.Contains("Stock quantity cannot be negative", ex.Message);
    }

    [Fact]
    public void AdjustStock_WithPositiveDelta_IncreasesStock()
    {
        // Arrange
        var currentStock = 50;
        var delta = 20;

        // Act
        var result = _service.AdjustStock(currentStock, delta);

        // Assert
        Assert.Equal(50, result.PreviousStock);
        Assert.Equal(20, result.Delta);
        Assert.Equal(70, result.NewStock);
    }

    [Fact]
    public void AdjustStock_WithNegativeDelta_DecreasesStock()
    {
        // Arrange
        var currentStock = 50;
        var delta = -20;

        // Act
        var result = _service.AdjustStock(currentStock, delta);

        // Assert
        Assert.Equal(50, result.PreviousStock);
        Assert.Equal(-20, result.Delta);
        Assert.Equal(30, result.NewStock);
    }

    [Fact]
    public void AdjustStock_WithDeltaThatWouldMakeNegative_ThrowsInvalidOperationException()
    {
        // Arrange
        var currentStock = 10;
        var delta = -20;

        // Act & Assert
        var ex = Assert.Throws<InvalidOperationException>(() => 
            _service.AdjustStock(currentStock, delta));
        Assert.Contains("would result in negative stock", ex.Message);
    }

    [Fact]
    public void ValidatePartData_WithValidData_ReturnsValid()
    {
        // Arrange
        var partNumber = "PART-001";
        var name = "Oil Filter";
        var unitPrice = 250m;
        var stockQty = 50;
        var lowStockThreshold = 10;

        // Act
        var result = _service.ValidatePartData(partNumber, name, unitPrice, stockQty, lowStockThreshold);

        // Assert
        Assert.True(result.IsValid);
        Assert.Empty(result.Errors);
    }

    [Fact]
    public void ValidatePartData_WithEmptyPartNumber_ReturnsInvalid()
    {
        // Arrange
        var partNumber = "";
        var name = "Oil Filter";
        var unitPrice = 250m;
        var stockQty = 50;
        var lowStockThreshold = 10;

        // Act
        var result = _service.ValidatePartData(partNumber, name, unitPrice, stockQty, lowStockThreshold);

        // Assert
        Assert.False(result.IsValid);
        Assert.Contains("Part number is required.", result.Errors);
    }

    [Fact]
    public void ValidatePartData_WithEmptyName_ReturnsInvalid()
    {
        // Arrange
        var partNumber = "PART-001";
        var name = "";
        var unitPrice = 250m;
        var stockQty = 50;
        var lowStockThreshold = 10;

        // Act
        var result = _service.ValidatePartData(partNumber, name, unitPrice, stockQty, lowStockThreshold);

        // Assert
        Assert.False(result.IsValid);
        Assert.Contains("Name is required.", result.Errors);
    }

    [Fact]
    public void ValidatePartData_WithZeroUnitPrice_ReturnsInvalid()
    {
        // Arrange
        var partNumber = "PART-001";
        var name = "Oil Filter";
        var unitPrice = 0m;
        var stockQty = 50;
        var lowStockThreshold = 10;

        // Act
        var result = _service.ValidatePartData(partNumber, name, unitPrice, stockQty, lowStockThreshold);

        // Assert
        Assert.False(result.IsValid);
        Assert.Contains("Unit price must be greater than zero.", result.Errors);
    }

    [Fact]
    public void ValidatePartData_WithNegativeStockQty_ReturnsInvalid()
    {
        // Arrange
        var partNumber = "PART-001";
        var name = "Oil Filter";
        var unitPrice = 250m;
        var stockQty = -10;
        var lowStockThreshold = 10;

        // Act
        var result = _service.ValidatePartData(partNumber, name, unitPrice, stockQty, lowStockThreshold);

        // Assert
        Assert.False(result.IsValid);
        Assert.Contains("Stock quantity cannot be negative.", result.Errors);
    }

}

