using Vsm.Application.Services;
using Vsm.Domain.Enums;
using Xunit;

namespace Vsm.Tests.UnitTests;

public class BillingServiceTests
{
    private readonly BillingService _service;

    public BillingServiceTests()
    {
        _service = new BillingService();
    }

    [Fact]
    public void CalculateInvoice_WithValidInputs_ReturnsCorrectTotals()
    {
        // Arrange
        var partsTotal = 1000m;
        var laborCharge = 500m;
        var taxRate = 0.10m; // 10%

        // Act
        var result = _service.CalculateInvoice(partsTotal, laborCharge, taxRate);

        // Assert
        Assert.Equal(1000m, result.PartsTotal);
        Assert.Equal(500m, result.LaborCharge);
        Assert.Equal(1500m, result.SubTotal);
        Assert.Equal(0.10m, result.TaxRate);
        Assert.Equal(150m, result.TaxAmount);
        Assert.Equal(1650m, result.TotalAmount);
    }

    [Fact]
    public void CalculateInvoice_WithNegativePartsTotal_ThrowsArgumentException()
    {
        // Arrange
        var partsTotal = -100m;
        var laborCharge = 500m;
        var taxRate = 0.10m;

        // Act & Assert
        var ex = Assert.Throws<ArgumentException>(() => 
            _service.CalculateInvoice(partsTotal, laborCharge, taxRate));
        Assert.Contains("Parts total cannot be negative", ex.Message);
    }

    [Fact]
    public void CalculateInvoice_WithNegativeLaborCharge_ThrowsArgumentException()
    {
        // Arrange
        var partsTotal = 1000m;
        var laborCharge = -100m;
        var taxRate = 0.10m;

        // Act & Assert
        var ex = Assert.Throws<ArgumentException>(() => 
            _service.CalculateInvoice(partsTotal, laborCharge, taxRate));
        Assert.Contains("Labor charge cannot be negative", ex.Message);
    }

    [Fact]
    public void CalculateInvoice_WithInvalidTaxRate_ThrowsArgumentException()
    {
        // Arrange
        var partsTotal = 1000m;
        var laborCharge = 500m;
        var taxRate = 1.5m; // Invalid: > 1

        // Act & Assert
        var ex = Assert.Throws<ArgumentException>(() => 
            _service.CalculateInvoice(partsTotal, laborCharge, taxRate));
        Assert.Contains("Tax rate must be between 0 and 1", ex.Message);
    }

    [Fact]
    public void DetermineLaborCharge_WithProvidedValue_ReturnsProvidedValue()
    {
        // Arrange
        var providedLaborCharge = 750m;
        var serviceCategoryBasePrice = 500m;

        // Act
        var result = _service.DetermineLaborCharge(providedLaborCharge, serviceCategoryBasePrice);

        // Assert
        Assert.Equal(750m, result);
    }

    [Fact]
    public void DetermineLaborCharge_WithoutProvidedValue_UsesServiceCategoryBasePrice()
    {
        // Arrange
        decimal? providedLaborCharge = null;
        var serviceCategoryBasePrice = 600m;

        // Act
        var result = _service.DetermineLaborCharge(providedLaborCharge, serviceCategoryBasePrice);

        // Assert
        Assert.Equal(600m, result);
    }

    [Fact]
    public void DetermineLaborCharge_WithoutAnyValue_ReturnsZero()
    {
        // Arrange
        decimal? providedLaborCharge = null;
        decimal? serviceCategoryBasePrice = null;

        // Act
        var result = _service.DetermineLaborCharge(providedLaborCharge, serviceCategoryBasePrice);

        // Assert
        Assert.Equal(0m, result);
    }

    [Fact]
    public void CanGenerateInvoice_WithCompletedStatus_ReturnsTrue()
    {
        // Act
        var result = _service.CanGenerateInvoice(ServiceRequestStatus.Completed);

        // Assert
        Assert.True(result);
    }

    [Fact]
    public void CanGenerateInvoice_WithClosedStatus_ReturnsTrue()
    {
        // Act
        var result = _service.CanGenerateInvoice(ServiceRequestStatus.Closed);

        // Assert
        Assert.True(result);
    }

    [Fact]
    public void CanGenerateInvoice_WithInProgressStatus_ReturnsFalse()
    {
        // Act
        var result = _service.CanGenerateInvoice(ServiceRequestStatus.InProgress);

        // Assert
        Assert.False(result);
    }

    [Fact]
    public void CanGenerateInvoice_WithRequestedStatus_ReturnsFalse()
    {
        // Act
        var result = _service.CanGenerateInvoice(ServiceRequestStatus.Requested);

        // Assert
        Assert.False(result);
    }
}

